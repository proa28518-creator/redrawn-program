// scenes/film.js — BUILD PASS: Tian Dan and the Fire-Oxen of Jimo (BIBLE.md, SHOTPLAN.md).
// 12 narrator lines (no `who` — third-person voiceover; nobody lip-syncs), 11 director
// segments, cuts ONLY on word boundaries (line starts; L5 on «جمع», L6 on its word
// boundaries, L10 at «وما», L12 at «الشرارة» / «يرجعوا» per the BIBLE line table).
// MOVEMENT LOCK: every shot is a named move with from→to (no parked camera), every segment
// has in-frame motion and a living element (flame / smoke / dust / cloth). Frame 0 is the
// hero bull's eye ECU, already galloping, tail aflame (the hook is a flash-forward).
// Prop state changes land on their BIBLE words; place changes only on cuts. Pure in t:
// bulls move on generated path keys, flames/gallop ride the `run` clock keys below.

import { makePost } from './post.js';
import { makeShade } from './shade.js';

// --- generated key helpers (pure data, built once at load) ---
const R2 = v => +v.toFixed(2);
// a straight path for a world prop: placement keys every `step` s (the stage blends
// ±0.1 s around each key, so 0.25 s steps read as continuous motion, never a jump)
function pathKeys(x0, z0, x1, z1, t0, t1, step = 0.25, rot = [0, 180, 0]) {
  const ks = [], n = Math.max(1, Math.round((t1 - t0) / step));
  for (let i = 0; i <= n; i++) { const u = i / n, t = t0 + (t1 - t0) * u;
    ks.push({ t: R2(t), at: [R2(x0 + (x1 - x0) * u), 0, R2(z0 + (z1 - z0) * u)], rot }); }
  return ks;
}
// the `run` clock: ramps 0→63.5 in 0.5 s steps with ease 0.5, so a prop's quantised opts
// change ~every frame and its userData.update (gallop, flame flicker, cloth flap) runs
// as a pure function of t
function clockKeys() {
  const ks = [];
  for (let t = 0; t <= 63.5; t += 0.5) ks.push({ t: R2(t), run: R2(t), ease: 0.5 });
  return ks;
}
const byT = (a, b) => a.t - b.t;
const bullKeys = extra => [...clockKeys(), ...extra].sort(byT);

export default {
  fps: 30, size: [1080, 1920],
  world: { set: 'own', setOpts: { post: { ...makePost(), shade: makeShade() } } },
  cast: {
    tiandan:   { spec: 'cast/tiandan.json',   at: [-3.6, -397.6], ry: -12 },
    witness:   { spec: 'cast/witness.json',   at: [-398.8, 2.2],  ry: 180 },
    commander: { spec: 'cast/commander.json', at: [-403.5, -3.0], ry: 20 },
    esoldier1: { spec: 'cast/esoldier1.json', at: [-401.7, 1.1],  ry: 55 },
    esoldier2: { spec: 'cast/esoldier2.json', at: [-398.6, 1.6],  ry: -30 },
    towns1:    { spec: 'cast/towns1.json',    at: [3.4, -400.5],  ry: -95 },
    towns2:    { spec: 'cast/towns2.json',    at: [1.8, -400.8],  ry: 150 },
    jsoldier1: { spec: 'cast/jsoldier1.json', at: [-403.0, -396.6], ry: 35 },
    jsoldier2: { spec: 'cast/jsoldier2.json', at: [-399.2, -398.4], ry: -50 },
    herder:    { spec: 'cast/herder.json',    at: [397.0, -399.5],  ry: 70 },
  },
  voice: {
    file: 'audio/clean.wav', words: 'scenes/words.json',
    lines: [
      { text: 'ديل التور بيولع وهو مش فاهم ليه بيجري ناحية الضلمة وقدامه معسكر جيش كامل' },
      { text: 'بعد حصار استمر خمس سنين كانت مدينة جيمو واحدة من آخر مدينتين بعد ما أكتر من 70 مدينة وقعت في مملكة شي' },
      { text: 'والعدو حاطط إيده في مية باردة' },
      { text: 'جوه الأسوار موظف صغير في السوق اسمه تيان دان لا كان قائد ولا جندي بس لقى نفسه مسؤول عن مصير المدينة' },
      { text: 'فقرر يعمل حركة جنونية جمع حوالي 1000 تور' },
      { text: 'لبسهم أقمشة حمرا مرسوم عليها تنانين وربط نصال في قرونهم وحزم قش مليانة زيت في ديولهم' },
      { text: 'ولما الليل نزل حفروا فتحات في سور المدينة وولعوا في الديول' },
      { text: 'التيران جريت زي المجنونة ناحية معسكر العدو' },
      { text: 'ووراهم 5000 جندي وأهل المدينة بيخبطوا على الطبول والأواني المعدن دوشة تزلزل الأرض' },
      { text: 'جنود العدو ما كانوش مصدقين عينيهم في الضلمة شافوا كائنات زي التنانين الحمرا نار في ديولهم وما لحقوش يفكروا' },
      { text: 'في لحظات المعسكر انهار والقائد اتقتل' },
      { text: 'ومن هنا كانت الشرارة اللي خلت السبعين مدينة يرجعوا تاني لأهلهم' },
    ],
  },
  acts: {
    tiandan: {
      place: [
        { t: 0, at: [-3.6, -397.6], ry: -12 },
        { t: 'line:12.word:9', at: [398.5, 2.2], ry: -10 },
      ],
      face: [
        { t: 0, brow: 'worried', eyes: 'sad', mouth: 'frown' },
        { t: 'line:4.start', brow: 'down', eyes: 'open', mouth: 'flat' },
        { t: 'line:4.word:8', brow: 'worried', eyes: 'sad', mouth: 'frown' },
        { t: 'line:4.word:18', brow: 'up', eyes: 'wide', mouth: 'o', react: false },
        { t: 'line:5.start', brow: 'down', eyes: 'stare', mouth: 'tight' },
        { t: 'line:5.word:4', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:12.word:9', brow: 'on', eyes: 'open', mouth: 'smile' },
      ],
      look: [
        { t: 'line:4.start', at: [-3.1, 1.0, -398.3], dip: 0.3 },
        { t: 'line:4.word:10', at: [1.8, 1.7, -400.8] },
        { t: 'line:4.word:14', at: [-3.1, 1.0, -398.3], dip: 0.3 },
        { t: 'line:4.word:18', at: [-3.4, 4.2, -393.5] },
        { t: 'line:5.start', at: [-3.2, 1.15, -398.15] },
        { t: 'line:5.word:3', at: [-2.45, 1.1, -398.35] },
        { t: 'line:12.word:9', at: [398.0, 2.6, -12] },
        { t: 'line:12.word:11', at: [402.5, 2.4, -13] },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:4.word:2', params: {} },
        { clip: 'lean_over', at: 'line:4.word:5', params: {} },
        { clip: 'point', at: 'line:4.word:8', hold: 6, out: 6, params: { side: 'R', dir: [0.2, -0.6, 0.4] } },
        { clip: 'head_turn', at: 'line:4.word:9', params: { yaw: 20 } },
        { clip: 'lean_over', at: 'line:4.word:9', out: 8, params: { deg: 24 } },
        { clip: 'lean_back', at: 'line:4.word:10', out: 8, params: {} },
        { clip: 'shake', at: 'line:4.word:12', params: { side: 'R' } },
        { clip: 'lean_back', at: 'line:4.word:11', params: {} },
        { clip: 'shrug', at: 'line:4.word:15', params: {} },
        { clip: 'lean_over', at: 'line:4.word:16', params: { deg: 20 } },
        { clip: 'head_turn', at: 'line:4.word:18', params: { yaw: -14 } },
        { clip: 'head_turn', at: 'line:5.start', params: { yaw: 0 } },
        { clip: 'lean_back', at: 'line:5.word:4', params: {} },
        { clip: 'point', at: 'line:12.word:10', hold: 10, out: 8, params: { side: 'R', dir: [0, 0.25, -0.4] } },
        { clip: 'head_turn', at: 'line:12.word:11', params: { yaw: 40 } },
      ],
    },
    witness: {
      place: [
        { t: 0, at: [-398.8, 2.2], ry: 180 },
        { t: 'line:10.word:17', at: [-398.8, 2.2], ry: 0 },
      ],
      face: [
        { t: 0, brow: 'on', eyes: 'open', mouth: 'rest' },
        { t: 'line:10.start', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:10.word:9', expr: 'fear' },
        { t: 'line:10.word:17', brow: 'up', eyes: 'wide', mouth: 'wide', react: false },
      ],
      look: [
        { t: 'line:10.start', at: [-398.8, 1.4, -14] },
        { t: 'line:10.word:6', at: [-401.0, 1.5, -13] },
        { t: 'line:10.word:12', at: [-395.5, 1.5, -12] },
        { t: 'line:10.word:17', at: [-398.8, 2.0, 14] },
      ],
      clips: [
        { clip: 'brace', at: 'line:10.word:4', params: {} },
        { clip: 'head_turn', at: 'line:10.word:6', params: { yaw: 22 } },
        { clip: 'react', at: 'line:10.word:9', params: { kind: 'recoil', deg: 10 } },
        { clip: 'head_turn', at: 'line:10.word:12', params: { yaw: -14 } },
        { clip: 'brace', at: 'line:10.word:14', params: {} },
        { clip: 'shock_jump', at: 'line:10.word:17', params: {} },
        { clip: 'brace', at: 'line:10.word:18', params: {} },
        { clip: 'brace', at: 'line:11.start', params: {} },
        { clip: 'lean_back', at: 'line:11.word:2', out: 6, params: { deg: 28, to: -28 } },
        { clip: 'head_turn', at: 'line:11.word:3', params: { yaw: -25 } },
      ],
    },
    commander: {
      face: [
        { t: 0, brow: 'down', eyes: 'smug', mouth: 'smirk' },
        { t: 'line:10.word:12', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:11.word:5', brow: 'up', eyes: 'wide', mouth: 'wide' },
        { t: 'line:11.word:6', brow: 'off', eyes: 'closed', mouth: 'flat', react: false },
      ],
      look: [
        { t: 'line:10.word:12', at: [-400, 1.5, -14] },
        { t: 'line:11.word:3', at: [-397.5, 1.3, -9] },
      ],
      clips: [
        { clip: 'akimbo', at: 'line:3.start', params: { side: 'both' } },
        { clip: 'lean_back', at: 'line:3.word:3', params: {} },
        { clip: 'head_turn', at: 'line:10.start', params: { yaw: 18 } },
        { clip: 'lean_back', at: 'line:10.word:6', params: {} },
        { clip: 'react', at: 'line:10.word:12', params: { kind: 'recoil', deg: 8 } },
        { clip: 'react', at: 'line:11.start', params: { kind: 'recoil', deg: 8 } },
        { clip: 'lean_over', at: 'line:11.word:3', out: 6, params: { deg: 22 } },
        { clip: 'head_turn', at: 'line:11.word:3', params: { yaw: -20 } },
        { clip: 'shake', at: 'line:11.word:4', params: { side: 'R' } },
        { clip: 'sit_down', at: 'line:11.word:5', params: {} },
      ],
    },
    esoldier1: {
      face: [
        { t: 0, brow: 'on', eyes: 'arc', mouth: 'smile' },
        { t: 'line:3.word:2', brow: 'up', eyes: 'arc', mouth: 'crescent' },
        { t: 'line:10.word:9', expr: 'fear' },
        { t: 'line:11.start', brow: 'up', eyes: 'wide', mouth: 'wide' },
      ],
      look: [
        { t: 'line:3.start', at: [-401.3, 0.3, 1.8], dip: 0.25 },
        { t: 'line:10.word:6', at: [-400, 1.2, -10] },
        { t: 'line:10.word:9', at: [-399, 1.5, -12] },
      ],
      clips: [
        { clip: 'sit', at: 0, params: { seat: 0.45 } },
        { clip: 'shake', at: 'line:3.word:2', params: { side: 'R' } },
        { clip: 'point', at: 'line:3.word:6', hold: 6, out: 6, params: { side: 'R', dir: [0.1, -0.7, 0.4] } },
        { clip: 'head_turn', at: 'line:10.word:6', params: { yaw: 12 } },
        { clip: 'stand_up', at: 'line:10.word:9', params: {} },
      ],
      walk: [
        { t0: 'line:10.word:10', path: [[-401.7, 1.1], [-403.5, 3.0], [-404.6, 5.5]], speed: 2.3, gait: 'run' },
        { t0: 'line:11.start', path: [[-404.6, 5.5], [-406.5, 8.5]], speed: 2.3, gait: 'run' },
      ],
    },
    esoldier2: {
      face: [
        { t: 0, brow: 'on', eyes: 'closed', mouth: 'rest', react: false },
        { t: 'line:10.word:9', expr: 'fear' },
        { t: 'line:11.start', brow: 'up', eyes: 'wide', mouth: 'o' },
      ],
      look: [{ t: 'line:10.word:9', at: [-397, 1.5, -12] }],
      clips: [
        { clip: 'sit', at: 0, params: { seat: 0.45 } },
        { clip: 'lean_back', at: 'line:3.start', params: {} },
        { clip: 'head_turn', at: 'line:3.word:4', params: { yaw: 16 } },
        { clip: 'head_turn', at: 'line:10.word:5', params: { yaw: -12 } },
        { clip: 'stand_up', at: 'line:10.word:9', params: {} },
        { clip: 'react', at: 'line:10.word:10', params: { kind: 'jolt' } },
      ],
      walk: [
        { t0: 'line:10.word:11', path: [[-398.6, 1.6], [-396.8, 3.4], [-395.8, 6.0]], speed: 2.3, gait: 'run' },
        { t0: 'line:11.start', path: [[-395.8, 6.0], [-394, 9.5]], speed: 2.3, gait: 'run' },
      ],
    },
    towns1: {
      place: [
        { t: 0, at: [3.4, -400.5], ry: -95 },
        { t: 'line:9.start', at: [397.5, 1.9], ry: -120 },
        { t: 'line:12.word:9', at: [393.5, 4.5], ry: -120 },
      ],
      face: [
        { t: 0, brow: 'worried', eyes: 'sad', mouth: 'frown' },
        { t: 'line:9.start', brow: 'down', eyes: 'stare', mouth: 'grid' },
        { t: 'line:9.word:12', brow: 'up', eyes: 'wide', mouth: 'wide' },
      ],
      look: [
        { t: 'line:4.start', at: [-3.6, 1.8, -397.6] },
        { t: 'line:9.start', at: [398.3, 1.3, -12], dip: 0 },
        { t: 'line:9.word:2', at: [398.3, 1.3, -12], dip: 0 },
        { t: 'line:9.word:4', at: [398.3, 1.3, -12], dip: 0 },
      ],
      clips: [
        { clip: 'head_turn', at: 'line:4.word:13', params: { yaw: 18 } },
        { clip: 'lean_over', at: 'line:4.word:18', params: {} },
        { clip: 'lean_over', at: 'line:9.word:4', params: { deg: 8 } },
        { clip: 'knock', at: 44.15, params: { side: 'R', prop: 'drum1', to: [-0.25, -0.05, 0.5] } },
        { clip: 'knock', at: 44.71, params: { side: 'L', prop: 'drum1', to: [0.25, -0.05, 0.5] } },
        { clip: 'knock', at: 45.9, params: { side: 'R', prop: 'drum1', to: [-0.25, -0.05, 0.5] } },
        { clip: 'knock', at: 46.87, params: { side: 'L', prop: 'drum1', to: [0.25, -0.05, 0.5] } },
        { clip: 'knock', at: 47.31, params: { side: 'R', prop: 'drum1', to: [-0.25, -0.05, 0.5] } },
      ],
      walk: [
        { t0: 'line:4.start', path: [[3.4, -400.5], [-3.4, -401.8]], speed: 0.95 },
      ],
    },
    towns2: {
      place: [
        { t: 0, at: [1.8, -400.8], ry: 150 },
        { t: 'line:9.start', at: [402.9, 2.0], ry: -135 },
      ],
      face: [
        { t: 0, brow: 'worried', eyes: 'sad', mouth: 'frown' },
        { t: 'line:4.word:10', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:9.start', brow: 'down', eyes: 'stare', mouth: 'grid' },
        { t: 'line:9.word:12', brow: 'up', eyes: 'wide', mouth: 'wide' },
      ],
      look: [
        { t: 'line:4.start', at: [-3.6, 1.8, -397.6] },
        { t: 'line:4.word:6', at: [-1.5, 1.2, -399.5] },
        { t: 'line:4.word:10', at: [-3.6, 1.8, -397.6] },
        { t: 'line:9.start', at: [402.2, 0.7, 1.1], dip: 0.2 },
        { t: 'line:9.word:3', at: [403.5, 1.7, -6] },
        { t: 'line:9.word:5', at: [402.2, 0.7, 1.1], dip: 0.2 },
      ],
      clips: [
        { clip: 'head_turn', at: 'line:4.word:6', params: { yaw: -18 } },
        { clip: 'head_turn', at: 'line:4.word:10', params: { yaw: 20 } },
        { clip: 'head_turn', at: 'line:4.word:14', params: { yaw: 0 } },
        { clip: 'lean_back', at: 'line:4.word:16', params: {} },
        { clip: 'lean_over', at: 'line:9.word:3', params: {} },
        { clip: 'knock', at: 45.0, params: { side: 'R', prop: 'pot1', to: [-0.3, 0.1, 0.45] } },
        { clip: 'knock', at: 45.51, params: { side: 'R', prop: 'pot1', to: [-0.3, 0.1, 0.45] } },
        { clip: 'knock', at: 46.4, params: { side: 'L', prop: 'pot1', to: [0.3, 0.1, 0.45] } },
        { clip: 'knock', at: 47.31, params: { side: 'L', prop: 'pot1', to: [0.3, 0.1, 0.45] } },
      ],
    },
    jsoldier1: {
      place: [
        { t: 0, at: [-403.15, -396.35], ry: 35 },
        { t: 'line:7.start', at: [-403.15, -396.35], ry: 85 },
        { t: 'line:7.word:9', at: [-403.15, -396.35], ry: 35 },
        { t: 'line:9.start', at: [395.5, 3.4], ry: 90 },
      ],
      face: [
        { t: 0, brow: 'knit', eyes: 'wince', mouth: 'grid' },
        { t: 'line:7.word:9', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:9.start', brow: 'down', eyes: 'stare', mouth: 'grid' },
      ],
      look: [
        { t: 'line:7.start', at: [-402.0, 0.9, -399.0] },
        { t: 'line:7.word:9', at: [-402.0, 0.9, -399.0] },
      ],
      clips: [
        { clip: 'knock', at: 'line:7.word:4', params: { side: 'R', to: [-0.3, -0.38, 0.55] } },
        { clip: 'shake', at: 'line:7.word:5', params: { side: 'L' } },
        { clip: 'knock', at: 'line:7.word:5', params: { side: 'R', to: [-0.3, -0.38, 0.55] } },
        { clip: 'lean_over', at: 'line:7.word:5-0.03', out: 5, params: { deg: 38 } },
        { clip: 'lean_back', at: 'line:7.word:6+0.03', out: 5, params: {} },
        { clip: 'lean_over', at: 'line:7.word:8+0.01', out: 5, params: { deg: 38 } },
        { clip: 'knock', at: 'line:7.word:8+0.11', params: { side: 'R', to: [-0.3, -0.38, 0.55] } },
        { clip: 'lean_back', at: 'line:7.word:8+0.26', out: 5, params: {} },
        { clip: 'lean_over', at: 'line:7.word:8+0.46', out: 5, params: { deg: 38 } },
        { clip: 'knock', at: 'line:7.word:9-0.23', params: { side: 'L', to: [0.3, -0.38, 0.55] } },
        { clip: 'lean_back', at: 'line:7.word:9-0.18', out: 7, params: {} },
        { clip: 'react', at: 'line:7.word:10', params: { kind: 'jolt' } },
      ],
      walk: [
        { t0: 'line:9.start', path: [[395.5, 3.4], [405.0, 3.4]], speed: 1.6, gait: 'run' },
      ],
    },
    jsoldier2: {
      place: [
        { t: 0, at: [-399.2, -398.4], ry: 145 },
        { t: 'line:9.start', at: [404.5, 3.8], ry: -90 },
        { t: 'line:12.word:9', at: [411.5, 4.0], ry: -90 },
      ],
      face: [
        { t: 0, brow: 'down', eyes: 'stare', mouth: 'flat' },
        { t: 'line:7.word:9', brow: 'up', eyes: 'wide', mouth: 'o', react: false },
        { t: 'line:9.start', brow: 'down', eyes: 'stare', mouth: 'grid' },
      ],
      look: [
        { t: 'line:7.start', at: [-401.8, 1.2, -398.2] },
        { t: 'line:7.word:8', at: [-402.0, 0.9, -399.0] },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:7.word:4', params: {} },
        { clip: 'raise_prop', at: 'line:7.word:8', params: { side: 'R', prop: 'torch1', to: 'forward', frames: 6, antic: 2 } },
      ],
      walk: [
        { t0: 'line:7.word:8', path: [[-399.2, -398.4], [-400.6, -398.6]], speed: 0.8 },
        { t0: 42.8, path: [[404.5, 3.8], [396.5, 3.8]], speed: 1.5, gait: 'run' },
      ],
    },
    herder: {
      face: [
        { t: 0, brow: 'on', eyes: 'open', mouth: 'flat' },
        { t: 'line:6.start', brow: 'down', eyes: 'stare', mouth: 'grid' },
        { t: 'line:6.word:11', brow: 'knit', eyes: 'wince', mouth: 'flat' },
      ],
      look: [
        { t: 'line:5.word:5', at: [400.5, 1.2, -400.5] },
        { t: 'line:6.start', at: [400.5, 1.4, -400.5] },
        { t: 'line:6.word:8', at: [400.3, 1.5, -401.2] },
        { t: 'line:6.word:11', at: [400.8, 0.9, -401.3] },
      ],
      place: [
        { t: 0, at: [397.0, -399.5], ry: 70 },
        { t: 'line:6.start', at: [401.6, -399.6], ry: -35 },
        { t: 'line:6.word:7', at: [401.3, -401.3], ry: -60 },
        { t: 'line:6.word:11', at: [401.6, -401.6], ry: -110 },
      ],
      clips: [
        { clip: 'wave', at: 'line:5.word:6', params: { side: 'R' } },
        { clip: 'lean_over', at: 'line:5.word:8', params: {} },
        { clip: 'lean_over', at: 'line:6.word:2', params: {} },
        { clip: 'shake', at: 'line:6.word:3', params: { side: 'R' } },
        { clip: 'shake', at: 'line:6.word:5', params: { side: 'L' } },
        { clip: 'point', at: 'line:6.word:8', hold: 5, out: 5, params: { side: 'R', dir: [-0.3, 0.35, -0.5] } },
        { clip: 'shake', at: 'line:6.word:10', params: { side: 'R' } },
        { clip: 'lean_over', at: 'line:6.word:12', params: {} },
        { clip: 'shake', at: 'line:6.word:14', params: { side: 'R' } },
      ],
      walk: [
        { t0: 'line:5.word:5', path: [[397.0, -399.5], [401.0, -399.7]], speed: 1.2 },
      ],
    },
  },
  props: [
    // THE HERO BULL — followed from frame 0 (BIBLE). Dressed + lit in seg 1 (flash-forward),
    // undressed on the seg-2 cut, dressed again on the seg-6 words, lit on «وولعوا» (37.28).
    { id: 'herobull', kind: 'bull', hero: 1, seed: 3, owner: 'tiandan', in: 'world',
      at: [3.4, 0, 7.5], rot: [0, 196.6, 0], cloth: 0, blades: 0, straw: 0, flame: 1, gallop: 1,
      keys: bullKeys([
        // seg-1 run is DIAGONAL (heading 196.6°): the body foreshortens toward the flank
        // camera so frame 0 can hold eye + tail flame in one frame (round-2 fix 1)
        ...pathKeys(3.4, 7.5, -1.2, -8, 0, 5.62, 0.28, [0, 196.6, 0]),
        { t: 5.9, flame: 0, gallop: 0.08 },
        { t: 6.26, at: [400.5, 0, -400.5], rot: [0, -20, 0] },
        { t: 26.6, at: [400.3, 0, -400.3], rot: [0, -20, 0] },
        { t: 28.39, cloth: 1, ease: 0.4 },
        { t: 30.75, blades: 1 },
        { t: 32.12, straw: 1, ease: 0.3 },
        { t: 34.4, at: [-401.8, 0, -398.2], rot: [0, 15, 0] },
        { t: 37.28, flame: 1, snap: true },
        { t: 38.9, gallop: 1 },
        ...pathKeys(0.5, 12, 0.5, -15, 38.9, 44.5, 0.28, [0, 180, 0]),
        ...pathKeys(-398.5, -13, -398.5, 3.5, 48.74, 55.4, 0.3, [0, 0, 0]),
        ...pathKeys(-398.5, 4.2, -398.0, 7.5, 56.21, 58.8, 0.4, [0, 0, 0]),
        { t: 58.8, gallop: 0.25 },
        { t: 59.55, at: [1.5, 0, -6], rot: [0, 205, 0], flame: 0, gallop: 0.06 },
      ]) },
    // pen herd (segs 5b/6): gathered undressed, dressed on the same seg-6 words
    ...[[-1.5, -1, 30], [1, -2, -40], [2.5, 0, 160], [-1, 1, 80]].map(([lx, lz, ry], i) => ({
      id: 'penbull' + (i + 1), kind: 'bull', seed: 11 + i, owner: 'herder', in: 'world',
      at: [400 + lx, 0, -400 + lz], rot: [0, ry, 0], cloth: 0, blades: 0, straw: 0, flame: 0, gallop: 0.1,
      keys: bullKeys([
        { t: 26.43 + i * 0.2, at: [400 + lx * 0.85, 0, -400 + lz * 0.85], rot: [0, ry, 0] },
        { t: 28.39, cloth: 1, ease: 0.5 },
        { t: 30.75, blades: i % 2 },
        { t: 32.12, straw: 1, ease: 0.4 },
      ]),
    })),
    // the wallbase line (seg 7): flame runs tail to tail from the hero on «وولعوا»
    ...[[-400.2, -398.0, 10], [-398.6, -397.8, -5], [-397.2, -398.3, 20]].map(([x, z, ry], i) => ({
      id: 'linebull' + (i + 1), kind: 'bull', seed: 21 + i, owner: 'jsoldier2', in: 'world',
      at: [x, 0, z], rot: [0, ry, 0], cloth: 1, blades: 1, straw: 1, flame: 0, gallop: 0.12,
      keys: bullKeys([{ t: 37.48 + i * 0.22, flame: 1 }, { t: 38.9, gallop: 0.9 }]),
    })),
    // the charge (seg 8, field): burst from the wall openings, every tail lit
    ...[[-5.5, 12.5], [-3.8, 13], [-2, 12.2], [0.5, 13.2], [2.2, 12.4], [4, 13], [5.6, 12.6]].map(([x, z], i) => ({
      id: 'fieldbull' + (i + 1), kind: 'bull', seed: 31 + i, owner: 'tiandan', in: 'world',
      // initial `at` parked BEHIND the field wall (z 15.9, wall slab 13.4–14.6): in seg 1
      // these bulls stood in front of the wall and one read as a disembodied horn arc
      // against it (build-final f_2_8). They teleport to the openings on the seg-8 cut
      // (38.9, first path key) — place changes only on cuts (PROP GUARD).
      at: [x, 0, 15.9], rot: [0, 180, 0], cloth: 1, blades: i % 2, straw: 1, flame: 0, gallop: 0.06,
      keys: bullKeys([
        { t: 37.3 + i * 0.16, flame: 1 },
        { t: 38.9, gallop: 1 },
        ...pathKeys(x, z, x * 1.15, -16, 38.9, 46.2, 0.3, [0, 180, 0]),
        { t: 46.5, gallop: 0.08 },
        ...(i < 3 ? [{ t: 59.55, at: [-2 + i * 2.6, 0, -7 - i * 1.5], rot: [0, 150 + i * 25, 0], flame: 0, gallop: 0.05 }] : []),
      ]),
    })),
    // the camp herd (segs 10/11a): the red dragon wall out of the dark
    ...[[-402.5, -14], [-400.5, -15], [-396.8, -14.5], [-394.8, -13.5]].map(([x, z], i) => ({
      id: 'campbull' + (i + 1), kind: 'bull', seed: 41 + i, owner: 'witness', in: 'hidden',
      at: [x, 0, z], rot: [0, 0, 0], cloth: 1, blades: i % 2, straw: 1, flame: 1, gallop: 1,
      keys: bullKeys([
        ...pathKeys(x, z, x + (i - 1.5) * 0.8, 4.5 - (i % 2), 48.74, 57.5, 0.3, [0, 0, 0])
          .map((k, j) => j === 0 ? { ...k, in: 'world' } : k),
        { t: 57.8, gallop: 0.35 },
      ]),
    })),
    // segment 9 rhythm: the drum hits land on «بيخبطوا» (44.25) / «الطبول» (44.81), the pot on
    // «الأواني» (45.10) / «المعدن» (45.61), then the rhythm rises to «تزلزل الأرض» (47.41)
    { id: 'drum1', kind: 'drum', owner: 'towns1', in: 'world', at: [398.3, 0, 0.9], rot: [0, -15, 0], hit: 0,
      keys: [44.25, 44.81, 46.0, 46.97, 47.41].flatMap(t => [{ t, hit: 1, snap: true }, { t: R2(t + 0.15), hit: 0 }]) },
    { id: 'pot1', kind: 'pot', owner: 'towns2', in: 'world', at: [402.2, 0.5, 1.1], rot: [0, 20, 0], hit: 0,
      keys: [45.10, 45.61, 46.5, 47.41].flatMap(t => [{ t, hit: 1, snap: true }, { t: R2(t + 0.15), hit: 0 }]) },
    // segment 5a: the stall lamp (the idea lights on «جنونية») and the dragon cloth
    { id: 'lamp1', kind: 'lamp', owner: 'tiandan', in: 'world', at: [-3.2, 0.99, -398.15], rot: [0, 0, 0], glow: 0.55,
      keys: bullKeys([{ t: 25.45, glow: 1, ease: 0.3 }]) },
    { id: 'dragoncloth1', kind: 'dragoncloth', owner: 'tiandan', in: 'world', at: [-2.45, 1.0, -398.35], rot: [0, 10, 0], lift: 0,
      keys: bullKeys([{ t: 25.45, lift: 1, ease: 0.55 }, { t: 26.43, lift: 0.25, ease: 0.4 }]) },
    // segment 3: the dice roll on «باردة»'s beat
    { id: 'dice1', kind: 'dice', owner: 'esoldier1', in: 'world', at: [-401.35, 0, 1.75], rot: [0, 30, 0], roll: 0,
      keys: [{ t: 15.72, roll: 1, ease: 0.7 }] },
    // segment 7: the ignition torch in jsoldier2's hand
    { id: 'torch1', kind: 'torch', owner: 'jsoldier2', in: 'hand:R', rot: [15, 0, 0], burn: 1,
      keys: clockKeys() },
    // enemy banners: one deep in the camp (living cloth), the command banner at the command
    // tent's pole — it falls on «انهار» (57.44)
    { id: 'banner1', kind: 'banner', seed: 1, owner: 'commander', in: 'world', at: [-406.5, 0, -12], rot: [0, 25, 0],
      keys: clockKeys() },
    { id: 'cmdbanner', kind: 'banner', seed: 5, color: '#7d2020', owner: 'commander', in: 'world', at: [-404.6, 0, -4.6], rot: [0, 10, 0], fall: 0,
      keys: bullKeys([{ t: 57.44, fall: 1, ease: 0.8 }]) },
    // camp tents: the first falls in seg 10's background on «يفكروا» (55.10), another in 11a
    { id: 'tent1', kind: 'tent', owner: 'esoldier1', in: 'world', at: [-403.8, 0, -4.5], rot: [0, 15, 0], fall: 0,
      keys: [{ t: 55.10, fall: 1, ease: 0.6 }] },
    { id: 'tent2', kind: 'tent', color: '#6b665b', owner: 'esoldier2', in: 'world', at: [-395.8, 0, -5.2], rot: [0, -20, 0], fall: 0,
      keys: [{ t: 56.96, fall: 1, ease: 0.7 }] },
    // 11a: fire spreading between the tents (fallen torches, appear on the seg-11 cut)
    { id: 'fire1', kind: 'torch', owner: 'commander', in: 'hidden', burn: 1, keys: clockKeys().concat([{ t: 56.21, in: 'world', at: [-397.0, 0.05, -6.2], rot: [0, 0, 80] }]).sort(byT) },
    { id: 'fire2', kind: 'torch', owner: 'commander', in: 'hidden', burn: 1, keys: clockKeys().concat([{ t: 56.21, in: 'world', at: [-402.5, 0.05, -9.0], rot: [20, 0, -75] }]).sort(byT) },
  ],
  shots: [
    // SEG 1 — the hook (round-2 re-stage): camera on the bull's FLANK at head height,
    // slightly ahead of the shoulder, looking diagonally ALONG the body: frame 0 holds the
    // west eye (1.23,1.3,5.96) large at one edge AND the lit tail flame (1.5,~0.75,7.98) at
    // the opposite edge past the receding body. The 0.9 key tracks at bull speed (2.67 D/s)
    // so the ECU geometry holds, then the shot settles into the side tracking (gallop, camp
    // ahead). Camera 1.13 D from the eye / 1.49 D from the head centre — outside the head
    // mesh (the opening-ECU exception); ≥2 D from the body centre.
    { t0: 0, t1: 'line:2.start', camera: { move: 'path', roll: [2, 1], keys: [
      { t: 0, pos: [1.61, 1.31, 5.84], target: [3.81, 1.03, 7.86], fov: 52 },
      { t: 0.9, pos: [0.87, 1.31, 3.36], target: [3.07, 1.03, 5.38], fov: 50 },
      { t: 2.4, pos: [-1.8, 2.2, -0.6], target: [1.6, 1.1, 0.6], fov: 36 },
      { t: 6.26, pos: [-3.4, 2.3, -13.5], target: [-1.0, 1.05, -8.3], fov: 35 } ] } },
    // SEG 2 — (round-2 re-stage) high wide from OUTSIDE the wall, far over the siege
    // sprawl, slow crane down + push: sprawl tents/banners/fires fill the near/mid ground
    // (local z -18..-43), the wall crosses the frame, Jimo rooftops (set.js, local z +9..13)
    // show behind/above the parapet, birds flee over the wall (7.2 s). Looking +Z also
    // removes the old frame's floating fragment — the pen place 400 D due -Z in the old
    // cone. Dawn sun hidden until 59.55 (set.js update).
    { t0: 'line:2.start', t1: 'line:3.start', camera: { move: 'push', ease: 'linear',
      from: { pos: [387.5, 2.8, -44], target: [400.5, 0.5, 1], fov: 46 },
      to: { pos: [389.5, 2.4, -40], target: [400.3, 0.4, 0.5], fov: 46 }, roll: [-2, -1] } },
    // SEG 3 — slow lateral dolly through the enemy camp: camera NW of the fire group so
    // esoldier2 (-398.6,1.6) centres, esoldier1 (-401.7,1.1) + dice left, commander
    // (-403.5,-3) centre-background, fire (-400,0.5) mid-frame
    { t0: 'line:3.start', t1: 'line:4.start', camera: { move: 'push', ease: 'linear',
      from: { pos: [-395.8, 2.9, 19.5], target: [-400.9, 1.1, 0.1], fov: 38 },
      to: { pos: [-394.6, 2.7, 17.8], target: [-400.4, 1.05, 0.05], fov: 38 }, roll: [2, 2] } },
    // SEG 4 — market push-in: wide ~12 D off Tian Dan's head (-3.6,1.95,-397.6), ending
    // front three-quarter at ~11 D with him LEFT of frame (face ~370 px)
    { t0: 'line:4.start', t1: 'line:5.start', camera: { move: 'push',
      from: { pos: [-0.1, 4.2, -385.8], target: [-3.1, 1.7, -397.5], fov: 31 },
      to: { pos: [0.2, 3.5, -387.5], target: [-3.3, 1.8, -397.4], fov: 29 }, roll: [-3, -2] } },
    // SEG 5a — night at his stall: Tian Dan (head -3.6,1.95,-397.6) LEFT at ~9.4 D (face
    // ~370 px), dragon cloth (-2.45,-398.35) centre-right, lamp (-3.2,-398.15) between them
    { t0: 'line:5.start', t1: 'line:5.word:5', camera: { move: 'push',
      from: { pos: [1.6, 2.2, -388.6], target: [-2.85, 1.55, -398.0], fov: 30 },
      to: { pos: [1.2, 2.0, -389.5], target: [-2.9, 1.5, -398.0], fov: 29 }, roll: [2, 3] } },
    // SEG 5b — cut on «جمع»: the pen filling with bulls, wide track (bulls centred on axis)
    { t0: 'line:5.word:5', t1: 'line:6.start', camera: { move: 'push', ease: 'linear',
      from: { pos: [393.8, 3.0, -390.8], target: [400.4, 1.1, -399.2], fov: 35 },
      to: { pos: [396.0, 2.8, -391.6], target: [401.0, 1.05, -399.6], fov: 35 }, roll: [-2, -2] } },
    // SEG 6a — montage 1: hands tie the red dragon cloth («أقمشة حمرا»)
    { t0: 'line:6.start', t1: 'line:6.word:7', camera: { move: 'push',
      from: { pos: [393.8, 2.8, -392.2], target: [401.8, 1.35, -400.2], fov: 30 },
      to: { pos: [394.4, 2.7, -392.8], target: [401.8, 1.32, -400.3], fov: 30 }, roll: [3, 2] } },
    // SEG 6b — montage 2: blades glint on the horns («نصال»)
    { t0: 'line:6.word:7', t1: 'line:6.word:11', camera: { move: 'push',
      from: { pos: [394.6, 1.9, -398.6], target: [399.9, 1.45, -399.3], fov: 28 },
      to: { pos: [395.0, 1.85, -398.8], target: [399.9, 1.42, -399.35], fov: 28 }, roll: [-3, -2] } },
    // SEG 6c — montage 3: oil-soaked straw bound to the tail («وحزم قش», oil dripping)
    { t0: 'line:6.word:11', t1: 'line:7.start', camera: { move: 'push',
      from: { pos: [402.4, 1.4, -402.8], target: [400.8, 0.9, -401.3], fov: 28 },
      to: { pos: [402.1, 1.35, -402.4], target: [400.8, 0.9, -401.3], fov: 28 }, roll: [2, 3] } },
    // SEG 7 — descend with the digging, then track the fire line: framed on jsoldier1 digging
    // at the left wall opening (-403,-396.6; opening at (-403.2,-395.2)), hero bull waiting
    // mid-ground (-401.8,-398.2), jsoldier2 + torch enter centre for the ignition at 37.28
    { t0: 'line:7.start', t1: 'line:8.start', camera: { move: 'push',
      from: { pos: [-403.5, 3.1, -411.5], target: [-401.3, 0.9, -396.8], fov: 36 },
      to: { pos: [-402.2, 2.8, -409.8], target: [-401.4, 0.9, -397.0], fov: 35 }, roll: [-2, -3] } },
    // SEG 8 — the charge: low OUTSIDE the openings (wall at z 13.4-14.6; build1's camera at
    // z 16.5->10.5 sat inside/behind the wall = black frame), retreating +X clear of the
    // herd lanes (max lane x 6.44) as the bulls burst toward/past. lowCam: no character in
    // shot; the BIBLE stages this camera low at the opening.
    { t0: 'line:8.start', t1: 'line:9.start', camera: { move: 'push', ease: 'linear', lowCam: true,
      from: { pos: [2.2, 1.2, -2.5], target: [0, 1.3, 9.5], fov: 38 },
      to: { pos: [8.5, 1.6, -5.5], target: [0.2, 1.35, 5.0], fov: 38 }, roll: [3, -3] } },
    // SEG 9 — tracking ON the wall top (x+400) at drummer shoulder height, from the EAST
    // end looking west so BOTH drummers fit the narrow 9:16 cone and jsoldier2's crossing
    // stays out of the foreground: towns1 + drum (397.5/398.3, 1.9/0.9) far, towns2 + pot
    // (402.9/402.2, 2.0/1.1) near, parapet + sprawl beyond (-Z)
    { t0: 'line:9.start', t1: 'line:10.start', camera: { move: 'push', ease: 'linear',
      from: { pos: [386.4, 3.5, -8.4], target: [398.9, 1.3, 1.6], fov: 41 },
      to: { pos: [388.4, 3.4, -7.8], target: [399.1, 1.25, 1.5], fov: 41 }, roll: [-2, 2] } },
    // SEG 10a — over the witness's shoulder: camera ~5 D behind + above his head
    // (-398.8,2.61,2.2; he faces -Z), head/shoulder in the lower third, the herd wall +
    // fire tails ahead (herobull on x -398.5 running z -13 -> 3.5)
    { t0: 'line:10.start', t1: 'line:10.word:17', camera: { move: 'push',
      from: { pos: [-396.2, 3.6, 11.8], target: [-398.6, 1.4, -7], fov: 32 },
      to: { pos: [-396.4, 3.4, 10.6], target: [-398.6, 1.4, -8], fov: 32 }, roll: [2, 1] } },
    // SEG 10b — pull back onto his terrified face («ما لحقوش يفكروا»): he turns to +Z at
    // word 17; camera in front of his head (-398.8,2.61,2.2), pulling 3.2 D -> 8.4 D
    { t0: 'line:10.word:17', t1: 'line:11.start', camera: { move: 'push',
      from: { pos: [-398.7, 2.3, 5.4], target: [-398.8, 2.55, 2.2], fov: 29 },
      to: { pos: [-398.55, 2.4, 10.6], target: [-398.8, 2.55, 2.2], fov: 29 }, roll: [-3, -2] } },
    // SEG 11a — the camp collapses, TRUE WIDE from the SE: command tent (-404.6,-6.5) +
    // its banner + the commander (-403.5,-3) in frame, fires spreading; camera kept clear
    // of the soldiers' flee endpoints (-404.6,5.5 / -395.8,6.0) that filled build1's frame
    { t0: 'line:11.start', t1: 'line:12.start', camera: { move: 'push',
      from: { pos: [-390.5, 4.9, 12.0], target: [-402.8, 1.15, -4.2], fov: 37 },
      to: { pos: [-391.5, 4.6, 10.6], target: [-402.6, 1.1, -4.6], fov: 37 }, roll: [2, 2] } },
    // SEG 12a — dawn: crane up over the battlefield
    { t0: 'line:12.start', t1: 'line:12.word:4', camera: { move: 'push',
      from: { pos: [2.6, 2.3, 2.5], target: [0, 1.2, -9], fov: 36 },
      to: { pos: [5.0, 6.0, 5.0], target: [-0.5, 1.0, -11], fov: 36 }, roll: [-2, -1] } },
    // SEG 12b — match-cut to the Qi map: top-down slow push on the qimap place (800,0);
    // 70 city lights relight 59.9-62.6 (heart: «السبعين مدينة»)
    { t0: 'line:12.word:4', t1: 'line:12.word:9', camera: { move: 'push',
      from: { pos: [801.5, 14.5, 7.0], target: [800, 0, -0.5], fov: 34 },
      to: { pos: [799.5, 12.0, 4.8], target: [800, 0, -0.5], fov: 34 }, roll: [1, 1] } },
    // SEG 12c — (round-2 re-stage) sunrise over Jimo's wall from OUTSIDE (-Z), around to
    // Tian Dan's FRONT three-quarter: he stands small on the walltop at (398.5,2.2) facing
    // -Z (his look target), face readable, head ~170 px at ~17.9 D / fov 36 (≥150 px for
    // the engine's endFraming — do not widen further). The dawn sun (set.js dawnW, moved
    // to local (-11,·,30)) sits clean on the view axis above/behind him — no horizon strip
    // crosses it. towns1/jsoldier2 step out of frame on this cut (place keys at word 9);
    // towns2/jsoldier1 fall outside the cone. Ends 63.64.
    { t0: 'line:12.word:9', t1: 63.64, camera: { move: 'push',
      from: { pos: [391.8, 3.8, -16.6], target: [397.6, 2.45, 1.2], fov: 36 },
      to: { pos: [393.4, 3.3, -13.2], target: [397.6, 2.45, 1.4], fov: 36 }, roll: [-1, 0] } },
  ],
  captions: 'words',
};
