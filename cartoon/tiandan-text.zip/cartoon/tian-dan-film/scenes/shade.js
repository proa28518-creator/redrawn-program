// scenes/shade.js — the SHADING pass: characters and props lit by their place.
// Consumed by world/look/rigshade.js via scenes/set.js (opts.post.shade).
// Per place: the key colour comes from the set's real light side (rig lights),
// keyTint/fillTint rebalance what the Post grade cooled; floor keeps faces out
// of mud; exposure lifts the people back after Post v11 dropped the world's
// level to the bar's night band. Dawn (59.55) is a state on field/walltop and
// lands on a cut, like every place change in this film (steps = seg bounds).
export function makeShade() {
  return {
    zones: { field: [0, 0], walltop: [400, 0], enemycamp: [-400, 0], market: [0, -400],
             pen: [400, -400], wallbase: [-400, -400], qimap: [800, 0] },
    states: [{ from: 59.55, zone: 'field', use: 'fieldDawn' },
             { from: 59.55, zone: 'walltop', use: 'walltopDawn' }],
    steps: [5.6, 9.41, 13.99, 16.76, 27.71, 35.36, 38.87, 44.1, 48.7, 55.41, 59.55],
    places: {
      // open field at night: cool moon key, warm fill from the camp fires far off
      field:      { exposure: 1.30, sat: 1.14, keyTint: [.82, .92, 1.14], fillTint: [1.14, .68, .32],
                    floor: [.28, .31, .40], hard: .65, rim: .6, rimFill: .55, low: .5,
                    metal: { spec: .7, env: .3, keep: .2, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
      // dawn: warm gold key, faces open up
      fieldDawn:  { exposure: 1.22, sat: 1.05, keyTint: [1.18, .98, .78], fillTint: [.85, .9, 1.05],
                    floor: [.36, .34, .30], hard: .5, rim: .45, rimFill: .45, low: .48,
                    metal: { spec: .7, env: .35, keep: .2, sky: [.6, .58, .5], ground: [.1, .09, .08] } },
      // wall top: brazier-warm key, cool moon fill
      walltop:    { exposure: 1.32, sat: 1.14, keyTint: [1.06, .9, .72], fillTint: [.76, .86, 1.14],
                    floor: [.28, .29, .37], hard: .67, rim: .55, rimFill: .5, low: .5,
                    metal: { spec: .7, env: .3, keep: .2, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
      walltopDawn:{ exposure: 1.22, sat: 1.05, keyTint: [1.16, .96, .74], fillTint: [.85, .9, 1.05],
                    floor: [.36, .34, .30], hard: .5, rim: .42, rimFill: .45, low: .48,
                    metal: { spec: .7, env: .35, keep: .2, sky: [.6, .58, .5], ground: [.1, .09, .08] } },
      // enemy camp: the central fire is the key — warm orange from the fire side,
      // blue moonlit shadow side (guide 08 campfire row); sparks never shaded
      enemycamp:  { exposure: 1.36, sat: 1.15, keyTint: [1.22, .78, .42], fillTint: [.7, .82, 1.15],
                    floor: [.27, .27, .36], hard: .7, rim: .6, rimFill: .6, low: .5,
                    metal: { spec: .8, env: .35, keep: .25, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
      // market: lantern-warm key, cool street fill
      market:     { exposure: 1.34, sat: 1.14, keyTint: [1.16, .86, .55], fillTint: [.76, .86, 1.1],
                    floor: [.28, .28, .36], hard: .67, rim: .5, rimFill: .5, low: .5,
                    metal: { spec: .7, env: .3, keep: .2, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
      // pen: lamp-warm key
      pen:        { exposure: 1.34, sat: 1.14, keyTint: [1.1, .86, .58], fillTint: [.78, .87, 1.1],
                    floor: [.28, .28, .36], hard: .67, rim: .5, rimFill: .5, low: .5,
                    metal: { spec: .7, env: .3, keep: .2, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
      // wall base: torch key, hard split, cool fill from the passage mouth
      wallbase:   { exposure: 1.34, sat: 1.14, keyTint: [1.2, .8, .45], fillTint: [.72, .84, 1.12],
                    floor: [.26, .26, .35], hard: .7, rim: .55, rimFill: .55, low: .5,
                    metal: { spec: .8, env: .35, keep: .25, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
      // map room glow: warm amber key off the board
      qimap:      { exposure: 1.28, sat: 1.12, keyTint: [1.16, .86, .5], fillTint: [.78, .86, 1.08],
                    floor: [.28, .27, .35], hard: .6, rim: .5, rimFill: .5, low: .5,
                    metal: { spec: .7, env: .3, keep: .2, sky: [.45, .52, .68], ground: [.07, .08, .12] } },
    },
    moods: [],
  };
}
