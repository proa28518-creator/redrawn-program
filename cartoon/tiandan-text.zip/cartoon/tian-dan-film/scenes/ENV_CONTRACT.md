# ENV CONTRACT — Tian Dan and the Fire-Oxen of Jimo (Environment overhaul)

The same film, real sets. Characters, acting, shots, voice, captions DO NOT CHANGE (one
lead-authorised exception: the seg-7 igniter facing touch, separate brief, film.js only).
Method = the previous film's proven template (~/workspace/projects/van-meegeren/blender/
build_set.py + its set.js GLB block): Blender 5.2.5 builds place-local GLBs into
assets/set/, scenes/set.js loads them with the engine's readGlb and a material-name
palette, everything falls back to the previz if a file is missing.

Coordinates: three.js place-local (x east, y up, z toward camera/south). Blender->glTF:
three (x,y,z) = blender (x, z, -y); place objects at blender (x, -z, y), dims (w, d, h).
Keep-clear: blender/keep_clear.json — binding. Read it before placing anything.

## Shared material names (GLB palette — env-three maps these exact names)
stone, stone_dark, wood, wood_dark, wood_pale, canvas_tent, canvas_red, cloth_blue,
iron, brass, straw, rope, tile_roof, plaster, ground_dark, paper.
Use ONLY these names. Bevel boxes (0.02, 2 seg) like the template — modelled read, no
plain code-colour cubes: vary sizes/rotations with a fixed seed, never a repeating pattern.

## SHIP ORDER (each GLB ships as soon as it is built)
1. walltop.glb — SEG 2 IS THE PASS'S FIRST CLOSURE TARGET (see below)
2. enemycamp.glb
3. market.glb
4. field.glb
5. pen.glb
6. wallbase.glb
7. qimap.glb

## Per place — what it must become

### walltop (400,0) — segs 2, 9, 12c. THE SEG-2 CLOSURE.
The shipped camera (local (-12.5,2.8,-44)->(-10.5,2.4,-40), target (0.4,0.45,0.75), fov 46)
frames three layers: siege sprawl foreground, the wall crossing mid-frame, Jimo rooftops
behind the parapet. Today the sprawl tents/rooftops are plain blocks and nothing reads.
GLB must deliver, in place-local coords:
- THE SPRAWL (z -44..-8, ground y -6.4): >=22 pitched tents (canvas_tent body + prism
  roof + ridge pole + entrance flap), sizes 1.8-3.0 wide, seeded scatter in rows that
  thin toward the horizon; >=10 banner standards (pole h 2.6-3.0 from ground, crossbar,
  cloth_blue hanging cloth 0.9x0.8); stone fire rings (6-8 small stones in a circle +
  2-3 crossed logs) at the EXISTING procedural glow points: (-24+i*6, -13-(i%3)*7) i=0..8
  and (-21+i*7, -29-(i%2)*5) i=0..6 (y = ground -6.4, ring centre y -6.3); 2 siege
  watchtowers (4 legs, platform, pitched cap, h ~4.2 from ground) at (-16,-26) and
  (14,-30); >=6 supply carts (bed, 2 big wheels, barrels) scattered z -12..-34;
  a palisade stake row (angled pointed logs) along z -10, x -20..20 with gaps;
  3 siege ladders leaning toward the wall at x -7, 3, 9 (base z -6, top resting y ~-0.5).
- THE WALL (z -2.5 face): a gatehouse protruding toward -Z at x 0: body 4.4 wide,
  from y -6.4 to -0.6, depth 1.6 (front face z -4.1), pitched cap, dark gate mouth
  (stone_dark inset 1.8w x 2.6h on its front); 2 round-ish towers (cylinders r 1.3,
  12 verts) at x -13 and +13.5 from y -6.4 to +2.2 with cone caps; stone pilaster
  strips (0.5w, 0.18 proud) every ~4.4 along the face; torch brackets (iron) at
  x -6, +6, y 0.4, z -2.7.
- THE CITY (z +9..+14, behind the parapet): >=8 real houses: plaster/stone walls,
  tile_roof pitched roofs (prism, ridge along x), chimneys, 2 with a second storey;
  ONE watch tower at x -8.5, z +12: stone body to y 3.0 + pyramidal tile cap to 4.2
  (caps in keep_clear.json); a gate arch silhouette at x +5, z +13 (two posts + beam,
  top <= 2.6). All other tops <= 2.6.
- WALL-TOP edges (outside the walking band): crate stack + weapon rack against the
  inner rail at x -9.5, z 4.3 (h <= 1.2); barrel pair at x +9, z 4.3.
- env-three: on successful walltop.glb load, HIDE the previz sprawl group (the two
  procedural sprawl tent loops + sprawl banner loops in set.js) — GLB replaces them.
  Keep: wall body/floor/parapet, rooftops bodies (GLB houses stand among/behind them —
  offset GLB houses z +10.5..+14.5 so both read as one city), braziers, glow bulbs,
  birds, dawn bulb. If the GLB is missing, the previz sprawl stays (fallback).

### enemycamp (-400,0) — segs 3, 10, 11a
- Tent upgrade at the 11 procedural tent positions (set.js: [-5.5,-4],[5.5,-4.5],
  [-6,-9],[6,-9.5],[-5,-14],[5.5,-14.5],[-6.5,-19],[6.5,-19.5],[-4,-24],[4.5,-25],
  [0,-29], rotation i*0.35): a prism roof (canvas_tent, ridge along local x of the
  tent) spanning 2.9w x 2.4d, base y 1.28, apex y 2.05; ridge pole caps; an entrance
  flap (triangle, stone_dark-canvas) on the +Z face; 2 guy ropes (thin cylinders)
  angled from the roof corners to ground stakes. The procedural box body stays as the
  tent's body — body + modelled roof + flap must read as one tent.
- Campfire dressing at (0,0.5): stone ring (8 stones r 0.75), 2 log benches at
  z 2.3, x -0.9 and +0.9 (clear of capsules — see keep_clear), a hanging pot tripod
  (3 poles + crossbar) at the fire's north edge z -0.3.
- Rows dressing: barrels + crates along x -6.8..-7.4 and +6.8..+7.4, z -4..-20;
  a weapon rack (frame + 4 spear shafts) at (-6.9,-6); water trough at (7,-11);
  banner standards (cloth_blue) at (-6,-16) and (6.5,-21); far-end tent row z -27..-33
  (5 smaller pitched tents, full GLB tents — no procedural bodies there); palisade
  stakes along z -34.
- SE foreground (seg 11a wide): crate stack + 2 barrels at (7.5,7.5)/(8.6,6.2), h<=1.0.
- Do NOT build the command tent (procedural, animated, local (-4.6,-6.5)) — keep its
  margin clear (keep_clear.json).

### market (0,-400) — segs 4, 5a. Local = world - (0,-400).
- Building fronts BOTH sides at |x| 5.4..7.2, z +4..-22: >=5 house fronts per side:
  plaster walls (3.4-4.6 h), tile_roof sloped slabs overhanging toward the street,
  door insets (wood_dark, 0.9w x 2.0h), window frames with wood shutters (some open),
  a stone base course. Vary widths/heights seeded — a lived street, not a pattern.
- Overhead: 3 cross-street beams (wood_dark, y 3.45) at z +5, -1, -7 spanning
  x -5.2..5.2, with 2 hanging sign boards (wood_pale 0.7x0.5, on short posts below
  the beam, bottom edge >= 3.0) on the z -1 and -7 beams, offset x -2 and +1.5.
- Ground dressing (flat or at street edges |x| 4.4..5.2): basket cylinders, jar
  clusters (3-5 per stall gap), sacks (squashed spheres, canvas_tent) at stall feet
  x -4.6/+4.6, z 2..-16; a stone well (cylinder r 0.7 h 0.8 + 2 posts + mini roof)
  at (4.9,-12.5); a hand cart (bed + 2 wheels + handles) at (-5.0,-17.5).
- Far end: the gate arch exists procedurally at z -24; add 2 flanking tower boxes
  (stone, 3.2w, 5.2h) at x +-3.4, z -24.5 and a tile cap strip.

### field (0,0) — segs 1, 8, 12a
- Wall enrichment at z 13.4..14.6 (the wall slab stays procedural): 2 flanking
  towers (box 2.6w, 7.5h + pyramid cap) at x +-12.5, z 14; timber frames around the
  3 openings (posts at opening x +-1.05, z 13.25, lintel at y 2.75 — mouths stay
  clear); stone pilasters on the wall face every ~5.5 (0.5w, 0.15 proud, z 13.3);
  fallen broken cart + barrel cluster at (-8.5, 10.5) (left foreground edge);
  siege debris: broken ladder at (9, 6), scattered shields (flat cylinders) |x| 7..11.
- Enemy camp at far -Z (z -27..-34): full pitched tents (7, matching the procedural
  silhouettes' positions in set.js — GLB tents stand AT those spots; env-three hides
  the procedural camp tent boxes on field.glb load, keeps the glow bulbs): tent =
  body + prism roof + flap, canvas_tent; 3 fire rings at (-3,-27.8),(1,-28.8),
  (4.5,-29.8) (the glow bulb positions); banner standards x -6/+6, z -30.
- Field dressing outside the lanes (|x| 8..20): rock clusters (already procedural
  small rocks inside — GLB adds 6 bigger boulder groups), 2 dead trees (-14,-6),
  (13,-14) (bare trunk + 2-3 branches, h <= 3.4), dry bush spheres squashed dark.
- Far hills: boxes at z -41, |x| 9..24, top <= 2.0 (sun clearance, keep_clear).

### pen (400,-400) — segs 5b, 6. Local = world - (400,-400).
- A barn at back-left OUTSIDE the fence: local (-7.5,-7): 4 posts, plaster/stone
  back + side walls, big pitched tile_roof (apex 3.2), open front facing +Z/+X,
  hay bales inside (3 cylinders lying, straw), a hanging lantern under the roof.
- Fence enrichment: diagonal brace boards on the outside of the existing rails
  (z +2.5 run and x +-4.5 runs), a gate frame at the back gap (x 1.2..3.4, z -5.5):
  2 posts + crossbar (gate stays open).
- Trough upgrade: stone trough (long box + inner dark water slab) beside the
  procedural one at (-3.4, 0.9); hay bale cylinders (r 0.42, lying) at (-4.2,-4.5),
  (4.3, 0.8); straw scatter: ~14 flat thin boxes (h 0.03) seeded inside the pen;
  a water bucket + rope coil by the gate post (2.2,-5.2).
- Nothing tall at the far end (walltop sightline cap, keep_clear).

### wallbase (-400,-400) — seg 7. Local = world - (-400,-400).
- Wall face enrichment (wall at local z 5.6, face toward -Z): stone pilasters
  (0.6w, 0.2 proud, z 4.85) at x -7.5, -5, +5, +7.5 (clear of the openings at
  -3.2/0/3.2 and the rubble apron); timber scaffolding against the wall at
  x 6..9 and x -9..-6: 4 poles + 2 platform levels (y 2.4, 4.4) + diagonal braces
  + a ladder; a mason's bench + bucket at its foot.
- Side return walls: stone stubs at x +-10.5, z 1..5.6 (2.8 h, 0.8 thick) framing
  the shot edges; rubble piles (stone clusters h <= 0.8) at (-5.2, 3.6), (5.6, 3.2)
  (clear of the apron lane); tool rack (frame + pick/shovel silhouettes as thin
  boxes) at (-6.5, 0.5); barrel pair + rope coil at (6.8, -0.5); extra torch
  bracket on the wall at (0, 3.1, 5.0) — bracket only, flame stays procedural? No:
  no new flame; bracket + unlit torch at x -5.5, y 2.6 on a pilaster.
- Ground: stone slab grid (flat boxes h 0.03, stone_dark edges) z 0..4.5.

### qimap (800,0) — seg 12b
- A stone border ring: 4 bevelled frame bars (stone) forming a 21x21 square frame
  at y 0.06 (inner edge radius >= 9.8 from centre), corner blocks (brass insets);
  an outer dark stone apron ring (flat, 26x26, ground_dark) under it; 4 corner
  lantern posts at (+-10.8,+-10.8): wood_dark post h 2.3 + brass lantern box +
  (env-three keeps the map lights; no bulbs in GLB — posts only, the place light
  rig already glows). Low plinth steps on the south edge (z +11.5): 2 flat steps.

## env-three (scenes/set.js) integration
- Copy the van-meegeren GLB block pattern (readGlb via ../world/look/glb.js,
  GLB_PALETTE by material name, try/catch fallback, place offsets:
  field [0,0], walltop [400,0], enemycamp [-400,0], market [0,-400],
  pen [400,-400], wallbase [-400,-400], qimap [800,0]).
- GLB_PALETTE (house flat pairs, night-true): stone ['#6a6e74','#4a4d52'],
  stone_dark ['#3f434a','#2a2d33'], wood ['#6e5136','#4c3823'],
  wood_dark ['#4c3519','#33230e'], wood_pale ['#8a6a42','#5f4726'],
  canvas_tent ['#7a7264','#57534a'], canvas_red ['#8d3a2c','#652619'],
  cloth_blue ['#33507a','#22334e'], iron ['#3a3d42','#24262a'],
  brass ['#a87c2c','#77571d'], straw ['#b08d4f','#7d6234'],
  rope ['#8a6f47','#5f4a2c'], tile_roof ['#4a5a6e','#333f4f'],
  plaster ['#9a8f7c','#6e6656'], ground_dark ['#232830','#161a21'],
  paper ['#e8e2d2','#c9c2ae'].
- Conditional hides (only when that place's GLB loaded): walltop -> hide the
  procedural sprawl tent/banner groups (wrap them in a named group first);
  field -> hide the procedural far-camp tent boxes (keep glow bulbs + wall +
  openings + torches). Nothing else is hidden; all dyn states (birds, cmdTent,
  rubble, dawn, cities, flames, awnings, lanterns, cloths) keep working.
- Do NOT change: lights data, PLACES, update(t) logic, marks, or any procedural
  geometry except the two conditional-hide groupings above.
- Exit check: drive-pipe info ERRORS: [] and stills render with GLBs present.

## The bar (judged by fresh critics, geometry/content only — grade/sky is Post's)
Every place reads as the real thing at full size: depth behind the faces, modelled
detail near the camera, practicals in frame, no plain-block silhouettes where the
eye goes, nothing in a keep-clear zone, no camera flight hits new geometry.
Seg 2 must read: a besieging ARMY CAMP (tents, banners, fires) below a real CITY
WALL, with a real CITY behind it.
