# BIBLE — Tian Dan and the Fire-Oxen of Jimo (تيان دان وتيران النار)

Build pass. The director's shot plan (`../SHOTPLAN.md`) is BINDING: 11 segments, cuts on word
boundaries only, the movement lock below. This bible locks cast, places, props, colour and the
line-by-line beats the builder implements in `film.js` / `set.js` / `cast/` / `props/`.

Format: 9:16, 1080x1920, 30 fps, frames 0..1909, film end = audio end 63.64 s.
Voice: `audio/clean.wav` exactly as delivered — never edited. 154 words, 12 lines, ALL lines are
narrator lines (third-person voiceover; `who` omitted in film.js lines — the engine resolves them
as narrator lines). On screen, each line's beat is carried by its named focus character(s), who
act and react; nobody lip-syncs the narration.
Captions: `captions: 'words'` from `scenes/words.json` (the faithful timings with the v2 bridging
rule applied to line-final words: end extended by gap − 0.42 s, capped +0.43 s; residual blink at
sentence boundaries ≤ 0.12 s). Style is the engine's established one: short white bold outlined
phrases, no black box, 60–86 % height band. No other text on screen, ever.

## THE MOVEMENT LOCK (director's order — no exceptions)
- NO static shot anywhere in the film. Every segment has (a) a named camera move with a start
  and an end, (b) motion inside the frame, (c) a living element: flame, smoke, dust or cloth.
- The bull is the motion hero: frame 0 is already running; the gallop is the film's pulse.
- Cuts only on word boundaries (line starts, and inside segment 6 on its word boundaries).

## GLOBAL LOOK
Ancient Chinese siege night. Deep night blue is the world; fire orange is the hero light;
dragon cloth crimson red; wall stone grey. Dawn gold only in segment 11b. Faces readable at all
times; no cropped faces; no main/focus character back-to-camera (segment 10's over-shoulder is
the plan's own staging: the shoulder may touch the frame edge but the segment's beat is the pull
back onto the witness's terrified FACE — the face must land big and readable). Frame 0: extreme
close on the hero bull's eye, flame entering from the frame edge, already galloping (the plan's
hook overrides the generic opening rule — the eye close-up is this film's expressive face).

## CAST (specs in scenes/cast/<id>.json, engine style: round white heads, ink outlines)
- `tiandan` — Tian Dan, small market clerk, young, plain undyed cloth clothes (hemp grey-brown,
  cloth belt), no hat, worried brow-led face. ALWAYS left of frame in market and wall scenes.
- `witness` — enemy soldier whose face is the mirror of terror in segment 10: full face keys,
  wide eyes; plain enemy uniform (dark blue-grey), cloth cap.
- `commander` — enemy commander: distinct silhouette (helmet with plume, dark armour tones,
  cape), seen in camp (seg 3 background / seg 10) and his tent falls in 11a; he is never
  glorified and never speaks.
- `esoldier1`, `esoldier2` — enemy soldiers (camp loungers, seg 3; panic crowd, seg 10/11a).
- `towns1`, `towns2` — Jimo townspeople (market crowd seg 4; drummers on the wall seg 9 —
  drumming is clips on the words, see line table).
- `jsoldier1`, `jsoldier2` — Jimo soldiers (runners behind the herd, seg 9; diggers, seg 7).
- `herder` — pen hand (segs 5/6), townsfolk variant.
Crowd depth: reuse the variants at different places/scales; nobody important is ever a copy
standing next to themselves in the same shot.

## THE BULLS (props, scenes/props/ — animals are modelled props, not character specs)
- `herobull` (kind `bull`, hero variant): one bull we follow from frame 0. Red cloth with a
  painted dragon over the back, blades bound on both horns, oil-soaked straw bundle on the tail.
  Pure-in-t gallop cycle (legs, head bob, cloth flap, tail sway). Flame states on the tail
  bundle: `flame: 0` unlit, `flame: 1` lit with flicker (flicker is a function of t, seeded).
  Attach states as prop keys: cloth/blades/straw appear in segment 6 on their words.
- `bull` (herd variant): simplified — cloth without dragon paint or plain, no blades on most,
  straw bundle on tail, same gallop at offset phases. The herd is ~8–12 placed instances in
  segs 8–10 (perf-safe), more read as dust/fire lines in the dark than as bodies.
Flame timing (binding): seg 1 the hero bull's tail is ALREADY lit (the hook is a flash-forward).
Segs 5–6: no flame anywhere on the bulls. Seg 7: ignition on the word «وولعوا» (37.28 s), flame
catches the hero bull's tail first and runs tail-to-tail down the line (cascade ≤ 1.5 s).
Segs 8–10: every visible tail lit. Seg 11a: fire spreading between tents (set/prop states).

## PLACES (scenes/set.js, own set, places 400 D apart; previz flat now — Environment owns the
real Blender sets later; give every place depth: far end 25 D+ behind the focus, 2+ visible
practicals, a living element keyed in set update(t) where noted)
1. `field` (0,0) — night field outside the walls. Wall silhouette at the +Z end, enemy camp
   glow at the far −Z end (25 D+). Ground dust. Segs 1, 8 (wall openings at the +Z edge), 11b
   dawn state (sky/lights shift by t in set update — dawn only after 59.55).
2. `walltop` (400,0) — top of Jimo's wall: parapet, braziers, drums and metal pots staged for
   seg 9, siege sprawl visible below/outside (tents + banner rows to the horizon = seg 2's
   wide). Segs 2, 9, 11b close.
3. `enemycamp` (−400,0) — enemy camp interior: tents in rows, central campfire, banners,
   command tent (distinct, larger, banner on a pole — its fall is a set state in 11a).
   Segs 3, 10, 11a.
4. `market` (0,−400) — Jimo market inside the walls: stalls with awnings (cloth flap in
   update(t)), hanging lanterns, goods crates, Tian Dan's small stall at the left. Segs 4, 5a.
5. `pen` (400,−400) — oxen pen: fence rails, trough, hay, gate. Segs 5b, 6.
6. `wallbase` (−400,−400) — inside base of the wall at night: torches, tools, the wall face
   where the openings are dug (opening states appear on the digging words). Seg 7.
7. `qimap` (800,0) — the Qi map graphic place: a dark ground plane carrying a stylised map of
   Qi (coastline/river lines as inlaid light strips) with 70 city light points. State
   `cities: n` — city lights ignite one by one (in set update(t) driven by film time during
   59.9–62.6, roughly 70 lights over ~2.5 s, seeded order, pure in t). Seg 11b only. This is
   the film's big motion-graphics moment, built as in-engine elements, no text.

## PROPS (scenes/props/<kind>.js; owners and hand-overs follow PROP GUARD — snap only on real
hits, place changes only on cuts)
- `bull` — hero + herd variants (above). Owner: world (paths as prop keys, pure in t).
- `drum` — wall drum; drummers' hits land on the words «بيخبطوا» (44.25) and «الطبول» (44.81).
- `pot` — metal vessel, second rhythm voice on «الأواني» (45.10) / «المعدن» (45.61).
- `torch` — wallbase/market torches; the ignition torch in seg 7 approaches the first tail on
  «وولعوا» (37.28) — the flame state change is the snap hit.
- `lamp` — Tian Dan's stall lamp (seg 5a), flame flicker; the idea lights with it.
- `dragoncloth` — the loose red dragon-painted cloth among his goods (seg 5a) that lifts in
  the lamp draught on «جنونية» (25.45) — the idea beat.
- `dice` — seg 3, a soldier's dice, rolling on «باردة»'s beat (camp idleness).
- `banner` — enemy banners (camp + sprawl): cloth flap everywhere; the command banner falls
  in 11a on «انهار» (57.44).
- `tent` — camp tents; first tent falls in seg 10 background on «يفكروا» (55.10), command
  tent falls in 11a.

## LINES — beats (narrator voiceover; focus = who carries the picture)
| # | time | place | focus / beat | camera (initial framing — Camera pass refines) | living element |
|---|------|-------|--------------|--------------------------------------------------|----------------|
| 1 | 0.03–5.62 | field | HERO BULL galloping at camera-side, tail aflame, camp lights growing ahead. Beat: the run never stops; eye ECU at frame 0. | side tracking at bull speed, from eye ECU pulling to full body | tail flame waves, hoof dust |
| 2 | 6.26–13.19 | walltop | The besieged city small below, siege sprawl to the horizon. Beat: scale of the trap. | high wide, slow crane down | banners flap, camp smoke rises, birds flee the wall |
| 3 | 13.78–15.89 | enemycamp | Enemy loungers round a low fire; one rolls dice, one asleep, weapon dropped. Beat: arrogance at rest. | slow lateral dolly | campfire, laughter shake, dice roll |
| 4 | 16.76–24.02 | market | TIAN DAN (left) counting goods at his stall; worried townsfolk pass. On «مسؤول» (22.87) he stops, lifts his eyes to the wall — the only still figure in a moving market. | slow push-in ending on his face | market flow, awning cloth, lantern sway |
| 5 | 24.59–27.71 | market→pen | Night, his stall lamp: his eye catches the DRAGON CLOTH (idea beat on «جنونية»). Cut on «جمع» (26.43) to the pen filling with bulls, herders running them in. | push on the cloth, then pen wide track | lamp flicker, cloth lifts, bulls jostle in |
| 6 | 28.12–33.74 | pen | Preparation montage, cuts ON WORDS inside the line: cloth tied («أقمشة حمرا» 28.39), blades glint on horns («نصال» 30.75), oil-soaked straw bound to tails («وحزم قش» 32.12, oil drip). Hands + bull heads, no faces needed except herder 3/4. | small push/orbit per mini-shot | tying, blade glint, oil dripping |
| 7 | 34.40–38.12 | wallbase | Digging the wall openings by torchlight («حفروا فتحات» 35.66); then the torch moves to the first tail — IGNITION on «وولعوا» (37.28), flame runs tail to tail. | descend with the digging, then track the fire line | sparks, torch flames, the fire cascade |
| 8 | 38.90–41.42 | field | THE CHARGE: bulls burst from the wall openings like a wave, fire lines behind each. Fastest segment. | low at an opening, camera shakes and retreats before the herd | dust burst, sparks, ground shake |
| 9 | 41.84–47.86 | walltop | Jimo soldiers run out behind the herd (below), townspeople on the wall HAMMER drums and pots — hits synced to «بيخبطوا على الطبول والأواني المعدن» (44.25–45.89), rhythm rising to «تزلزل الأرض» (47.41). | tracking along the wall-top | rhythmic hammering, pot glints, dust shivers per hit |
| 10 | 48.74–55.41 | enemycamp | WITNESS over-shoulder: the red dragon wall coming out of the dark, tails of fire; push in over his shoulder, then pull back onto his TERRIFIED FACE («ما لحقوش يفكروا» 54.71). First tent falls behind. | over-shoulder push, then pull-back reveal | herd approach, panic runs, tent fall |
| 11 | 56.21–59.17 | enemycamp | The camp collapses wide: command tent falls, its banner drops on «انهار» (57.44); «والقائد اتقتل» (58.25) — the commander falls among the chaos (no gore, no close-up: a figure down by the fallen tent, banner over him). | wide, slow push | spreading fire, fleeing figures, falling cloth |
| 12 | 59.55–63.19 | field→qimap→walltop | DAWN. Crane up over the battlefield; match-cut to the QI MAP: 70 city lights relight one by one («السبعين مدينة» 61.31–62.08 is the cascade's heart); close on sunrise over Jimo's wall, TIAN DAN small on top, watching. Final frame holds him + the risen sun. | crane up; map top-down slow push; final wall wide | city lights igniting in sequence, sun rising |

## COLOUR SCRIPT
Segs 1–10: night blue world, fire orange as the only warm hero light, crimson cloth the single
red accent (it must read as "dragon" colour before it reads as danger). Seg 2 dusk: last grey
violet in the sky. Seg 11b: dawn gold washes the field, map lights warm amber, final sunrise.

## BUILD LOCKS (checked by the critic)
- Frame 0 = hero bull eye ECU + flame at frame edge, galloping. No empty frame, no back.
- Every segment: named camera move + in-frame motion + living element (table above).
- No cropped faces; focus faces readable; Tian Dan left of frame in market/wall scenes.
- Every word of the 154 in exactly one line, as heard; cuts on word boundaries only.
- Prop state changes (cloth/blades/straw/flames/tent falls/banner fall/city lights) land on
  their words, listed above. PROP GUARD: no prop jumps; changes on cuts or with snap on hits.
- Pure in t everywhere: seeded randomness only, no Date/Math.random, no state between frames.
