// scenes/post.js — POST PASS: a look per place for Tian Dan (BIBLE colour script:
// segs 1-10 deep blue night, orange fire the hero light; seg 2 dusk grey-violet;
// 11b/12 dawn gold). Started from the quality-bar row "exterior at night"
// (coloured cobalt haze, aperture 9, warm bloom on windows/lamps, cooler grade,
// vignette) and tuned per place. The set's rigs wear a pale tan horizon, so the
// night places carry a dark cobalt murk and `far` long enough for the sky band
// to take the murk: the pale wash deepens to night instead of washing white.
// Every place change in this film is a cut, so `moves` is empty; the dawn at
// 59.55 also lands on a cut (line 12 start), so the two dawn states switch hard.
export function makePost(A = {}) {
  const dust = (count, box, color, alpha, vel = [.08, .012, -.03]) => ({
    mode: 'box', count, box, vel, velVar: [.05, .01, .03], size: .022, sizeVar: .8,
    color, alpha, lit: 1, ambient: .12, sway: .25, swaySpeed: .22,
    nearFade: [.4, 1.6], farFade: .012, soft: .1, shutter: .05 });
  const embers = (count, box, alpha = .3) => ({
    mode: 'box', count, box, vel: [.04, .1, .02], velVar: [.03, .05, .03], size: .013, sizeVar: .7,
    color: [1, .52, .18], alpha, lit: 0, ambient: 1, twinkle: .7,
    nearFade: [.4, 1.4], farFade: .03, soft: .06, shutter: .03 });
  return {
    quality: 'auto', maxBlur: 26, blend: .14,
    zones: { field: [0, 0], walltop: [400, 0], enemycamp: [-400, 0], market: [0, -400],
             pen: [400, -400], wallbase: [-400, -400], qimap: [800, 0] },
    states: [{ from: 59.55, zone: 'field', use: 'fieldDawn' },
             { from: 59.55, zone: 'walltop', use: 'walltopDawn' }],
    moves: [],
    focus: [[0, 5.6, 'herobull'], [16.76, 27.71, 'tiandan'], [35.36, 38.9, 'jsoldier2'], [48.7, 55.41, 'witness'], [61.28, 63.64, 'tiandan']],
    places: {
      field: {
        air: { density: .010, start: [.8, 6], far: 85, color: [.020, .034, .095], lights: .3, g: .25, top: [.009, .014, .050] },
        dof: { aperture: 9, nearK: .3, dead: .55 }, bloom: { k: .38, thr: .62 }, gain: 1.6,
        grade: { gamma: 1.12, contrast: 1.10, saturation: 1.28, gr: .94, gb: 1.20, vignette: .3, vgamma: 1.5 },
        particles: [dust(500, [46, 10, 46], [.55, .58, .66], .16),
          { mode: 'burst', at: [0, 1.2, 13], spread: [16, .8, 1.5], t0: 38.87, count: 350,
            vel: [0, 2.2, -7], velVar: [2.5, 1.6, 2], drag: 1.4, gravity: -2.5, life: 1.5,
            size: .05, sizeVar: .8, grow: .35, shape: 'puff', color: [.62, .55, .45], alpha: .5,
            opaque: 1, lit: 1, ambient: .15, soft: .3, shutter: .04 }],
      },
      fieldDawn: { rig: 'field',
        air: { density: .009, start: [1, 6], far: 95, color: [.020, .014, .007], lights: .3, g: .55 },
        dof: { aperture: 9, nearK: .3, dead: .55 }, bloom: { k: .3, thr: .72 }, gain: 1.45,
        grade: { gamma: 1.10, contrast: 1.05, saturation: 1.20, gr: 1.05, gb: .98, vignette: .30, vgamma: 1.5 },
        particles: [dust(350, [46, 10, 46], [.8, .66, .42], .14, [.08, .01, -.02])],
      },
      walltop: {
        air: { density: .0085, start: [.8, 6], far: 105, color: [.018, .020, .072], lights: .22, g: .3, top: [.007, .011, .046] },
        dof: { aperture: 5, nearK: .3, dead: .55 }, bloom: { k: .6, thr: .5 }, gain: 1.3,
        grade: { gamma: 1.02, contrast: 1.16, saturation: 1.14, gr: .70, gg: .92, gb: 1.42, vignette: .44, vgamma: 1.5 },
        particles: [dust(450, [44, 12, 44], [.55, .57, .68], .15), embers(90, [30, 7, 30])],
      },
      walltopDawn: { rig: 'walltop',
        air: { density: .009, start: [1, 6], far: 100, color: [.020, .014, .007], lights: .3, g: .55 },
        dof: { aperture: 9, nearK: .3, dead: .55 }, bloom: { k: .3, thr: .72 }, gain: 1.45,
        grade: { gamma: 1.10, contrast: 1.05, saturation: 1.20, gr: 1.05, gb: .98, vignette: .30, vgamma: 1.5 },
        particles: [dust(350, [44, 12, 44], [.8, .66, .42], .14, [.08, .01, -.02])],
      },
      enemycamp: {
        air: { density: .011, start: [.7, 5], far: 80, color: [.020, .030, .088], lights: .32, g: .3, top: [.009, .014, .050] },
        dof: { aperture: 9, nearK: .3, dead: .55 }, bloom: { k: .55, thr: .55 }, gain: 1.35,
        grade: { gamma: 1.02, contrast: 1.16, saturation: 1.16, gr: .74, gg: .93, gb: 1.38, vignette: .50, vgamma: 1.5 },
        particles: [dust(400, [44, 10, 44], [.5, .5, .6], .13, [.1, .01, -.03]),
          { mode: 'stream', at: [-400, 1.3, .5], spread: [2.2, .5, 2.2], count: 260,
            vel: [.15, 1.5, .1], velVar: [.3, .5, .3], life: 2.6, size: .016, sizeVar: .7,
            color: [1, .5, .15], alpha: .55, lit: 0, ambient: 1.1, twinkle: .65,
            sway: .3, swaySpeed: .8, nearFade: [.4, 1.4], soft: .06, shutter: .03 }],
      },
      market: {
        air: { density: .009, start: [.6, 4], far: 55, color: [.022, .028, .070], lights: .36, g: .3 },
        dof: { aperture: 13, nearK: .3, dead: .42 }, bloom: { k: .85, thr: .46 }, gain: 1.3,
        grade: { gamma: 1.04, contrast: 1.16, saturation: 1.18, gr: .86, gg: .95, gb: 1.30, vignette: .40, vgamma: 1.5 },
        particles: [dust(600, [34, 9, 34], [.62, .55, .42], .16, [.05, .008, -.02])],
      },
      pen: {
        air: { density: .010, start: [.6, 4], far: 55, color: [.020, .030, .080], lights: .3, g: .28 },
        dof: { aperture: 9, nearK: .3, dead: .5 }, bloom: { k: .45, thr: .58 }, gain: 1.35,
        grade: { gamma: 1.04, contrast: 1.16, saturation: 1.16, gr: .88, gg: .95, gb: 1.26, vignette: .44, vgamma: 1.5 },
        particles: [{ ...dust(550, [36, 8, 36], [.66, .58, .4], .15, [.04, -.03, -.01]), size: .026, sway: .3, swaySpeed: .2 }],
      },
      wallbase: {
        air: { density: .012, start: [.4, 4], far: 36, color: [.026, .026, .050], lights: .38, g: .3 },
        dof: { aperture: 14, nearK: .3, dead: .42 }, bloom: { k: .85, thr: .46 }, gain: 1.38,
        grade: { gamma: 1.03, contrast: 1.16, saturation: 1.16, gr: .86, gg: .95, gb: 1.30, vignette: .42, vgamma: 1.5 },
        particles: [dust(500, [30, 9, 30], [.55, .5, .44], .15, [.06, .01, -.02]),
          { mode: 'burst', at: [-400, 1.2, -397], spread: [3, .6, .6], t0: 37.25, count: 160,
            vel: [0, 1.6, 0], velVar: [1.2, .8, 1.2], drag: 1.2, gravity: -1.5, life: 1.1,
            size: .02, sizeVar: .7, color: [1, .55, .15], alpha: .6, lit: 0, ambient: 1.2,
            twinkle: .5, soft: .06, shutter: .02 }],
      },
      qimap: {
        air: { density: .005, start: [.5, 4], far: 45, color: [.004, .006, .014], lights: .2, g: .2 },
        dof: { aperture: 6, nearK: .35, dead: .5 }, bloom: { k: .5, thr: .58 }, gain: 1.65,
        grade: { gamma: 1.12, contrast: 1.12, saturation: 1.20, gr: 1.0, gb: 1.07, vignette: .4, vgamma: 1.5 },
        particles: [{ mode: 'box', count: 160, box: [26, 8, 26], vel: [.02, .05, .01], velVar: [.02, .02, .02],
          size: .018, sizeVar: .7, color: [.85, .68, .35], alpha: .22, lit: 0, ambient: .9, twinkle: .5,
          sway: .2, swaySpeed: .3, nearFade: [.4, 1.4], farFade: .02, soft: .06, shutter: .04 }],
      },
    },
  };
}
