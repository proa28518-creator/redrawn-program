// props/tent.js — a camp tent (BIBLE props): canvas wedge on poles. State `fall` 0..1
// collapses it — the first tent falls in segment 10's background on «يفكروا» (55.10) and
// the camp's tents go down through 11a. Origin at the ground centre; ridge along X.
import { THREE, flat, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group();
  const fallG = new THREE.Group(); g.add(fallG);
  const canvasM = flat(o.color ?? '#7a7466', '#57534a');
  // the roof: two sloped slabs meeting at the ridge
  [-1, 1].forEach(sd => {
    const slab = part(new THREE.BoxGeometry(2.3, .05, 1.25), canvasM, .02);
    slab.position.set(0, .78, sd * .31); slab.rotation.x = sd * -.85; fallG.add(slab);
  });
  const back = part(new THREE.BoxGeometry(2.3, .06, 1.1), canvasM, .018);
  back.position.set(0, .4, -.58); back.rotation.x = .12; fallG.add(back);
  const flap = part(new THREE.BoxGeometry(.7, .95, .04), flat('#6b665b', '#4c483f'), .016);
  flap.position.set(.3, .48, .62); flap.rotation.x = -.2; fallG.add(flap);
  [-1.05, 1.05].forEach(x => {
    const pole = part(new THREE.CylinderGeometry(.03, .03, 1.25, 8), flat('#4c3823', '#33250f'), .012);
    pole.position.set(x, .62, 0); fallG.add(pole);
  });
  const ridge = part(new THREE.CylinderGeometry(.028, .028, 2.4, 8), flat('#4c3823', '#33250f'), .012);
  ridge.rotation.z = Math.PI / 2; ridge.position.y = 1.26; fallG.add(ridge);
  g.userData.update = (obj, q) => {
    const fall = q.fall ?? 0;
    fallG.scale.y = 1 - fall * .78;
    fallG.rotation.z = fall * .22;
    fallG.rotation.x = fall * .1;
    fallG.position.y = -fall * .05;
  };
  g.userData.update(g, o);
  return finish(g);
}
