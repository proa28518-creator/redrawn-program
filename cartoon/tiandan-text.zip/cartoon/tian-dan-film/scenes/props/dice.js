// props/dice.js — a pair of bone dice (BIBLE props, segment 3): camp idleness. State
// `roll` 0..1: on «باردة»'s beat (15.72) they tumble — rotation and hop are pure functions
// of the eased roll value the film keys. Origin at the ground between the dice.
import { THREE, flat, part, finish } from '../../engine/props/_kit.js';

function die(x0, z0, seedTurns) {
  const dg = new THREE.Group(); dg.position.set(x0, .07, z0);
  const cube = part(new THREE.BoxGeometry(.13, .13, .13), flat('#e8e0cc', '#c4b998'), .012);
  dg.add(cube);
  const pipM = new THREE.MeshBasicMaterial({ color: 0x2c2115 });
  [[.032, .032], [-.032, -.032], [0, 0]].forEach(([px, py]) => {
    const pip = new THREE.Mesh(new THREE.CircleGeometry(.016, 8), pipM);
    pip.position.set(px, py, .066); dg.add(pip);
  });
  dg.userData.seedTurns = seedTurns;
  return dg;
}

export function build(o = {}) {
  const g = new THREE.Group();
  const d1 = die(-.11, .02, [2, 3]), d2 = die(.12, -.03, [3, 1]);
  g.add(d1, d2);
  g.userData.update = (obj, q) => {
    const roll = q.roll ?? 0;
    [d1, d2].forEach((d, i) => {
      const [tx, tz] = d.userData.seedTurns;
      d.rotation.x = roll * Math.PI * tx + i * .7;
      d.rotation.z = roll * Math.PI * tz;
      d.position.y = .07 + Math.sin(roll * Math.PI) * .09 * (1 - i * .3);
    });
  };
  g.userData.update(g, o);
  return finish(g);
}
