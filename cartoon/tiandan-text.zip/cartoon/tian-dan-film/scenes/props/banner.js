// props/banner.js — an enemy banner (BIBLE props): tall pole, crossbar, hanging cloth.
// The cloth flaps with the `run` clock everywhere; state `fall` 0..1 topples the whole
// banner — the command banner falls in segment 11a on «انهار» (57.44). Origin at the
// pole's foot.
import { THREE, flat, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group();
  const fallG = new THREE.Group(); g.add(fallG);
  const pole = part(new THREE.CylinderGeometry(.035, .045, 3.1, 8), flat('#4c3823', '#33250f'), .014);
  pole.position.y = 1.55; fallG.add(pole);
  const bar = part(new THREE.CylinderGeometry(.028, .028, 1.15, 8), flat('#4c3823', '#33250f'), .012);
  bar.rotation.z = Math.PI / 2; bar.position.y = 2.92; fallG.add(bar);
  const finial = part(new THREE.ConeGeometry(.07, .2, 8), flat('#c8a24a', '#96742c'), .012);
  finial.position.y = 3.22; fallG.add(finial);
  const clothG = new THREE.Group(); clothG.position.y = 2.92; fallG.add(clothG);
  const cloth = part(new THREE.BoxGeometry(1.05, 1.25, .03), flat(o.color ?? '#2e3d55', '#1e2839'), .016);
  cloth.position.y = -.64; clothG.add(cloth);
  const stripe = part(new THREE.BoxGeometry(1.05, .16, .036), flat('#c8a24a', '#96742c'), .008);
  stripe.position.y = -.2; clothG.add(stripe);
  g.userData.update = (obj, q) => {
    const run = q.run ?? 0, fall = q.fall ?? 0;
    clothG.rotation.y = Math.sin(run * 2.6 + (o.seed ?? 0)) * .16 * (1 - fall);
    cloth.rotation.x = Math.sin(run * 3.4 + (o.seed ?? 0)) * .06 * (1 - fall);
    fallG.rotation.x = fall * 1.35;
    fallG.position.y = -fall * .12;
  };
  g.userData.update(g, o);
  return finish(g);
}
