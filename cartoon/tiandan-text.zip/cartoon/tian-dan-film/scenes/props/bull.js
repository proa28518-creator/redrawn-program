// props/bull.js — THE BULL (BIBLE.md "THE BULLS"): hero variant (o.hero) and herd variant.
// Red dragon cloth over the back, blades bound on both horns, oil-soaked straw bundle on the
// tail. Timed states ride on userData.update as prop keys: cloth / blades / straw 0..1
// (they appear in segment 6 on their words), flame 0..1 (seg 1 already lit — the hook is a
// flash-forward; lit for real on «وولعوا» in segment 7), gallop 0..1 (legs settle when 0).
// The gallop itself is a pure function of the `run` opt, a clock the film ramps with keys
// every 0.5 s (prop opts are re-read when their quantised value changes, ~every frame), so
// legs, head bob, cloth flap, tail sway and flame flicker are all pure in t. Origin at the
// ground under the body's centre; the bull faces +Z in local space.
import { THREE, flat, basic, part, canvasTex, finish } from '../../engine/props/_kit.js';

function dragonTex() {
  return canvasTex(512, 320, (x, W, H) => {
    x.fillStyle = '#a01822'; x.fillRect(0, 0, W, H);
    x.fillStyle = '#8d1420'; x.fillRect(0, 0, W, 26); x.fillRect(0, H - 26, W, 26);
    x.strokeStyle = '#e8c33c'; x.lineWidth = 15; x.lineCap = 'round';
    x.beginPath();                                                        // the dragon's body: one serpentine sweep
    x.moveTo(52, 210); x.bezierCurveTo(140, 90, 220, 250, 300, 140);
    x.bezierCurveTo(350, 70, 410, 120, 452, 84); x.stroke();
    x.lineWidth = 9; x.beginPath();                                       // tail flick
    x.moveTo(52, 210); x.quadraticCurveTo(26, 160, 44, 118); x.stroke();
    x.fillStyle = '#e8c33c';                                              // head: wedge + horn + eye
    x.beginPath(); x.moveTo(438, 66); x.lineTo(492, 88); x.lineTo(446, 116); x.closePath(); x.fill();
    x.beginPath(); x.moveTo(452, 70); x.lineTo(470, 34); x.lineTo(482, 72); x.closePath(); x.fill();
    x.fillStyle = '#a01822'; x.beginPath(); x.arc(462, 88, 6, 0, 7); x.fill();
    x.strokeStyle = '#e8c33c'; x.lineWidth = 7;                            // legs / claws
    [[150, 196], [238, 200], [330, 168]].forEach(([lx, ly]) => {
      x.beginPath(); x.moveTo(lx, ly); x.lineTo(lx - 8, ly + 34); x.stroke();
    });
    x.fillStyle = 'rgba(232,195,60,.85)';                                 // scale dots
    for (let i = 0; i < 26; i++) { const px = 70 + ((i * 67) % 380), py = 96 + ((i * 41) % 130); x.beginPath(); x.arc(px, py, 4, 0, 7); x.fill(); }
  });
}

export function build(o = {}) {
  const hero = !!o.hero, seed = o.seed ?? (hero ? 3 : 7);
  let s = (seed * 9301 + 49297) % 233280 || 1;
  const rnd = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const phase0 = rnd() * 6.28;
  const g = new THREE.Group();
  const hide = flat('#4a3826', '#2e2115'), hideD = flat('#3c2d1e', '#241a10');
  const hornM = flat('#d8cdb2', '#a89a7c'), steel = flat('#c8ccd2', '#8a8f96');

  const bodyG = new THREE.Group(); g.add(bodyG);
  const bodyGeo = new THREE.CapsuleGeometry(.36, .95, 6, 14); bodyGeo.rotateX(Math.PI / 2); bodyGeo.scale(1, 1.06, 1);
  const body = part(bodyGeo, hide, .03); body.position.y = 1.08; bodyG.add(body);
  const hump = part(new THREE.SphereGeometry(.3, 12, 10), hideD, .025);
  hump.position.set(0, 1.32, .38); hump.scale.set(1, .8, 1.1); bodyG.add(hump);

  // head (front, +Z): skull, muzzle, ears, eyes, horns
  const headG = new THREE.Group(); headG.position.set(0, 1.22, .82); bodyG.add(headG);
  const skull = part(new THREE.BoxGeometry(.52, .56, .58), hide, .03); headG.add(skull);
  const muzzle = part(new THREE.BoxGeometry(.38, .3, .3), hideD, .025); muzzle.position.set(0, -.18, .36); headG.add(muzzle);
  [-1, 1].forEach(sd => {
    const nose = new THREE.Mesh(new THREE.SphereGeometry(.045, 8, 8), basic(0x1c1410));
    nose.position.set(sd * .09, -.2, .52); headG.add(nose);
    const ear = part(new THREE.ConeGeometry(.09, .3, 8), hideD, .02);
    ear.position.set(sd * .36, .12, -.02); ear.rotation.z = sd * -1.9; headG.add(ear);
    const eye = new THREE.Mesh(new THREE.SphereGeometry(.055, 10, 10), basic(0x140d08));
    eye.position.set(sd * .27, .08, .22); headG.add(eye);
    const glint = new THREE.Mesh(new THREE.SphereGeometry(.018, 6, 6), basic(0xffe9c0));
    glint.position.set(sd * .29, .12, .26); headG.add(glint);
  });
  // horns + their blades (state: blades)
  const bladeG = new THREE.Group(); headG.add(bladeG);
  [-1, 1].forEach(sd => {
    const hornGeo = new THREE.TorusGeometry(.18, .05, 8, 12, 1.9);
    const horn = part(hornGeo, hornM, .018);
    horn.position.set(sd * .3, .2, 0); horn.rotation.set(-.7, sd * .5, sd * -.9); headG.add(horn);
    const blade = part(new THREE.BoxGeometry(.035, .34, .13), steel, .012);
    blade.position.set(sd * .47, .4, -.06); blade.rotation.z = sd * -.5; bladeG.add(blade);
    const glint = new THREE.Mesh(new THREE.PlaneGeometry(.05, .3),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .0, side: THREE.DoubleSide }));
    glint.position.set(sd * .5, .4, .015); bladeG.add(glint); bladeG.userData['glint' + sd] = glint;
  });

  // legs: pivot groups at the hips/shoulders, gallop swings them about X
  const legs = [];
  [[-.2, .48], [.2, .48], [-.2, -.48], [.2, -.48]].forEach(([lx, lz], i) => {
    const hip = new THREE.Group(); hip.position.set(lx, .82, lz); bodyG.add(hip);
    const leg = part(new THREE.CylinderGeometry(.075, .055, .82, 10), hide, .022);
    leg.position.y = -.41; hip.add(leg);
    const hoof = part(new THREE.BoxGeometry(.13, .09, .16), flat('#2c2115', '#1a120a'), .015);
    hoof.position.set(0, -.8, .02); hip.add(hoof);
    legs.push({ hip, ph: (i < 2 ? 0 : Math.PI) + (i % 2) * .35 });
  });

  // the dragon cloth (state: cloth): top slab with the painted dragon + two side panels
  const clothG = new THREE.Group(); bodyG.add(clothG);
  const top = new THREE.Mesh(new THREE.BoxGeometry(1.0, .05, 1.3),
    [flat('#a01822'), flat('#a01822'), basic(0xffffff, { map: dragonTex() }), flat('#8d1420'), flat('#a01822'), flat('#a01822')]);
  top.position.set(0, 1.47, -.02); clothG.add(top);
  const panels = [];
  [-1, 1].forEach(sd => {
    const pg = new THREE.Group(); pg.position.set(sd * .5, 1.44, -.02); clothG.add(pg);
    const p = part(new THREE.BoxGeometry(.04, .62, 1.24), flat('#a01822', '#7d1019'), .018);
    p.position.y = -.31; pg.add(p); panels.push({ pg, sd });
  });

  // tail + straw bundle (state: straw) + flame (state: flame)
  const tailG = new THREE.Group(); tailG.position.set(0, 1.3, -.78); bodyG.add(tailG);
  const tail = part(new THREE.CylinderGeometry(.045, .03, .85, 8), hideD, .018);
  tail.position.set(0, -.36, -.1); tail.rotation.x = .25; tailG.add(tail);
  const strawG = new THREE.Group(); strawG.position.set(0, -.78, -.2); tailG.add(strawG);
  const straw = part(new THREE.ConeGeometry(.13, .42, 10), flat('#c8a24a', '#96742c'), .018);
  straw.rotation.x = Math.PI; strawG.add(straw);
  const band = part(new THREE.TorusGeometry(.09, .025, 6, 12), flat('#6e4526', '#4a2d14'), .012);
  band.rotation.x = Math.PI / 2; band.position.y = .12; strawG.add(band);
  const flameG = new THREE.Group(); flameG.position.set(0, -.78, -.2); tailG.add(flameG);
  const flames = [];
  [[0, .16, 0, .11, .42, 0xff7a26], [.05, .1, .03, .07, .3, 0xffb03a], [-.05, .12, -.02, .06, .26, 0xffd76a]].forEach(([fx, fy, fz, r, h, c]) => {
    const f = new THREE.Mesh(new THREE.ConeGeometry(r, h, 8), basic(c));
    f.position.set(fx, fy, fz); flameG.add(f); flames.push(f);
  });
  const glowBall = new THREE.Mesh(new THREE.SphereGeometry(.16, 10, 8),
    new THREE.MeshBasicMaterial({ color: 0xff9a3a, transparent: true, opacity: .35, depthWrite: false }));
  glowBall.position.y = .12; flameG.add(glowBall);

  g.userData.update = (obj, q) => {
    const run = q.run ?? 0, gal = q.gallop ?? 1;
    const cloth = q.cloth ?? (hero ? 1 : 0), blades = q.blades ?? (hero ? 1 : 0);
    const strawV = q.straw ?? 1, flame = q.flame ?? 0;
    clothG.visible = cloth > .02; bladeG.visible = blades > .02;
    strawG.visible = strawV > .02; flameG.visible = flame > .02;
    const ph = run * 9.6 + phase0;                                   // ~1.53 gallop cycles / s
    for (const L of legs) L.hip.rotation.x = Math.sin(ph + L.ph) * .62 * gal;
    bodyG.position.y = Math.abs(Math.sin(ph)) * .07 * gal + Math.sin(run * 2.2 + phase0) * .012;
    bodyG.rotation.x = Math.sin(ph * 2) * .02 * gal;
    headG.rotation.x = Math.sin(ph + .6) * .09 * gal + .04;
    headG.rotation.y = Math.sin(run * .7 + phase0) * .05 * (1 - gal * .5);
    tailG.rotation.z = Math.sin(ph * .5 + phase0) * .3;
    tailG.rotation.x = Math.sin(ph + 1.2) * .12 * gal;
    for (const P of panels) P.pg.rotation.z = P.sd * (Math.sin(run * 7 + phase0) * .1 + .06) * (0.4 + gal);
    top.rotation.x = Math.sin(run * 7.7 + phase0) * .03;
    const fl = flame * (0.85 + 0.22 * Math.sin(run * 31 + phase0 * 3) + 0.12 * Math.sin(run * 47));
    flameG.scale.set(fl, fl * (1 + .15 * Math.sin(run * 41 + phase0)), fl);
    glowBall.material.opacity = .35 * flame;
    [-1, 1].forEach(sd => { const gl = bladeG.userData['glint' + sd]; if (gl) gl.material.opacity = blades * Math.max(0, Math.sin(run * 1.3 + phase0 + sd)) * .8; });
  };
  g.userData.update(g, o);
  return finish(g);
}
