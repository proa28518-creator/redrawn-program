// props/torch.js — a hand torch (BIBLE props): wrapped head, live flame. The ignition torch
// of segment 7 approaches the first tail on «وولعوا» (37.28) — that flame state change on the
// bull is the snap hit; the torch itself just burns. Flame flicker is a pure function of the
// `run` clock opt the film ramps. Origin at the grip (bottom of the shaft).
import { THREE, flat, basic, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group();
  const shaft = part(new THREE.CylinderGeometry(.032, .04, .62, 10), flat('#6e4526', '#4a2d14'), .014);
  shaft.position.y = .31; g.add(shaft);
  const wrap = part(new THREE.CylinderGeometry(.075, .09, .2, 10), flat('#8a6a42', '#5f4726'), .016);
  wrap.position.y = .68; g.add(wrap);
  const flameG = new THREE.Group(); flameG.position.y = .8; g.add(flameG);
  const flames = [];
  [[0, .14, .09, .34, 0xff7a26], [.03, .09, .055, .24, 0xffb03a], [-.02, .11, .04, .18, 0xffd76a]].forEach(([fx, fy, r, h, c]) => {
    const f = new THREE.Mesh(new THREE.ConeGeometry(r, h, 8), basic(c));
    f.position.set(fx, fy, 0); flameG.add(f); flames.push(f);
  });
  const glowBall = new THREE.Mesh(new THREE.SphereGeometry(.13, 10, 8),
    new THREE.MeshBasicMaterial({ color: 0xff9a3a, transparent: true, opacity: .32, depthWrite: false }));
  glowBall.position.y = .12; flameG.add(glowBall);
  g.userData.update = (obj, q) => {
    const run = q.run ?? 0, burn = q.burn ?? 1;
    flameG.visible = burn > .02;
    const fl = burn * (0.86 + 0.2 * Math.sin(run * 29 + 1.7) + 0.1 * Math.sin(run * 43));
    flameG.scale.set(fl, fl * (1 + .13 * Math.sin(run * 37)), fl);
    flameG.rotation.z = Math.sin(run * 23) * .05;
  };
  g.userData.update(g, o);
  return finish(g);
}
