// props/drum.js — the wall drum (BIBLE props): a big standing war drum on a wooden frame.
// State `hit` 0..1: the head dents and the whole drum jolts — the film keys it on the drum
// words of line 9 («بيخبطوا» 44.25, «الطبول» 44.81, then the rising rhythm to «تزلزل الأرض»).
// Origin at the ground under the drum; the head faces +Z.
import { THREE, flat, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group();
  const frameM = flat('#6e4526', '#4a2d14');
  [-.42, .42].forEach(x => {
    const leg = part(new THREE.BoxGeometry(.09, 1.0, .09), frameM, .02);
    leg.position.set(x, .5, 0); leg.rotation.z = x > 0 ? -.18 : .18; g.add(leg);
  });
  const bar = part(new THREE.BoxGeometry(1.0, .08, .08), frameM, .018);
  bar.position.y = .18; g.add(bar);
  const drumG = new THREE.Group(); drumG.position.y = 1.02; g.add(drumG);
  const shellGeo = new THREE.CylinderGeometry(.52, .52, .5, 18); shellGeo.rotateX(Math.PI / 2);
  const shell = part(shellGeo, flat('#8d2f24', '#5f1d15'), .025); drumG.add(shell);
  const headGeo = new THREE.CircleGeometry(.48, 18);
  const head = new THREE.Mesh(headGeo, flat('#e3d3ac', '#c2ab7e'));
  head.position.z = .26; drumG.add(head);
  [-1, 1].forEach(sd => {
    const rimGeo = new THREE.TorusGeometry(.5, .035, 8, 20);
    const rim = part(rimGeo, flat('#5d3a1e', '#3c2410'), .015);
    rim.position.z = sd * .25; drumG.add(rim);
  });
  for (let i = 0; i < 8; i++) {                                   // rope lacing round the shell
    const a = (i / 8) * Math.PI * 2;
    const rope = part(new THREE.BoxGeometry(.035, .035, .52), flat('#c8a24a', '#96742c'), .008);
    rope.position.set(Math.cos(a) * .53, Math.sin(a) * .53, 0); drumG.add(rope);
  }
  g.userData.update = (obj, q) => {
    const hit = q.hit ?? 0;
    drumG.position.y = 1.02 - hit * .05;
    drumG.rotation.x = hit * .05;
    head.position.z = .26 - hit * .07;
    head.scale.setScalar(1 + hit * .04);
  };
  g.userData.update(g, o);
  return finish(g);
}
