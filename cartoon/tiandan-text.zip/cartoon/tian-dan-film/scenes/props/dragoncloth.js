// props/dragoncloth.js — the loose red dragon-painted cloth among Tian Dan's goods
// (BIBLE props, segment 5a). State `lift` 0..1: on «جنونية» (25.45) the lamp draught lifts
// it — the idea beat. It also stirs gently with the `run` clock. Origin at its resting
// centre on the stall counter; the cloth lies along X, painted side up (+Y face).
import { THREE, flat, basic, part, canvasTex, finish } from '../../engine/props/_kit.js';

function dragonTex() {
  return canvasTex(512, 256, (x, W, H) => {
    x.fillStyle = '#a01822'; x.fillRect(0, 0, W, H);
    x.strokeStyle = '#e8c33c'; x.lineWidth = 13; x.lineCap = 'round';
    x.beginPath();
    x.moveTo(46, 168); x.bezierCurveTo(140, 60, 230, 200, 320, 108);
    x.bezierCurveTo(372, 56, 424, 92, 458, 62); x.stroke();
    x.fillStyle = '#e8c33c';
    x.beginPath(); x.moveTo(446, 44); x.lineTo(494, 64); x.lineTo(452, 94); x.closePath(); x.fill();
    x.beginPath(); x.moveTo(458, 48); x.lineTo(474, 16); x.lineTo(486, 50); x.closePath(); x.fill();
    x.fillStyle = '#a01822'; x.beginPath(); x.arc(466, 66, 5, 0, 7); x.fill();
    x.fillStyle = 'rgba(232,195,60,.85)';
    for (let i = 0; i < 18; i++) { const px = 66 + ((i * 71) % 360), py = 66 + ((i * 43) % 110); x.beginPath(); x.arc(px, py, 3.5, 0, 7); x.fill(); }
  });
}

export function build(o = {}) {
  const g = new THREE.Group();
  const clothG = new THREE.Group(); g.add(clothG);
  const top = new THREE.Mesh(new THREE.BoxGeometry(1.15, .035, .62),
    [flat('#a01822'), flat('#a01822'), basic(0xffffff, { map: dragonTex() }), flat('#8d1420'), flat('#a01822'), flat('#a01822')]);
  clothG.add(top);
  const fold = part(new THREE.BoxGeometry(1.15, .03, .14), flat('#8d1420', '#6d0d16'), .01);
  fold.position.set(0, -.015, -.24); fold.rotation.x = .5; clothG.add(fold);
  g.userData.update = (obj, q) => {
    const run = q.run ?? 0, lift = q.lift ?? 0;
    clothG.position.y = lift * .34 + Math.sin(run * 3.1) * .008 * (1 + lift * 2);
    clothG.rotation.z = lift * -.16 + Math.sin(run * 2.3) * .012;
    clothG.rotation.x = lift * .1 + Math.sin(run * 2.7 + 1) * .01 * (1 + lift * 3);
  };
  g.userData.update(g, o);
  return finish(g);
}
