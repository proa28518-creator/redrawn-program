// props/pot.js — a metal cooking vessel (BIBLE props): the second rhythm voice of line 9,
// beaten on «الأواني» (45.10) and «المعدن» (45.61). State `hit` 0..1: a jolt + a glint flash
// on the rim. Origin at the ground under the pot; it hangs from its handle when held.
import { THREE, flat, basic, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group();
  const potG = new THREE.Group(); g.add(potG);
  const metal = flat('#9aa0a4', '#6d7276');
  const bellyGeo = new THREE.SphereGeometry(.3, 14, 10); bellyGeo.scale(1, .82, 1);
  const belly = part(bellyGeo, metal, .022); belly.position.y = .3; potG.add(belly);
  const rimGeo = new THREE.TorusGeometry(.24, .03, 8, 16); rimGeo.rotateX(Math.PI / 2);
  const rim = part(rimGeo, metal, .014); rim.position.y = .52; potG.add(rim);
  const lidGeo = new THREE.SphereGeometry(.24, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2); lidGeo.scale(1, .45, 1);
  const lid = part(lidGeo, flat('#868c90', '#5d6165'), .018); lid.position.y = .52; potG.add(lid);
  const handleGeo = new THREE.TorusGeometry(.2, .022, 6, 14, Math.PI);
  const handle = part(handleGeo, flat('#4c4f52', '#2e3033'), .012); handle.position.y = .56; potG.add(handle);
  const glint = new THREE.Mesh(new THREE.PlaneGeometry(.16, .05),
    new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide }));
  glint.position.set(.12, .44, .27); potG.add(glint);
  g.userData.update = (obj, q) => {
    const hit = q.hit ?? 0;
    potG.position.y = hit * .06;
    potG.rotation.z = hit * .14;
    glint.material.opacity = hit * .9;
  };
  g.userData.update(g, o);
  return finish(g);
}
