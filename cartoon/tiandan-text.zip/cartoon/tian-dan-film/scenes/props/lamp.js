// props/lamp.js — Tian Dan's stall lamp (BIBLE props, segment 5a): a small oil lamp on a
// stand. State `glow` 0..1: on «جنونية» (25.45) the idea lights with it — the flame swells.
// Flicker is a pure function of the `run` clock opt. Origin at the ground under the stand.
import { THREE, flat, basic, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group();
  const iron = flat('#3a3d40', '#232527');
  const stem = part(new THREE.CylinderGeometry(.03, .05, .5, 8), iron, .012);
  stem.position.y = .25; g.add(stem);
  const baseGeo = new THREE.CylinderGeometry(.16, .2, .05, 12);
  const base = part(baseGeo, iron, .012); base.position.y = .03; g.add(base);
  const bowlGeo = new THREE.SphereGeometry(.13, 12, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2); bowlGeo.scale(1, .6, 1);
  const bowl = part(bowlGeo, flat('#8a5f22', '#5f3f14'), .014); bowl.position.y = .62; g.add(bowl);
  const flameG = new THREE.Group(); flameG.position.y = .6; g.add(flameG);
  const flame = new THREE.Mesh(new THREE.ConeGeometry(.05, .22, 8), basic(0xffb03a));
  flame.position.y = .1; flameG.add(flame);
  const core = new THREE.Mesh(new THREE.ConeGeometry(.028, .13, 8), basic(0xffe9a0));
  core.position.y = .07; flameG.add(core);
  const glowBall = new THREE.Mesh(new THREE.SphereGeometry(.17, 10, 8),
    new THREE.MeshBasicMaterial({ color: 0xffc26a, transparent: true, opacity: .3, depthWrite: false }));
  glowBall.position.y = .1; flameG.add(glowBall);
  g.userData.update = (obj, q) => {
    const run = q.run ?? 0, glow = q.glow ?? .55;
    const fl = glow * (0.88 + 0.16 * Math.sin(run * 27 + .6) + 0.08 * Math.sin(run * 41));
    flameG.scale.set(.6 + fl * .7, fl * 1.5, .6 + fl * .7);
    glowBall.material.opacity = .12 + glow * .3;
    glowBall.scale.setScalar(.7 + glow * .8);
  };
  g.userData.update(g, o);
  return finish(g);
}
