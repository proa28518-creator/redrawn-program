// scenes/set.js — the film's own set (film.js: world: { set: 'own' }). Seven places, 400 D
// apart (BIBLE.md PLACES), so one place's light never leaks into another:
//   field     (0,0)        night field: Jimo's wall + openings at the +Z end, the enemy camp
//                          glow 25 D+ away at the -Z end. Segs 1, 8, 11b (dawn state).
//   walltop   (400,0)      top of Jimo's wall: parapet, braziers, the siege sprawl below to
//                          the horizon. Segs 2, 9, 11b close.
//   enemycamp (-400,0)     the enemy camp interior: tent rows, central fire, command tent
//                          (its fall at 57.44 is a set state). Segs 3, 10, 11a.
//   market    (0,-400)     Jimo market inside the walls: stalls, awnings, lanterns, Tian
//                          Dan's small stall at the LEFT. Segs 4, 5a.
//   pen       (400,-400)   the oxen pen: fence, trough, hay, gate. Segs 5b, 6.
//   wallbase  (-400,-400)  inside base of the wall at night: torches, tools, the wall face
//                          the openings are dug into (rubble state on the digging words). Seg 7.
//   qimap     (800,0)      the Qi map graphic: dark plane, inlaid light strips, 70 city
//                          lights igniting one by one in update(t) over 59.9–62.6. Seg 11b.
// Previz flat is correct at Build (Environment owns the real sets later); every place still
// has depth: a far end 25 D+ behind the focus, 2+ visible practicals, lights as data.
// update(t) is pure in t: flame flicker, awning cloth, lantern sway, banner flap, the birds'
// flight (seg 2), the command tent's fall, the digging rubble, the dawn sun, the city lights.
import { createLightRig } from '../world/look/lights.js';
import { createPost } from '../world/look/post.js';
import { createRigShade } from '../world/look/rigshade.js';
import { flat } from '../lib/film/props.js';
import { outline } from '../engine/shade.js';

const NIGHT = { sky: [.1, .14, .24], ground: [.07, .08, .12], fog: { color: '#131c2c', density: .012 } };
const PLACES = {
  field: {
    ...NIGHT,
    lights: [
      { id: 'moon', kind: 'spot', color: [.55, .65, .9], power: .85, pos: [-4, 9, 6], dir: [.2, -.8, -.3], cone: [35, 65], fall: .03, range: 30 },
      { id: 'camp', kind: 'point', color: [1, .55, .2], power: 1.1, pos: [0, 1.6, -27], fall: .04, range: 34 },
      { id: 'torchL', kind: 'point', color: [1, .62, .25], power: .8, pos: [-3.4, 2.6, 12.4], fall: .07, range: 10 },
      { id: 'torchR', kind: 'point', color: [1, .62, .25], power: .8, pos: [3.4, 2.6, 12.4], fall: .07, range: 10 },
    ],
    states: [{ from: 59.55, sky: [.42, .34, .26], fog: { color: '#4a3a2c', density: .008 },
      lights: { moon: { power: 1.05, color: [1, .78, .5] }, camp: { power: .5 } } }],
  },
  walltop: {
    sky: [.12, .15, .26], ground: [.09, .09, .13], fog: { color: '#18202f', density: .01 },
    lights: [
      { id: 'moon', kind: 'spot', color: [.55, .65, .9], power: .8, pos: [396, 10, 8], dir: [.2, -.8, -.3], cone: [35, 65], fall: .03, range: 32 },
      { id: 'brazL', kind: 'point', color: [1, .6, .22], power: 1.0, pos: [396.4, 1.7, .6], fall: .06, range: 12 },
      { id: 'brazR', kind: 'point', color: [1, .6, .22], power: 1.0, pos: [403.6, 1.7, .6], fall: .06, range: 12 },
      { id: 'sprawl', kind: 'point', color: [1, .5, .2], power: .7, pos: [400, 0, -22], fall: .03, range: 30 },
    ],
    states: [{ from: 59.55, sky: [.45, .36, .27], fog: { color: '#54402c', density: .007 },
      lights: { moon: { power: 1.1, color: [1, .8, .52] } } }],
  },
  enemycamp: {
    ...NIGHT,
    lights: [
      { id: 'fire', kind: 'point', color: [1, .58, .2], power: 1.25, pos: [-400, 1.3, .5], fall: .05, range: 16 },
      { id: 'moon', kind: 'spot', color: [.5, .6, .88], power: .7, pos: [-404, 9, 7], dir: [.25, -.8, -.3], cone: [35, 65], fall: .03, range: 30 },
      { id: 'lampL', kind: 'point', color: [1, .7, .35], power: .6, pos: [-404.5, 1.6, -3], fall: .07, range: 9 },
      { id: 'lampR', kind: 'point', color: [1, .7, .35], power: .6, pos: [-395.5, 1.6, -3.5], fall: .07, range: 9 },
    ],
  },
  market: {
    sky: [.11, .14, .24], ground: [.09, .08, .11], fog: { color: '#151d2b', density: .011 },
    lights: [
      { id: 'lant1', kind: 'point', color: [1, .68, .3], power: 1.0, pos: [-2, 2.6, -398], fall: .06, range: 12 },
      { id: 'lant2', kind: 'point', color: [1, .68, .3], power: .85, pos: [2.4, 2.6, -401], fall: .06, range: 12 },
      { id: 'lant3', kind: 'point', color: [1, .62, .28], power: .7, pos: [0, 2.8, -406], fall: .05, range: 14 },
      { id: 'moon', kind: 'spot', color: [.45, .55, .85], power: .55, pos: [-3, 9, -394], dir: [.2, -.85, -.2], cone: [35, 65], fall: .03, range: 28 },
    ],
  },
  pen: {
    ...NIGHT,
    lights: [
      { id: 'moon', kind: 'spot', color: [.55, .65, .9], power: .8, pos: [396, 9, -394], dir: [.2, -.8, .3], cone: [35, 65], fall: .03, range: 30 },
      { id: 'lamp', kind: 'point', color: [1, .66, .3], power: .9, pos: [396.2, 2.0, -398.6], fall: .06, range: 11 },
      { id: 'lamp2', kind: 'point', color: [1, .62, .28], power: .6, pos: [404, 2.0, -402], fall: .06, range: 10 },
    ],
  },
  wallbase: {
    ...NIGHT,
    lights: [
      { id: 'torchL', kind: 'point', color: [1, .62, .25], power: 1.1, pos: [-403.4, 2.2, -397.6], fall: .06, range: 13 },
      { id: 'torchR', kind: 'point', color: [1, .62, .25], power: 1.1, pos: [-396.6, 2.2, -397.6], fall: .06, range: 13 },
      { id: 'moon', kind: 'spot', color: [.45, .55, .85], power: .5, pos: [-404, 10, -406], dir: [.3, -.85, .3], cone: [35, 65], fall: .03, range: 30 },
    ],
  },
  qimap: {
    sky: [.05, .06, .1], ground: [.04, .04, .06], fog: { color: '#0a0d16', density: .006 },
    lights: [
      { id: 'map', kind: 'point', color: [1, .72, .35], power: 1.0, pos: [800, 4, 2], fall: .03, range: 30 },
      { id: 'moon', kind: 'spot', color: [.5, .6, .9], power: .5, pos: [796, 10, 8], dir: [.2, -.85, -.3], cone: [40, 70], fall: .03, range: 34 },
    ],
  },
};

function part(THREE, geo, mat, ink = .03) {
  const m = new THREE.Mesh(geo, mat);
  if (ink > 0) outline(m, { width: ink, color: 0x14100c });
  m.frustumCulled = false;
  return m;
}
function box(THREE, w, h, d, color, dark, x, y, z, ry = 0, ink = .02) {
  const m = part(THREE, new THREE.BoxGeometry(w, h, d), flat(color, dark), ink);
  m.position.set(x, y, z); m.rotation.y = ry; return m;
}
function glow(THREE, w, h, d, color, x, y, z, ry = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshBasicMaterial({ color }));
  m.position.set(x, y, z); m.rotation.y = ry; m.frustumCulled = false; return m;
}
function bulb(THREE, r, color, x, y, z) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), new THREE.MeshBasicMaterial({ color }));
  m.position.set(x, y, z); m.frustumCulled = false; return m;
}
function flame(THREE, x, y, z, s = 1) {
  const f = new THREE.Group(); f.position.set(x, y, z);
  const a = new THREE.Mesh(new THREE.ConeGeometry(.16 * s, .55 * s, 8), new THREE.MeshBasicMaterial({ color: 0xff7a26 }));
  a.position.y = .26 * s; f.add(a);
  const b = new THREE.Mesh(new THREE.ConeGeometry(.1 * s, .36 * s, 8), new THREE.MeshBasicMaterial({ color: 0xffc26a }));
  b.position.y = .18 * s; f.add(b);
  f.userData.ph = x * 1.7 + z * 2.3;
  return f;
}
const ss = (a, b, t) => { const k = Math.min(1, Math.max(0, (t - a) / (b - a))); return k * k * (3 - 2 * k); };
function rng(seed) { let s = (seed * 9301 + 49297) % 233280 || 1; return () => (s = (s * 9301 + 49297) % 233280) / 233280; }

export async function buildSet(THREE, scene, opts = {}, kit) {
  const base = kit('plain', {});
  const g = base.group;
  const points = { ...(base.points || {}) };
  const dyn = { flames: [], awnings: [], lanterns: [], cloths: [], cities: [] };

  // ================= FIELD (0,0) =================
  const F = new THREE.Group(); g.add(F);
  F.add(box(THREE, 60, .08, 70, '#232a38', '#171c26', 0, -.02, -4, 0, .005));                 // night ground
  for (let i = 0; i < 14; i++) { const r = rng(100 + i);                                    // rocks + dry tufts
    F.add(box(THREE, .3 + r() * .5, .18 + r() * .2, .3 + r() * .4, '#39404e', '#262b36', -9 + r() * 18, .08, 6 - r() * 26, r() * 2, .012)); }
  // Jimo's wall at the +Z end: long stone run, battlements, three dark openings, torches
  F.add(box(THREE, 34, 5.4, 1.2, '#5d6066', '#40434a', 0, 2.7, 14, 0, .015));
  for (let i = 0; i < 15; i++) F.add(box(THREE, 1.1, .8, 1.2, '#565a60', '#3a3d42', -15.4 + i * 2.2, 5.8, 14, 0, .012));
  [-4.5, 0, 4.5].forEach(ox => F.add(box(THREE, 1.7, 2.6, .3, '#0a0d13', '#06080c', ox, 1.3, 13.32, 0, .01)));  // the openings (dark)
  [-3.4, 3.4].forEach(tx => {                                                                // wall torches (practicals)
    F.add(box(THREE, .07, 1.1, .07, '#4c3823', '#33250f', tx, 1.9, 13.2, 0, .01));
    const fl = flame(THREE, tx, 2.5, 13.2, .9); F.add(fl); dyn.flames.push(fl);
  });
  // the enemy camp at the far -Z end (25 D+): tent silhouettes + glow (practicals)
  // (env-three: the tent boxes are wrapped in fieldCampPreviz so the field GLB can
  // replace them on load — glow bulbs below stay in F and are never hidden)
  const fieldCampPreviz = new THREE.Group(); F.add(fieldCampPreviz);
  [[-6, -27], [-2.5, -29], [1.5, -27.5], [5, -29.5], [-4, -31.5], [3, -32], [0, -34]].forEach(([tx, tz], i) => {
    fieldCampPreviz.add(box(THREE, 2.2, 1.5, 1.9, '#3d4149', '#282c33', tx, .75, tz, i * .4, .012));
    fieldCampPreviz.add(box(THREE, 2.4, .5, 2.1, '#33373f', '#21252c', tx, 1.7, tz, i * .4, .01));
  });
  [-3, 1, 4.5].forEach((bx, i) => { F.add(bulb(THREE, .17, 0xffa03a, bx, 1.1, -27.8 - i)); dyn['campGlow' + i] = bx; });
  const dawnF = bulb(THREE, 1.6, 0xffc978, 0, -2, -38); F.add(dawnF); dyn.dawnF = dawnF;      // dawn sun, rises in update

  // ================= WALLTOP (400,0) =================
  const W = new THREE.Group(); W.position.set(400, 0, 0); g.add(W);
  W.add(box(THREE, 34, .3, 7, '#5d6066', '#40434a', 0, -.12, 1.5, 0, .01));                   // the wall-top floor (34 wide: crosses the seg-2 frame edge to edge)
  W.add(box(THREE, 34, 1.05, .5, '#565a60', '#3a3d42', 0, .55, -1.6, 0, .015));               // parapet (outer, -Z)
  for (let i = 0; i < 16; i++) W.add(box(THREE, 1.1, .6, .5, '#5d6066', '#40434a', -16.5 + i * 2.2, 1.35, -1.6, 0, .012));
  W.add(box(THREE, 34, .9, .4, '#4c4f55', '#33363b', 0, .45, 4.6, 0, .012));                  // inner rail (+Z)
  W.add(box(THREE, 34, 6.6, 2.6, '#54575e', '#3c3f45', 0, -3.3, -1.2, 0, .015));              // the WALL BODY: floor down to the sprawl ground (-6.4) — without it the walltop slab floated over a sky void in every outside view (segs 2, 12c)
  // Jimo rooftops behind the wall (+Z, seen above the parapet from outside in seg 2):
  // dark bodies with lighter roof slabs, bases sunk so nothing floats; tops ≤2.6 so the
  // seg-12c sun ray (≥2.98 over local z +10) clears them — no line crosses the sun disc
  [[-11, 10.5, 2.6], [-7.5, 12, 2.2], [-3.5, 10, 2.4], [.5, 11.5, 2.0], [4.5, 10, 2.5], [8, 12, 2.15], [11.5, 10.5, 2.45]].forEach(([rx, rz, rh]) => {
    W.add(box(THREE, 2.6, rh + 1.5, 2.2, '#2c3038', '#1d2026', rx, (rh - 1.5) / 2, rz, 0, .008));
    W.add(box(THREE, 3.0, .22, 2.6, '#4c4f55', '#33363b', rx, rh + .08, rz, 0, .01));
  });
  [-3.6, 3.6].forEach(bx => {                                                                // braziers (practicals)
    W.add(box(THREE, .5, .7, .5, '#2e2c2c', '#1a1818', bx, .35, .6, 0, .015));
    const fl = flame(THREE, bx, .75, .6, 1.25); W.add(fl); dyn.flames.push(fl);
  });
  // siege sprawl below/outside: ground far below, tent + banner rows to the horizon
  // (env-three: all sprawl tent/banner previz is wrapped in sprawlPreviz so the
  // walltop GLB can replace it on load — ground, fire-glow bulbs, braziers, birds
  // and the dawn bulb stay in W and are never hidden)
  const sprawlPreviz = new THREE.Group(); W.add(sprawlPreviz);
  W.add(box(THREE, 90, .1, 60, '#1d232f', '#12161f', 0, -6.4, -32, 0, .004));
  for (let i = 0; i < 26; i++) { const r = rng(300 + i);
    sprawlPreviz.add(box(THREE, 1.8, 1.2, 1.6, '#3d4149', '#282c33', -30 + r() * 60, -5.7, -9 - r() * 34, r() * 2, .008)); }
  for (let i = 0; i < 12; i++) { const r = rng(400 + i);                                      // sprawl banner poles + cloth
    const bx = -28 + r() * 56, bz = -10 - r() * 26;
    sprawlPreviz.add(box(THREE, .06, 2.6, .06, '#3a2c1c', '#241a10', bx, -5.1, bz, 0, .006));
    const cl = box(THREE, .9, .8, .03, '#2e3d55', '#1e2839', bx + .45, -4.2, bz, 0, .005);
    sprawlPreviz.add(cl); dyn.cloths.push({ m: cl, ph: i * 1.3 });
  }
  for (let i = 0; i < 9; i++) W.add(bulb(THREE, .13, 0xffa03a, -24 + i * 6, -5.2, -13 - (i % 3) * 7));  // sprawl fire glows
  // round-2 density for the seg-2 outside wide: a second sprawl band (tents + a banner
  // row + campfire points) in local z -18..-38, the near/mid ground that camera reads
  for (let i = 0; i < 12; i++) { const r = rng(500 + i);
    const tx = -26 + r() * 52, tz = -19 - r() * 18;
    sprawlPreviz.add(box(THREE, 2.0, 1.25, 1.7, '#43464e', '#2d3038', tx, -5.75, tz, r() * 2, .008));
    sprawlPreviz.add(box(THREE, 2.2, .45, 1.9, '#383b42', '#24262c', tx, -5.0, tz, r() * 2, .007));
  }
  for (let i = 0; i < 8; i++) { const bx = -24.5 + i * 7;                                   // banner row at z -24
    sprawlPreviz.add(box(THREE, .07, 2.9, .07, '#3a2c1c', '#241a10', bx, -4.95, -24, 0, .006));
    const cl = box(THREE, 1.0, .85, .03, '#2e3d55', '#1e2839', bx + .5, -4.05, -24, 0, .005);
    sprawlPreviz.add(cl); dyn.cloths.push({ m: cl, ph: 20 + i * 1.1 });
  }
  for (let i = 0; i < 7; i++) W.add(bulb(THREE, .15, 0xffa03a, -21 + i * 7, -5.5, -29 - (i % 2) * 5));  // mid-ground campfires
  const birds = new THREE.Group(); W.add(birds); dyn.birds = birds;                          // birds flee the wall (seg 2)
  for (let i = 0; i < 4; i++) {
    const b = new THREE.Group();
    [-1, 1].forEach(sd => { const wing = box(THREE, .5, .03, .16, '#14161c', '#0c0e12', sd * .26, 0, 0, sd * .3, .004); b.add(wing); });
    b.userData.i = i; birds.add(b);
  }
  // sunrise disc: round-2 moved to local (-11,·,+30) — on the seg-12c camera's view axis
  // above/behind Tian Dan, so the disc is clean in frame (at the old -Z spot the pen
  // place's tree branch, 400 D away, crossed it as a thin black line — build-final f_63_2)
  const dawnW = bulb(THREE, 1.9, 0xffc978, 7, -1, 30); W.add(dawnW); dyn.dawnW = dawnW;

  // ================= ENEMYCAMP (-400,0) =================
  const E = new THREE.Group(); E.position.set(-400, 0, 0); g.add(E);
  E.add(box(THREE, 40, .08, 44, '#252b38', '#181d27', 0, -.02, -4, 0, .005));
  // tent rows receding to -Z (the far end, 25 D+)
  [[-5.5, -4], [5.5, -4.5], [-6, -9], [6, -9.5], [-5, -14], [5.5, -14.5], [-6.5, -19], [6.5, -19.5], [-4, -24], [4.5, -25], [0, -29]].forEach(([tx, tz], i) => {
    E.add(box(THREE, 2.6, .06, 2.2, '#57534a', '#3d3a33', tx, 1.32, tz, i * .35, .01));
    E.add(box(THREE, 2.7, 1.3, 2.2, '#6b665b', '#4c483f', tx, .65, tz, i * .35, .012));
  });
  // central campfire (practical): logs, stones, flame
  for (let i = 0; i < 6; i++) { const a = i * 1.05;
    E.add(box(THREE, .16, .16, .16, '#4c4f55', '#33363b', Math.cos(a) * .55, .07, .5 + Math.sin(a) * .55, 0, .01)); }
  [[.3, .2], [-.28, .35], [.1, -.3]].forEach(([lx, lz]) => {
    const log = part(THREE, new THREE.CylinderGeometry(.06, .06, .8, 8), flat('#5d3a1e', '#3c2410'), .012);
    log.position.set(lx, .12, .5 + lz); log.rotation.z = Math.PI / 2; log.rotation.y = lx * 2; E.add(log);
  });
  const campFlame = flame(THREE, 0, .15, .5, 1.6); E.add(campFlame); dyn.flames.push(campFlame);
  E.add(bulb(THREE, .2, 0xffa03a, 0, .8, .5));
  // hanging lanterns on posts (practicals 2 and 3)
  [[-4.5, -3], [4.5, -3.5]].forEach(([lx, lz]) => {
    E.add(box(THREE, .07, 2.2, .07, '#4c3823', '#33250f', lx, 1.1, lz, 0, .01));
    E.add(box(THREE, .34, .4, .34, '#8a5f22', '#5f3f14', lx, 1.95, lz, 0, .012));
    E.add(bulb(THREE, .11, 0xffc26a, lx, 1.92, lz));
  });
  // the COMMAND TENT (distinct, larger, at the back-left): its fall at 57.44 is a set state
  const cmd = new THREE.Group(); cmd.position.set(-4.6, 0, -6.5); E.add(cmd); dyn.cmdTent = cmd;
  cmd.add(box(THREE, 4.4, .07, 3.4, '#7d2f26', '#571f18', 0, 2.15, 0, 0, .012));
  cmd.add(box(THREE, 4.5, 2.1, 3.4, '#8d3a2c', '#652619', 0, 1.05, 0, 0, .014));
  cmd.add(box(THREE, .09, 3.1, .09, '#4c3823', '#33250f', 0, 1.55, 1.9, 0, .01));
  cmd.add(bulb(THREE, .13, 0xffc26a, 0, 2.2, 1.9));
  // env-fix1 dressing (inside cmd so the 57.44 fall carries it all):
  // (a) gabled roof — two sloped thin boxes meeting at a ridge along x at y ~2.55
  //     (flat slab above stays as the ceiling under them)
  [[1, .22], [-1, -.22]].forEach(([sd, rx]) => {
    const panel = box(THREE, 4.7, .07, 1.95, '#7d2f26', '#571f18', 0, 2.35, sd * .88, 0, .012);
    panel.rotation.x = rx; cmd.add(panel);
  });
  // (b) ridge pole along x at the ridge
  { const ridge = part(THREE, new THREE.CylinderGeometry(.05, .05, 4.9, 8), flat('#4c3823', '#33250f'), .01);
    ridge.position.set(0, 2.58, 0); ridge.rotation.z = Math.PI / 2; cmd.add(ridge); }
  // (c) 4 corner poles at the body corners, ground to eaves
  [[-2.25, -1.7], [2.25, -1.7], [-2.25, 1.7], [2.25, 1.7]].forEach(([px, pz]) => {
    const pole = part(THREE, new THREE.CylinderGeometry(.05, .05, 2.15, 8), flat('#4c3823', '#33250f'), .01);
    pole.position.set(px, 1.07, pz); cmd.add(pole);
  });
  // (d) entrance flap on the +Z face, slightly proud, angled a few degrees
  { const flap = box(THREE, .9, 1.4, .05, '#652619', '#471a10', .55, .72, 1.74, 0, .012);
    flap.rotation.x = .07; flap.rotation.y = -.06; cmd.add(flap); }
  // (e) guy ropes from the roof's back (-Z) corners to the ground behind
  [[-1], [1]].forEach(([sd]) => {
    const from = new THREE.Vector3(sd * 2.2, 2.3, -1.65), to = new THREE.Vector3(sd * 2.7, 0, -3.3);
    const dir = to.clone().sub(from), len = dir.length();
    const rope = part(THREE, new THREE.CylinderGeometry(.025, .025, len, 6), flat('#8a6f47', '#5f4a2c'), .006);
    rope.position.copy(from).add(to).multiplyScalar(.5);
    rope.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
    cmd.add(rope);
  });
  // weapon rack + crates + a dropped shield (seg 3 dressing, seg 10 foreground)
  E.add(box(THREE, 1.6, .08, .3, '#5d4226', '#3f2c16', 2.2, .8, 1.8, .4, .012));
  [-.6, 0, .6].forEach(dx => { const sp = box(THREE, .07, 1.5, .07, '#7a7d82', '#55585c', 2.2 + dx * .8, .75, 1.8 - dx * .32, .4, .01); E.add(sp); });
  E.add(box(THREE, .8, .8, .06, '#6e4526', '#4a2d14', 1.4, .4, 2.6, .8, .015));

  // ================= MARKET (0,-400) =================
  const M = new THREE.Group(); M.position.set(0, 0, -400); g.add(M);
  M.add(box(THREE, 30, .08, 44, '#2a2c33', '#1c1e24', 0, -.02, -4, 0, .005));
  function stall(x, z, ry, main) {
    const s = new THREE.Group(); s.position.set(x, 0, z); s.rotation.y = ry; M.add(s);
    s.add(box(THREE, 2.4, .08, 1.1, '#6e5136', '#4c3823', 0, .95, 0, 0, .015));               // counter
    s.add(box(THREE, 2.2, .9, .9, '#5d4226', '#3f2c16', 0, .45, 0, 0, .012));
    [[-1.1, -.45], [1.1, -.45], [-1.1, .45], [1.1, .45]].forEach(([px, pz]) =>
      s.add(box(THREE, .07, 2.5, .07, '#4c3823', '#33250f', px, 1.25, pz, 0, .01)));
    const awn = new THREE.Group(); awn.position.set(0, 2.52, 0); s.add(awn);
    const cloth = box(THREE, 2.7, .05, 1.7, main ? '#8d3a2c' : '#5d6242', main ? '#652619' : '#40442c', 0, 0, .1, 0, .012);
    cloth.rotation.x = -.16; awn.add(cloth); dyn.awnings.push({ m: awn, ph: x + z });
    for (let i = 0; i < 3; i++) s.add(box(THREE, .42, .3, .42, ['#a8874f', '#7d5f36', '#8a4f3a'][i], '#5d4a2c', -.7 + i * .65, 1.15, .1, i * .4, .01));
    return s;
  }
  stall(-2.3, 1.6, .12, true);                                                                // TIAN DAN's stall — LEFT of frame
  stall(2.6, .8, -.15, false); stall(-2.8, -3.4, .1, false); stall(2.9, -4.2, -.08, false);
  stall(-2.5, -8.5, .12, false); stall(2.7, -9.5, -.1, false);                                // the street recedes 25 D+
  stall(-2.6, -14, .1, false); stall(2.8, -15, -.12, false); stall(0, -20, 0, false);
  [[-2, 2], [2.4, -1], [0, -6], [-1.8, -11], [1.5, -16]].forEach(([lx, lz], i) => {           // hanging lanterns (practicals)
    const lg = new THREE.Group(); lg.position.set(lx, 3.1, lz); M.add(lg);
    lg.add(box(THREE, .03, .5, .03, '#2c2c30', '#17171a', 0, -.2, 0, 0, 0));
    lg.add(box(THREE, .3, .36, .3, '#a87c2c', '#77571d', 0, -.62, 0, 0, .012));
    lg.add(bulb(THREE, .1, 0xffc26a, 0, -.64, 0));
    dyn.lanterns.push({ m: lg, ph: i * 1.7 });
  });
  [[3.6, 3.4], [-3.8, -1.5], [3.9, -6.5]].forEach(([cx, cz]) => {                             // crates + barrels dressing
    M.add(box(THREE, .62, .62, .62, '#7a5c38', '#573f22', cx, .31, cz, .3, .015));
    const bar = part(THREE, new THREE.CylinderGeometry(.3, .3, .85, 12), flat('#6e5136', '#4c3823'), .015);
    bar.position.set(cx - .8, .43, cz + .4); M.add(bar);
  });
  M.add(box(THREE, 1.4, 2.2, .1, '#4c4f55', '#33363b', 0, 3.4, -24, 0, .01));                  // the far gate arch glow end
  M.add(bulb(THREE, .16, 0xffc26a, -.8, 2.6, -23.8)); M.add(bulb(THREE, .16, 0xffc26a, .8, 2.6, -23.8));

  // ================= PEN (400,-400) =================
  const P = new THREE.Group(); P.position.set(400, 0, -400); g.add(P);
  P.add(box(THREE, 34, .08, 36, '#272b33', '#191d24', 0, -.02, -3, 0, .005));
  // (hunyuan-integration: rails/trough/hay are wrapped in penPreviz so the
  // adapted Hunyuan pen GLB — now assets/set/pen.glb — can hide them, exactly
  // like sprawlPreviz/fieldCampPreviz; ground, lanterns and the far hill stay)
  const penPreviz = new THREE.Group(); P.add(penPreviz);
  function rail(x0, z0, x1, z1) {
    const dx = x1 - x0, dz = z1 - z0, len = Math.hypot(dx, dz), ry = Math.atan2(dx, dz);
    [.55, 1.0].forEach(h => penPreviz.add(box(THREE, .07, .07, len, '#6e5136', '#4c3823', (x0 + x1) / 2, h, (z0 + z1) / 2, ry, .01)));
    const n = Math.max(2, Math.round(len / 1.6));
    for (let i = 0; i <= n; i++) penPreviz.add(box(THREE, .09, 1.25, .09, '#5d4226', '#3f2c16', x0 + dx * i / n, .62, z0 + dz * i / n, 0, .012));
  }
  rail(-4.5, 2.5, 4.5, 2.5); rail(-4.5, 2.5, -4.5, -5.5); rail(4.5, 2.5, 4.5, -5.5); rail(-4.5, -5.5, 1.2, -5.5); rail(3.4, -5.5, 4.5, -5.5); // gate gap x 1.2..3.4 at the back
  penPreviz.add(box(THREE, 2.0, .25, .6, '#5d4a2c', '#40331f', -3, .13, -.5, .3, .012));      // trough
  [[2.8, 1.2], [-1.5, -3.8], [3.6, -3.2]].forEach(([hx, hz]) => {                             // hay piles
    const hay = part(THREE, new THREE.ConeGeometry(.7, .8, 10), flat('#a8874f', '#77571d'), .015);
    hay.position.set(hx, .4, hz); penPreviz.add(hay);
  });
  P.add(box(THREE, .07, 2.3, .07, '#4c3823', '#33250f', -3.8, 1.15, 1.8, 0, .01));             // lantern post (practical)
  P.add(box(THREE, .32, .38, .32, '#8a5f22', '#5f3f14', -3.8, 2.1, 1.8, 0, .012));
  P.add(bulb(THREE, .1, 0xffc26a, -3.8, 2.08, 1.8));
  P.add(box(THREE, .07, 2.3, .07, '#4c3823', '#33250f', 4.2, 1.15, -4.6, 0, .01));
  P.add(bulb(THREE, .09, 0xffc26a, 4.2, 2.2, -4.6));
  // far end: LOW hill silhouette + a bare tree, 25 D+ behind the pen (kept low: at its
  // full 3.5 height this hill read as a black bar on the horizon of every walltop shot
  // and across the seg-12c sunrise, 400 D away in the walltop place)
  P.add(box(THREE, 40, 1.2, 1, '#1a2029', '#11151d', 0, 0, -19, 0, .004));
  P.add(box(THREE, .22, 1.8, .22, '#241a10', '#17100a', -7, .9, -16, 0, .008));
  P.add(box(THREE, 1.8, .14, .14, '#241a10', '#17100a', -6.4, 1.7, -16, .5, .006));

  // ================= WALLBASE (-400,-400) =================
  const B = new THREE.Group(); B.position.set(-400, 0, -400); g.add(B);
  B.add(box(THREE, 30, .08, 30, '#242932', '#171b23', 0, -.02, -3, 0, .005));
  B.add(box(THREE, 26, 8, 1.4, '#5d6066', '#40434a', 0, 4, 5.6, 0, .015));                     // THE WALL face (+Z)
  for (let i = 0; i < 11; i++) B.add(box(THREE, 1.2, .9, 1.4, '#565a60', '#3a3d42', -11.5 + i * 2.3, 8.4, 5.6, 0, .012));
  dyn.rubble = [];
  [-3.2, 0, 3.2].forEach((ox, i) => {                                                         // opening mouths + rubble (state: dug)
    B.add(box(THREE, 1.8, 2.7, .3, '#0a0d13', '#06080c', ox, 1.35, 4.82, 0, .01));
    const rub = new THREE.Group(); rub.position.set(ox, 0, 4.1); B.add(rub); dyn.rubble.push(rub);
    for (let k = 0; k < 5; k++) { const r = rng(700 + i * 10 + k);
      rub.add(box(THREE, .3 + r() * .35, .2 + r() * .25, .3 + r() * .3, '#4c4f55', '#33363b', (r() - .5) * 1.6, .1, (r() - .5) * .8, r() * 2, .012)); }
    rub.scale.setScalar(.15);
  });
  [[-3.6, 2.4], [3.6, 2.4]].forEach(([tx, tz]) => {                                           // torch stands (practicals)
    B.add(box(THREE, .08, 1.9, .08, '#4c3823', '#33250f', tx, .95, tz, 0, .01));
    const fl = flame(THREE, tx, 2.0, tz, 1.1); B.add(fl); dyn.flames.push(fl);
  });
  [[-5.5, .5], [5.8, -.8], [-5.2, -3.5]].forEach(([cx, cz]) => {                              // tools, crates, rope
    B.add(box(THREE, .66, .66, .66, '#7a5c38', '#573f22', cx, .33, cz, .25, .015));
  });
  const rope = part(THREE, new THREE.TorusGeometry(.34, .07, 8, 16), flat('#a8874f', '#77571d'), .015);
  rope.position.set(5.4, .08, 1.8); rope.rotation.x = Math.PI / 2; B.add(rope);
  B.add(box(THREE, 20, 2.2, .8, '#1a2029', '#11151d', 0, 1.1, -14, 0, .004));                  // rooftops silhouette, far end

  // ================= QIMAP (800,0) =================
  const Q = new THREE.Group(); Q.position.set(800, 0, 0); g.add(Q);
  Q.add(box(THREE, 46, .06, 46, '#11131c', '#0b0d13', 0, -.01, 0, 0, .004));
  const stripM = new THREE.MeshBasicMaterial({ color: 0x3f7d8c });
  function strip(points) {                                                                    // an inlaid light strip along a path
    for (let i = 0; i < points.length - 1; i++) {
      const [x0, z0] = points[i], [x1, z1] = points[i + 1];
      const len = Math.hypot(x1 - x0, z1 - z0), ry = Math.atan2(x1 - x0, z1 - z0);
      const m = new THREE.Mesh(new THREE.BoxGeometry(.09, .02, len), stripM);
      m.position.set((x0 + x1) / 2, .025, (z0 + z1) / 2); m.rotation.y = ry; m.frustumCulled = false; Q.add(m);
    }
  }
  strip([[-7, -8], [-4.5, -5.5], [-4.8, -2], [-2.5, .5], [-3.5, 3.5], [-1, 6], [2, 7.5], [5, 6.5], [7, 3.5], [6, .5], [7.5, -2.5], [5.5, -5.5], [2.5, -7], [-1, -6.2], [-4, -7.5], [-7, -8]]); // coastline loop
  strip([[-4.8, -2], [-2, -1.2], [.5, -1.8], [3, -.8], [6, .5]]);                             // the river
  strip([[-2.5, .5], [-.5, 2.2], [1.5, 3.8], [5, 6.5]]);
  { const r = rng(2027);                                                                      // 70 city lights, seeded order
    const order = [...Array(70).keys()];
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    const rank = new Array(70); order.forEach((city, k) => rank[city] = k);
    for (let i = 0; i < 70; i++) {
      let cx, cz, ok = false;
      while (!ok) { cx = -6.6 + r() * 13.6; cz = -7.4 + r() * 14.4; ok = (cx * cx) / 52 + (cz * cz) / 62 < 1; }
      const c = bulb(THREE, .14, 0xffb03a, cx, .1, cz);
      const halo = new THREE.Mesh(new THREE.SphereGeometry(.3, 10, 8),
        new THREE.MeshBasicMaterial({ color: 0xff9a3a, transparent: true, opacity: .3, depthWrite: false }));
      halo.position.set(cx, .1, cz); halo.frustumCulled = false; Q.add(halo);
      c.visible = halo.visible = false; Q.add(c);
      dyn.cities.push({ c, halo, rank: rank[i] });
    }
  }

  // ================= BLENDER DRESSING (Environment overhaul) =================
  // assets/set/<place>.glb, built in Blender (see ENV_CONTRACT.md): modelled sets in
  // place-local coords, flat palette by material name. Loaded with the engine's
  // readGlb; any missing/unreadable file simply leaves the procedural set above
  // standing, so the film always renders.
  const GLB_PALETTE = {
    stone: ['#6a6e74', '#4a4d52'], stone_dark: ['#3f434a', '#2a2d33'],
    wood: ['#6e5136', '#4c3823'], wood_dark: ['#4c3519', '#33230e'], wood_pale: ['#8a6a42', '#5f4726'],
    canvas_tent: ['#7a7264', '#57534a'], canvas_red: ['#8d3a2c', '#652619'], cloth_blue: ['#33507a', '#22334e'],
    iron: ['#3a3d42', '#24262a'], brass: ['#a87c2c', '#77571d'], straw: ['#b08d4f', '#7d6234'],
    rope: ['#8a6f47', '#5f4a2c'], tile_roof: ['#4a5a6e', '#333f4f'], plaster: ['#9a8f7c', '#6e6656'],
    ground_dark: ['#232830', '#161a21'], paper: ['#e8e2d2', '#c9c2ae'],
    flame: ['#ff8a3a', '#d6540f'],
  };
  try {
    const { readGlb } = await import('../world/look/glb.js');
    const GLB_PLACES = [['field', 0, 0], ['walltop', 400, 0], ['enemycamp', -400, 0], ['market', 0, -400],
      ['pen', 400, -400], ['wallbase', -400, -400], ['qimap', 800, 0]];
    const glbLoaded = {};
    for (const [place, ox, oz] of GLB_PLACES) {
      const data = await readGlb(THREE, new URL(`../assets/set/${place}.glb`, import.meta.url));
      if (!data || !data.roots) continue;
      glbLoaded[place] = true;
      for (const root of data.roots) {
        const grp = new THREE.Group();
        root.matrix.decompose(grp.position, grp.quaternion, grp.scale);
        for (const prim of root.prims) {
          const pal = GLB_PALETTE[prim.material] || ['#7a7d82', '#55585c'];
          const mesh = new THREE.Mesh(prim.geometry, flat(pal[0], pal[1]));
          mesh.frustumCulled = false;
          grp.add(mesh);
        }
        grp.position.x += ox; grp.position.z += oz;
        g.add(grp);
      }
    }
    // conditional hides — ONLY where that place's GLB actually landed
    if (glbLoaded.walltop) sprawlPreviz.visible = false;
    if (glbLoaded.field) fieldCampPreviz.visible = false;
    if (glbLoaded.pen) penPreviz.visible = false;
    // hunyuan backdrop (ADDITIVE, walltop only): the palette-repainted
    // Hunyuan city wall (blender/repaint_hunyuan.py) as a distant second
    // wall+city silhouette BEHIND the procedural city — the city houses sit
    // at z +10..+16, this is centred at z +34, scaled x26 (native bbox
    // 1.12 wide x 0.40 high -> ~29 wide x ~10.4 high, base at y 0).
    // Nothing existing is hidden or altered by this layer.
    try {
      const hw = await readGlb(THREE, new URL('../assets/set/hunyuan-wall.glb', import.meta.url));
      if (hw && hw.roots) for (const root of hw.roots) {
        const grp = new THREE.Group();
        root.matrix.decompose(grp.position, grp.quaternion, grp.scale);
        for (const prim of root.prims) {
          const pal = GLB_PALETTE[prim.material] || ['#7a7d82', '#55585c'];
          const mesh = new THREE.Mesh(prim.geometry, flat(pal[0], pal[1]));
          mesh.frustumCulled = false;
          grp.add(mesh);
        }
        grp.scale.multiplyScalar(26);
        grp.position.set(400.79, 0.01, 34.81);
        g.add(grp);
      }
    } catch (e) { /* hunyuan backdrop unavailable: the procedural city stands */ }
    // hunyuan-integration layers (user decision B, 2026-11-27): palette-adapted
    // Hunyuan pieces (blender/adapt_hunyuan.py), each integrated ONLY for the
    // layer it actually covers — same additive pattern as hunyuan-wall above.
    // (a) enemycamp FAR CAMP: the camp diorama (tents ring + watchtower) as the
    //     camp's far depth beyond the palisade (local z -44, scale 18). The
    //     piece's base-plate TOP sits at native z 0.075 (= 1.35 at scale 18),
    //     so the group is sunk -1.38 to land that surface at ground level, and
    //     the plate-top faces in hunyuan-camp.glb were remapped to ground_dark
    //     (blender bake) — two critic rounds found the plate reading as a
    //     raised tan platform before this. Nothing existing is hidden.
    try {
      const hc = await readGlb(THREE, new URL('../assets/set/hunyuan-camp.glb', import.meta.url));
      if (hc && hc.roots) for (const root of hc.roots) {
        const grp = new THREE.Group();
        root.matrix.decompose(grp.position, grp.quaternion, grp.scale);
        for (const prim of root.prims) {
          const pal = GLB_PALETTE[prim.material] || ['#7a7d82', '#55585c'];
          const mesh = new THREE.Mesh(prim.geometry, flat(pal[0], pal[1]));
          mesh.frustumCulled = false;
          grp.add(mesh);
        }
        grp.scale.multiplyScalar(18);
        grp.position.set(-400, -1.38, -44);
        g.add(grp);
      }
    } catch (e) { /* hunyuan camp layer unavailable: the Blender camp stands */ }
    // (b) market HERO STALL — NOT SHIPPED: the market piece is a single
    //     elaborate stall, not a street. It was integrated as a hero stall on
    //     the street's right side (tried at local z -6.3, then z -1.7) and
    //     rejected by this round's fresh critic: the film's market cameras
    //     stay tight on Tian Dan's story stall, so the piece never enters a
    //     frame as more than an edge sliver — it has no honest slot in this
    //     coverage. The block was removed; the market stands exactly as the
    //     Environment pass verified it. See lessons/hunyuan-integration.md.
    // (c) walltop FAR CITY — NOT SHIPPED: the city-street facade was integrated
    //     here as a third city layer (z +54) and REJECTED by this round's fresh
    //     critic (scale inversion + duplicated gate + a foreign dark-blue wall
    //     mass at frame right in the 12c close/final frames). The layer was
    //     removed; walltop keeps the Environment-verified hunyuan-wall
    //     backdrop only. See lessons/hunyuan-integration.md.
  } catch (e) { /* Blender dressing unavailable: the procedural set stands on its own */ }

  let rig; try { rig = createLightRig(THREE, PLACES, {}); } catch { rig = undefined; }
  const look = (rig && opts && opts.post) ? createPost(THREE, rig, opts.post) : undefined;
  if (look && opts && opts.post && opts.post.shade) { try { look.shading = createRigShade(THREE, rig, opts.post.shade); } catch (e) { /* shading optional */ } }
  return {
    ...base, group: g, rig, look,
    marks: { ...(base.marks || {}),
      field: [0, 0], walltop: [400, 0], enemycamp: [-400, 0], market: [0, -400],
      pen: [400, -400], wallbase: [-400, -400], qimap: [800, 0] },
    points,
    update(t) {
      base.update?.(t); rig?.update(t);
      for (const f of dyn.flames) { const ph = f.userData.ph || 0;
        f.scale.y = 1 + .14 * Math.sin(t * 9.3 + ph) * Math.sin(t * 3.1 + ph); f.rotation.z = .04 * Math.sin(t * 7.7 + ph); }
      for (const a of dyn.awnings) a.m.rotation.x = .03 * Math.sin(t * 1.9 + a.ph);
      for (const l of dyn.lanterns) l.m.rotation.z = .05 * Math.sin(t * 1.4 + l.ph);
      for (const c of dyn.cloths) c.m.rotation.y = .18 * Math.sin(t * 2.2 + c.ph);
      if (dyn.birds) for (const b of dyn.birds.children) {                                    // seg 2: birds flee the wall top
        const i = b.userData.i, u = Math.min(1, Math.max(0, (t - 7.2 - i * .5) / 3.4));
        b.position.set(-3 + i * 1.6 + u * 16, 2.2 + u * 3.4 + Math.sin(t * 9 + i) * .08, -1 - u * 9);
        b.rotation.y = -.5 - u * .4; b.visible = t > 7 && t < 12.5;
      }
      if (dyn.cmdTent) { const k = ss(57.44, 58.3, t);                                        // 11a: the command tent falls
        dyn.cmdTent.rotation.z = k * .5; dyn.cmdTent.scale.y = 1 - k * .45; dyn.cmdTent.position.y = -k * .3; }
      if (dyn.rubble) dyn.rubble.forEach((r, i) => { const k = ss(35.66 + i * .18, 36.6 + i * .18, t);
        r.scale.setScalar(.15 + k * .85); });
      // the dawn suns stay hidden until the dawn state (59.55): before that the walltop
      // dawn bulb read as a giant orange disc floating over the seg-2 sprawl
      if (dyn.dawnF) { const k = ss(59.55, 63.4, t); dyn.dawnF.visible = t > 59.5; dyn.dawnF.position.y = -2 + k * 3.4; dyn.dawnF.material.opacity = 1; }
      if (dyn.dawnW) { const k = ss(59.55, 63.4, t); dyn.dawnW.visible = t > 59.5; dyn.dawnW.position.y = -1 + k * 5.6; }
      // (the pen place (400,-400) sits dead ahead of every walltop camera; its horizon
      // bar is fixed at the source by lowering the pen's far hill + tree — see PEN above)
      for (const city of dyn.cities) {                                                        // 11b: 70 cities relight, 59.9–62.6
        const on = t > 59.9 + (city.rank / 70) * 2.7;
        city.c.visible = city.halo.visible = on;
        if (on) { const pop = Math.min(1, (t - 59.9 - (city.rank / 70) * 2.7) * 6);
          city.c.scale.setScalar(.4 + pop * .6); city.halo.scale.setScalar(.4 + pop * .6); }
      }
    },
  };
}
