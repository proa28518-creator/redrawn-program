# Hunyuan prompts v5 — authored by Qwen4-Max, verified by the lead (2026-11-28 07:56)

عربي reassigned prompt writing to Qwen4-Max ("مش عرفين تكتبوها ابعتيها ال qwan 4 max").
Lead verification: character counts recounted exactly — P1 495/500, P2 465/500 (Qwen's
stated counts were accurate). Every contract element present. Two Qwen design choices
accepted by the lead: (1) the lobby arch sits at the back wall's right end so it does not
punch a hole in the key grid (the gag wall stays unmissable); (2) the street adds a cobbled
road beyond the kerb and open sky — harmless dressing inside the street zone.
Use VERBATIM. Download the PANORAMA variant in-session. Qwen chat:
chat.qwen.ai/c/cef5f921-b5ff-4b98-9916-bc67bc8cd6bf

## PROMPT 1 — LOBBY (495 chars)
Cartoon hotel lobby interior: enclosed room with walls, ceiling, floor. One long straight wooden reception counter stands mid-room. Directly behind it, the entire back wall is covered floor to ceiling with dense rows of small brass key hooks and hanging keys. Wide arched doorway at that wall's right end. One brass lantern hangs high near the ceiling. Deep warm wood panelled walls, red carpet floor, teal and burgundy jewel-tone accents, cosy lamplit gold light, no people, no text, no letters

## PROMPT 2 — STREET (465 chars)
Cartoon night street scene, an open outdoor set with no buildings. In the foreground, a straight row of four oversized chunky vintage street lamps, big and prominent: very thick posts and large glowing amber lantern heads, evenly spaced on a wide stone pavement strip. The strip has a clear raised kerb edge, with a cobbled road beyond the kerb and open night sky above. Warm lamplit gold tones, cosy amber glow pooling on the stones, no people, no text, no letters
