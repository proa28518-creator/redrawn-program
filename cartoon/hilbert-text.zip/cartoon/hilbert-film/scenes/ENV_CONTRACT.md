# ENV CONTRACT — فندق هيلبرت / Hilbert's Infinite Hotel (Environment overhaul)

The same film, real sets. Characters, acting, shots, voice, captions DO NOT CHANGE.
Method = the proven Tian Dan template: Blender 5.2.5 builds place-local GLBs into
`assets/set/`, `scenes/set.js` loads them with the engine's `readGlb` and a
material-name palette (the engine reads geometry + material names only — no
textures), everything falls back to the previz if a file is missing.
Palette direction is BINDING (`LOOK-DIRECTION.md`, user order 02:18): VIVID —
lamplit golds, deep warm wood, jewel-tone door paints (deep teal, burgundy, plum,
forest); not muted, not grey. No frame below 40/255 mean luminance because of the set.

Coordinates: three.js place-local (x east, y up, z toward camera/south).
Blender->glTF: three (x,y,z) = blender (x, z, -y); objects placed at blender
(x, -z, y), dims (w, d, h). Keep-clear: `blender/keep_clear.json` — binding.

## Shared material names (GLB palette — set.js maps these exact names)
wood, wood_dark, wood_pale, brass, iron, stone,
door_teal, door_burg, door_plum, door_forest (jewel door paints, cycled n%4),
wall_teal (deep teal wall panels), plaster_warm (vivid warm plaster),
carpet_red (runner/desk rug), cream (paper/cream insets),
lampglow (lit lamp glass — basic material, registered for flicker in set.js),
winlit (lit window panes — basic material),
bus_blue, bus_cream.
Use ONLY these names. Bevel boxes (0.02, 2 seg) — modelled read, no plain cubes;
vary sizes/rotations with a fixed seed, never a repeating pattern.

## SHIP ORDER (most-seen surfaces first)
1. corridor.glb — the spine: doors+lamps in 12 of 19 lines
2. lobby.glb — desk + key board + arch (frame 0's stakes)
3. front.glb — facade + street
4. bus.glb — separate roots `busbody` / `busdoor`, loaded into the animated bus group

## Per place — what it must become

### corridor (400,0) — lines 2,3,4,8,9,10,11,12,14,15,16,19. THE SPINE.
Layout contract (from Build set.js + film.js camera keys — DO NOT MOVE):
inner walls at x ±2.125, doors every 3 D at z = -2-(n-1)*3, odd doors LEFT
(x -2.12), even RIGHT; wall lamps at z .5-i*6.5 alternating sides; mouth wall
at z 5.2 with doorway gap x -0.95..0.95; far end z -63.5.
GLB delivers, place-local:
- Modelled doors n=1..21: wood_dark frame (2 posts + lintel, proud of wall),
  jewel-tone panel (n%4 cycle) with 2 inset mouldings + brass knob plate.
  Frames for hero doors 1/2/3 included (their panels are PROPS — GLB ships NO
  panel for n<=3); NO panels for n=5/7 (animated reveal panels stay procedural
  in set.js); panels for all other n.
- Wall cladding: wainscot (wood) + upper panels (wall_teal) segments between
  doors on both walls, skirting (wood_dark), cornice, ceiling beams every
  6.5 D + ceiling coffers. Runner carpet (carpet_red) with pale border strips.
- Modelled wall lamps at the previz lamp positions: iron bracket, brass shade,
  lampglow glass sphere (flicker-registered by set.js).
- Dressing at wall bases only (|x| >= 1.45): luggage stacks, shoe pairs,
  a serving trolley deep (z -30), picture frames on wall stretches.
- Door-1 lit doorway modelled (fault-4 / S10 fix on the set side): deep reveal
  jambs + threshold + architrave around door 1 (z -2, left wall) so the prop's
  lit plane sits inside modelled depth, not on a flat wall.
- Far end (z -62..-64): modelled end wall with an arched lampglow doorway +
  flanking lamps — warm haze glow, never a black void (previz glow plane stays).
- **S19 SIGHT-LINE (NAMED REQUIREMENT, Build critic r1 fault 4):** the closing
  camera (pos ~(401.5,2.7,-11.2) -> target (400,2.4,-0.7)) looks BACK toward
  the mouth (+Z) with the faces at z ~-0.6. Behind the faces the frame must
  contain: (a) the corridor lamp at z .5 (left wall) and the mouth lamps as
  VISIBLE lit fixtures; (b) a readable receding space through the mouth
  doorway — a modelled VESTIBULE extension z 5.4..15 (continuation walls,
  2 lamp pairs, warm lampglow end arch at z 15) so depth behind the faces
  reads 15 D+ with 2+ visible light sources, replacing the flat pale
  rectangle (the previz lit-doorway card) read. Vestibule keeps the guest/
  clerk standing capsules at (0.4,10.5)/(0.3,9.5) clear (walls at |x|>=2.1,
  lamps on walls only).

### lobby (0,0) — lines 1,5,6,7,18. FRAME 0'S STAKES.
Layout contract: desk centre (-0.5,-1.6) front face z -1.1; key board on the
back wall (-0.5,2.6,-4.7); corridor mouth arch gap x 2.1..4.7 in back wall
z -5; stub corridor behind it (x 2.02..4.78, z -5..-18) with doors 1-2-3 on
its left wall at z -7.2,-10.2,-13.2.
GLB delivers:
- **Modelled desk (Build critic r1 fault 5 fix, set side):** real front with
  3 recessed panels + pilasters, bevelled counter top with overhang, side
  returns, a floor-contact plinth and shadow gap — the clerk behind it reads
  planted, never floating on the counter. Desk lamp modelled on top (brass
  stem, teal shade, lampglow bulb).
- **Key board as a real board:** wood_dark frame + back panel, 3 rows x 7
  brass hooks, EVERY hook holding a modelled key (brass bow + stem + fob) —
  it must READ as exhausted/full at frame 0 at the previz board's size/place.
- Back/side walls: wainscot + plaster_warm panels, skirting, cornice;
  modelled sconce fixtures at the previz positions (-4.55,3.0,-2.5) and
  (4.55,3.0,-4.4) with lampglow glass.
- The arch: pilasters + architrave + brass trim around the mouth; through it
  the STUB modelled: panelled walls, jewel doors 1-2-3 with frames (panels
  included — stub doors are set, not props), 2 modelled lamps, ceiling
  beams, and a far glow arch (lampglow, framed — not a bare card) at z -17.8.
  Stub occupant heads stay procedural (set.js dyn.stubHeads).
- Floor: parquet slabs (wood / wood_pale alternating, flat) + the rug
  (carpet_red with border) in front of the desk; ceiling beams + coffers;
  a hanging lantern over the desk (brass cage + lampglow, bottom >= y 3.4).
- Dressing: modelled luggage trolley (brass frame, wheels, suitcases with
  straps) at the previz spot (-3.9,1.8); a bench + plant pot by the left
  wall; framed picture (wood frame, cream canvas) on the left wall.

### front (-400,0) — lines 13,17. THE ONE WIDE.
Layout contract: facade face z -6.0 (previz body z -6.5±.5), entrance bay
centre x 0, canopy z -4.4..-2.7 at y 4.35, street lamps at (±5.5, z 2..26),
bus stops at local (-4.4,-2.5) travelling along x, queue lane x -1.3..0 z 3+.
GLB delivers (place-local):
- Modelled facade: stone base course, pilasters between window bays,
  cornice strips per floor, 5 storeys x 7 bays of window frames (wood_dark)
  with winlit panes (ALL lit = full hotel), entrance portico: 2 columns,
  recessed double doors (wood_dark + brass), canopy on modelled brackets
  with brass fascia + 2 hanging lampglow lanterns, entrance steps with
  side cheeks.
- Street: kerbs + pavement slab strips both sides, modelled street lamps
  (post, crossarm, lantern head with lampglow) at the previz positions,
  far buildings (z 29..33) with frames + winlit windows — depth, never void.
- Dressing at edges only: crates + barrels by the entrance sides, a luggage
  cart, lamp-post bases. NOTHING in the bus lane (z -4..-1, x -18..6) above
  0.35 except the canopy (y >= 4.0), nothing in the queue lane.

### bus (own GLB, bus-local coords, front = +X end)
- Roots: `busbody` (body, roof band, window band of winlit panes, wheel
  arches + wheels, grille + bumper) and `busdoor` (the door panel at
  (2.6,1.6,1.16)) as a SEPARATE root so set.js keeps animating it.
- **The FRONT exists (Build handover item 5):** modelled +X face with a
  windshield (winlit), 2 round headlights (lampglow) at (±0.75 across z,
  y .95, x +3.83), grille (iron slats), bumper, route board (cream).
  Previz bus children hide only when bus.glb loads.

## Integration (scenes/set.js)
- Tian Dan pattern: dynamic import of `../world/look/glb.js`, GLB_PALETTE by
  material name (vivid pairs), try/catch, `frustumCulled = false`.
- Previz statics are grouped per place (lobbyPreviz / stubPreviz / corrPreviz /
  frontPreviz / busPreviz); a group hides ONLY when its place's GLB loaded.
  Dynamic previz stays live in all cases: stub heads, odd-door panels 5/7 +
  their lit planes, corridor far glow, door plaques/knobs (kept on the
  corridor group, re-seated proud of the GLB panels), bus group + queue.
- lampglow prims: geometry re-centred on its bbox centre and registered in
  dyn.bulbs so the existing pure-in-t flicker drives them. winlit prims use
  a plain basic material (no flicker).
- Lights data, PLACES, update(t) logic, marks DO NOT CHANGE (<=8 lights/place
  already: lobby 5, corridor 7, front 5).

## The bar (production file, hard floor)
Every shot >=22% detailed set and <=80% flat; film median shot >=28% detail
and <=78% flat; <=40% of shots under. NOTE: this VM's harness (drive-pipe)
exposes NO set-measure route (suite = info/stills/sweep/track/layout/
resolved only) — the app-side film_check {kind:'set'} is not reachable from
here. Substitute evidence: scale-1 before/after stills of the same 8 frames
+ a documented local pixel proxy over one mid-shot still per shot (21),
labelled as a proxy, never as the app's number. Plus the six look questions
from references/review.md per place.
