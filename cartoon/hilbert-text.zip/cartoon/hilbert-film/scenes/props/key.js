// props/key.js — the clerk's brass room key on a fob (BIBLE hero companion prop).
// Origin at the grip (the ring, where the hand holds it); the fob and key hang below.
// Pure build of opts; no state — the clerk's hand and clips carry its motion.
import { THREE, flat, basic, part, finish, canvasTex } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group(); g.name = 'prop.key';
  const brass = flat('#c9a227', '#8a6a14'), brassDk = flat('#a8843a', '#6e5220');
  // the ring (the grip)
  const ring = part(new THREE.TorusGeometry(.085, .02, 8, 20), brass, .01);
  g.add(ring);
  // the fob: a flat brass disc hanging from the ring, stamped with the hotel mark
  const fobTex = canvasTex(96, 96, (c, W, H) => {
    c.fillStyle = '#c9a227'; c.fillRect(0, 0, W, H);
    c.strokeStyle = '#6e5220'; c.lineWidth = 5; c.strokeRect(7, 7, W - 14, H - 14);
    c.fillStyle = '#4a3608'; c.font = '900 52px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText('H', W / 2, H / 2 + 2);
  });
  const fob = new THREE.Group(); fob.position.set(0, -.17, 0); g.add(fob);
  const disc = part(new THREE.CylinderGeometry(.11, .11, .028, 20), brass, .012);
  disc.rotation.x = Math.PI / 2; fob.add(disc);
  const face = new THREE.Mesh(new THREE.CircleGeometry(.095, 20), basic('#ffffff', { map: fobTex }));
  face.position.z = .016; fob.add(face);
  const link = part(new THREE.TorusGeometry(.035, .012, 6, 12), brassDk, .006);
  link.position.y = -.075; g.add(link);
  // the key itself: shaft + bow is the ring; blade with two teeth, hanging beside the fob
  const keyG = new THREE.Group(); keyG.position.set(.13, -.06, 0); keyG.rotation.z = .12; g.add(keyG);
  const shaft = part(new THREE.CylinderGeometry(.021, .021, .3, 8), brass, .008);
  shaft.position.y = -.15; keyG.add(shaft);
  const collar = part(new THREE.CylinderGeometry(.04, .04, .05, 8), brassDk, .008);
  collar.position.y = -.05; keyG.add(collar);
  const tooth1 = part(new THREE.BoxGeometry(.07, .035, .03), brass, .006);
  tooth1.position.set(.035, -.24, 0); keyG.add(tooth1);
  const tooth2 = part(new THREE.BoxGeometry(.05, .03, .03), brass, .006);
  tooth2.position.set(.025, -.29, 0); keyG.add(tooth2);
  return finish(g);
}
