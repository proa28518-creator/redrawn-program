// props/suitcase.js — a traveller's suitcase with handle, straps and print (BIBLE props).
// Origin at the grip (the top of the handle), so `in: 'hand:R'` hangs it from the hand
// and a put_down lands it on its base. Never a blank slab: corner caps, two straps, a
// stitched seam and a destination sticker. Opts: color, strap, sticker.
import { THREE, flat, basic, part, finish } from '../../engine/props/_kit.js';

export function build(o = {}) {
  const g = new THREE.Group(); g.name = 'prop.suitcase';
  const W = o.w ?? .62, H = o.h ?? .46, D = o.d ?? .2;
  const leather = flat(o.color ?? '#7a4a28', '#4f2d15');
  const strapM = flat(o.strap ?? '#4a2c14', '#2e1a0a');
  const brass = flat('#c9a227', '#8a6a14');
  const bag = new THREE.Group(); g.add(bag);
  // handle: two posts + a grip bar; the origin is the grip bar's top
  const grip = part(new THREE.CylinderGeometry(.028, .028, .26, 8), strapM, .01);
  grip.rotation.z = Math.PI / 2; grip.position.y = -.015; bag.add(grip);
  [-.1, .1].forEach(px => {
    const post = part(new THREE.BoxGeometry(.035, .07, .035), brass, .008);
    post.position.set(px, -.06, 0); bag.add(post);
  });
  const bodyY = -.09 - H / 2; // body hangs below the handle
  const body = part(new THREE.BoxGeometry(W, H, D), leather, .022);
  body.position.y = bodyY; bag.add(body);
  // lid seam + stitched line around the front face
  const seam = new THREE.Mesh(new THREE.PlaneGeometry(W * .94, .012), basic('#d8b98a'));
  seam.position.set(0, bodyY + H * .18, D / 2 + .002); bag.add(seam);
  const seam2 = seam.clone(); seam2.position.y = bodyY - H * .3; bag.add(seam2);
  // two straps over the lid, with brass buckles
  [-W * .28, W * .28].forEach(px => {
    const st = part(new THREE.BoxGeometry(.055, H * 1.02, D * 1.04), strapM, .01);
    st.position.set(px, bodyY, 0); bag.add(st);
    const bk = part(new THREE.BoxGeometry(.075, .06, .02), brass, .008);
    bk.position.set(px, bodyY + H * .18, D / 2 + .012); bag.add(bk);
  });
  // corner caps
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sy]) => {
    const cap = part(new THREE.BoxGeometry(.09, .09, D * 1.03), strapM, .008);
    cap.position.set(sx * (W / 2 - .045), bodyY + sy * (H / 2 - .045), 0); bag.add(cap);
  });
  // destination sticker (the print): a small cream label with a red band and ink lines
  const sticker = new THREE.Group(); sticker.position.set(W * .18, bodyY - H * .08, D / 2 + .004);
  sticker.rotation.z = -.14; bag.add(sticker);
  const lab = new THREE.Mesh(new THREE.PlaneGeometry(.17, .12), basic('#efe3c2'));
  sticker.add(lab);
  const band = new THREE.Mesh(new THREE.PlaneGeometry(.17, .032), basic('#a33327'));
  band.position.set(0, .036, .001); sticker.add(band);
  [-0.005, -0.032].forEach(ly => {
    const ln = new THREE.Mesh(new THREE.PlaneGeometry(.12, .012), basic('#5a4632'));
    ln.position.set(0, ly, .001); sticker.add(ln);
  });
  return finish(g, { bottom: [0, -.09 - H, 0] });
}
