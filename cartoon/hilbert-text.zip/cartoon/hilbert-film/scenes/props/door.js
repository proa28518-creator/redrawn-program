// props/door.js — a hero hotel door with a brass number plaque (BIBLE props).
// opts: { n (room number), open 0..1, lit 0..1, color }
// Origin at the floor centre of the doorway; the door faces +Z (the corridor side).
// The panel swings on its hinge (at the -X jamb) inward (-Z) as `open` goes 0→1;
// when `lit`, a warm interior plane glows behind the opening. Pure function of opts:
// the film drives open/lit with prop keys on their words (door 1 opens on «فضيت»).
import { THREE, flat, basic, part, finish, canvasTex } from '../../engine/props/_kit.js';

const plaqueTex = n => canvasTex(128, 128, (c, W, H) => {
  c.fillStyle = '#8a6a14'; c.fillRect(0, 0, W, H);
  c.fillStyle = '#c9a227'; c.fillRect(8, 8, W - 16, H - 16);
  c.strokeStyle = '#5f470c'; c.lineWidth = 4; c.strokeRect(14, 14, W - 28, H - 28);
  c.fillStyle = '#3a2a04'; c.font = '900 64px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(String(n ?? 1), W / 2, H / 2 + 4);
});

export function build(o = {}) {
  const g = new THREE.Group(); g.name = 'prop.door';
  const W = 1.6, H = 3.2, T = .18; // doorway width/height, frame depth
  const wood = flat(o.color ?? '#5d3a22', '#3c2410');
  const woodDk = flat('#4a2c14', '#2e1a0a');
  const brass = flat('#c9a227', '#8a6a14');
  // frame: two jambs + lintel
  [-1, 1].forEach(s => {
    const jamb = part(new THREE.BoxGeometry(.16, H + .16, T), woodDk, .018);
    jamb.position.set(s * (W / 2 + .08), (H + .16) / 2, 0); g.add(jamb);
  });
  const lintel = part(new THREE.BoxGeometry(W + .32, .16, T), woodDk, .018);
  lintel.position.set(0, H + .08, 0); g.add(lintel);
  // the warm interior behind the opening (shown when lit / as the panel opens)
  const litPlane = new THREE.Mesh(new THREE.PlaneGeometry(W + .34, H + .12),
    new THREE.MeshBasicMaterial({ color: 0xffcf8a, transparent: true, opacity: 0 }));
  litPlane.position.set(0, H / 2, -.3); g.add(litPlane);
  const roomBack = part(new THREE.BoxGeometry(W + .4, H + .2, .06), flat('#2e2015', '#1c130b'), .01);
  roomBack.position.set(0, H / 2, -.62); g.add(roomBack);
  // light spill on the floor in front of the door (grows with open*lit)
  const spill = new THREE.Mesh(new THREE.PlaneGeometry(W * 1.15, 1.5),
    new THREE.MeshBasicMaterial({ color: 0xffb45e, transparent: true, opacity: 0, depthWrite: false }));
  spill.rotation.x = -Math.PI / 2; spill.position.set(0, .012, .75); g.add(spill);
  // the panel, hinged at the +X jamb (moved from -X after stills showed the
  // -X fold masking the lit interior and the clerk from down-corridor cameras)
  const hinge = new THREE.Group(); hinge.position.set(W / 2, 0, 0); g.add(hinge);
  const panel = new THREE.Group(); panel.position.x = -W / 2; hinge.add(panel);
  const slab = part(new THREE.BoxGeometry(W - .06, H - .06, .09), wood, .02);
  slab.position.y = H / 2; panel.add(slab);
  // inset panels (print/detail on the slab)
  [[.62], [1.55], [2.45]].forEach(([py]) => {
    const inset = part(new THREE.BoxGeometry(W * .68, .78, .03), woodDk, .012);
    inset.position.set(0, py, .05); panel.add(inset);
  });
  // brass knob
  const knob = part(new THREE.SphereGeometry(.055, 10, 8), brass, .008);
  knob.position.set(W / 2 - .18, 1.55, .09); panel.add(knob);
  const knobB = part(new THREE.SphereGeometry(.055, 10, 8), brass, .008);
  knobB.position.set(W / 2 - .18, 1.55, -.09); panel.add(knobB);
  // the number plaque above the knob side, on the panel's face
  const plaque = new THREE.Group(); plaque.position.set(0, 2.78, .062); panel.add(plaque);
  const pBack = part(new THREE.BoxGeometry(.34, .34, .025), brass, .01); plaque.add(pBack);
  const pFace = new THREE.Mesh(new THREE.PlaneGeometry(.31, .31), basic('#ffffff', { map: plaqueTex(o.n) }));
  pFace.position.z = .014; plaque.add(pFace);
  g.userData.update = (obj, q) => {
    const open = Math.min(1, Math.max(0, q.open ?? 0)), lit = Math.min(1, Math.max(0, q.lit ?? 0));
    hinge.rotation.y = -open * 1.85; // hinge is on the +X jamb, so the sign flips: the panel folds INTO the room (the + sign parked it across the corridor, masking the clerk in S12/S15a/S19 stills)
    litPlane.material.opacity = lit; // fully opaque when lit: the doorway glows solid (a translucent plane over the dark room-back read as a black slab on stills)
    spill.material.opacity = lit * open * .34;
  };
  g.userData.update(g, o);
  return finish(g);
}
