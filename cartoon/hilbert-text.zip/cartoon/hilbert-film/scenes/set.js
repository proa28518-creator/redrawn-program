// scenes/set.js — the film's own set (film.js: world: { set: 'own' }). Three places,
// 400 D apart (BIBLE PLACES), so one place's light never leaks into another:
//   lobby    (0,0)      grand reception at night: desk + exhausted key board, and the
//                       CORRIDOR MOUTH in the back wall — through the arch a stub of
//                       corridor with doors 1-2-3 recedes 12 D+ (the hook's stakes).
//   corridor (400,0)    the endless corridor: 4 D wide, 66 D long, numbered doors on
//                       both sides every 3 D, wall lamps in pools, runner carpet,
//                       luggage outside occupied doors, warm haze at the far end.
//                       Hero doors 1/2/3 are PROPS (film.js); doors 5 and 7 panels are
//                       animated here for the L16 odd-door reveal (pure in t).
//   front    (-400,0)   the facade at night: five storeys of lit windows (ALL lit =
//                       full), entrance canopy with lamps, the street running 30 D
//                       with lamp posts; the bus arrives in update(t) on L13's words
//                       and the passenger queue shuffles toward the entrance.
// ENVIRONMENT OVERHAUL: Blender-built GLBs (assets/set/<place>.glb, see
// scenes/ENV_CONTRACT.md + blender/build_set.py) replace the previz statics per
// place. Previz statics live in named groups (lobbyPreviz / stubPreviz /
// corrPreviz / frontPreviz / busPreviz) that hide ONLY when that place's GLB
// loaded; every dynamic element (stub heads, odd-door panels, far glow, bus,
// queue, plaques) stays live either way, so the film always renders.
// update(t) is pure in t: lamp flicker, door-head stir silhouettes in the
// lobby stub, bus arrival, queue shuffle, odd-door reveal.
import { createLightRig } from '../world/look/lights.js';
import { createPost } from '../world/look/post.js';
import { createRigShade } from '../world/look/rigshade.js';
import { flat } from '../lib/film/props.js';
import { outline } from '../engine/shade.js';

const WARM = { sky: [.16, .13, .1], ground: [.1, .08, .06], fog: { color: '#241a10', density: .009 } };
const PLACES = {
  lobby: {
    sky: [.15, .12, .1], ground: [.1, .08, .06], fog: { color: '#201810', density: .008 },
    ao: { floor: 0, h: 1.6, amt: .4 },
    lights: [
      { id: 'desk', kind: 'point', color: [1, .72, .38], power: 1.15, pos: [-1.7, 2.1, -1.4], fall: .06, range: 13 },
      { id: 'sconceL', kind: 'point', color: [1, .66, .3], power: .8, pos: [-4.6, 3.0, -2.5], fall: .07, range: 11 },
      { id: 'sconceR', kind: 'point', color: [1, .66, .3], power: .8, pos: [4.4, 3.0, -4.2], fall: .07, range: 11 },
      { id: 'stub', kind: 'point', color: [1, .7, .34], power: .85, pos: [3.3, 2.6, -10], fall: .06, range: 13 },
      { id: 'fill', kind: 'spot', color: [.85, .8, .7], power: .5, pos: [0, 7, 9], dir: [0, -.7, -.5], cone: [40, 70], fall: .03, range: 30 },
    ],
  },
  corridor: {
    sky: [.13, .11, .09], ground: [.09, .07, .055], fog: { color: '#1e150c', density: .011 },
    ao: { floor: 0, h: 1.6, amt: .42 },
    lights: [
      { id: 'lamp0', kind: 'point', color: [1, .7, .33], power: 1.0, pos: [400, 3.1, 1], fall: .055, range: 13 },
      { id: 'lamp1', kind: 'point', color: [1, .7, .33], power: 1.0, pos: [400, 3.1, -9], fall: .055, range: 13 },
      { id: 'lamp2', kind: 'point', color: [1, .7, .33], power: 1.0, pos: [400, 3.1, -19], fall: .055, range: 13 },
      { id: 'lamp3', kind: 'point', color: [1, .7, .33], power: .95, pos: [400, 3.1, -29], fall: .055, range: 13 },
      { id: 'lamp4', kind: 'point', color: [1, .7, .33], power: .9, pos: [400, 3.1, -39], fall: .055, range: 13 },
      { id: 'lamp5', kind: 'point', color: [1, .68, .32], power: .85, pos: [400, 3.1, -49], fall: .055, range: 13 },
      { id: 'far', kind: 'point', color: [1, .62, .26], power: .8, pos: [400, 2.6, -60], fall: .04, range: 16 },
    ],
  },
  front: {
    sky: [.07, .09, .16], ground: [.06, .06, .09], fog: { color: '#10182b', density: .008 },
    ao: { floor: 0, h: 1.6, amt: .35 },
    lights: [
      { id: 'canopyL', kind: 'point', color: [1, .72, .36], power: 1.1, pos: [-401.6, 3.1, -3.4], fall: .06, range: 13 },
      { id: 'canopyR', kind: 'point', color: [1, .72, .36], power: 1.1, pos: [-398.4, 3.1, -3.4], fall: .06, range: 13 },
      { id: 'street1', kind: 'point', color: [1, .66, .3], power: .85, pos: [-405.5, 3.6, 2], fall: .05, range: 15 },
      { id: 'street2', kind: 'point', color: [1, .66, .3], power: .8, pos: [-394.5, 3.6, 12], fall: .05, range: 15 },
      { id: 'moon', kind: 'spot', color: [.5, .6, .9], power: .55, pos: [-408, 12, 14], dir: [.3, -.8, -.3], cone: [38, 68], fall: .03, range: 40 },
    ],
  },
};

function part(THREE, geo, mat, ink = .02) {
  const m = new THREE.Mesh(geo, mat);
  if (ink > 0) outline(m, { width: ink, color: 0x17110a });
  m.frustumCulled = false;
  return m;
}
function box(THREE, w, h, d, color, dark, x, y, z, ry = 0, ink = .018) {
  const m = part(THREE, new THREE.BoxGeometry(w, h, d), flat(color, dark), ink);
  m.position.set(x, y, z); m.rotation.y = ry; return m;
}
function bulb(THREE, r, color, x, y, z) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), new THREE.MeshBasicMaterial({ color }));
  m.position.set(x, y, z); m.frustumCulled = false; return m;
}
function glowPlane(THREE, w, h, color, x, y, z, ry = 0, opacity = 1) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h),
    new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity }));
  m.position.set(x, y, z); m.rotation.y = ry; m.frustumCulled = false; return m;
}
const ss = (a, b, t) => { const k = Math.min(1, Math.max(0, (t - a) / (b - a))); return k * k * (3 - 2 * k); };
function rng(seed) { let s = (seed * 9301 + 49297) % 233280 || 1; return () => (s = (s * 9301 + 49297) % 233280) / 233280; }
// a brass door plaque with the room number (canvas print — diegetic text, allowed)
function plaque(THREE, n, x, y, z, ry) {
  const cv = document.createElement('canvas'); cv.width = cv.height = 128;
  const c = cv.getContext('2d');
  c.fillStyle = '#8a6a14'; c.fillRect(0, 0, 128, 128);
  c.fillStyle = '#c9a227'; c.fillRect(8, 8, 112, 112);
  c.strokeStyle = '#5f470c'; c.lineWidth = 4; c.strokeRect(15, 15, 98, 98);
  c.fillStyle = '#3a2a04'; c.font = '900 62px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(String(n), 64, 68);
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(.34, .34), new THREE.MeshBasicMaterial({ map: tex }));
  m.position.set(x, y, z); m.rotation.y = ry; m.frustumCulled = false; return m;
}
// a wall lamp: bracket + shade + bulb (a visible practical); returns the bulb for flicker
function wallLamp(THREE, parent, x, y, z, ry, dyn, s = 1) {
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = ry; parent.add(g);
  g.add(box(THREE, .07, .3, .07, '#4c3823', '#33250f', 0, -.12, .06, 0, .01));
  const shade = part(THREE, new THREE.ConeGeometry(.21 * s, .18 * s, 10, 1, true), flat('#8a5f22', '#5f3f14'), .012);
  shade.position.y = .05; g.add(shade);
  const b = bulb(THREE, .085 * s, 0xffc26a, 0, -.03, 0); g.add(b);
  if (dyn) dyn.bulbs.push({ m: b, ph: x * 1.3 + z * 1.7 });
  return g;
}

export async function buildSet(THREE, scene, opts = {}, kit) {
  const base = kit('plain', {});
  const g = base.group;
  const points = { ...(base.points || {}) };
  const dyn = { bulbs: [], stubHeads: [], oddDoors: [], queue: [] };

  // ================= LOBBY (0,0) =================
  const L = new THREE.Group(); g.add(L);
  const LP = new THREE.Group(); LP.name = 'lobbyPreviz'; L.add(LP);   // previz statics (GLB replaces)
  LP.add(box(THREE, 26, .08, 30, '#4a3826', '#322412', 0, -.02, 0, 0, .004));                    // floor
  LP.add(box(THREE, 9, .04, 7, '#6e2f26', '#4c1f18', -.6, .025, 1.5, 0, .004));                  // lobby rug
  // back wall (z=-5) in segments: the CORRIDOR MOUTH arch is the gap x 2.1..4.7
  LP.add(box(THREE, 7.1, 5.6, .4, '#3d4a4a', '#293333', -1.45, 2.8, -5, 0, .012));                // left of arch
  LP.add(box(THREE, 8.3, 5.6, .4, '#3d4a4a', '#293333', 8.85, 2.8, -5, 0, .012));                 // right of arch
  LP.add(box(THREE, 2.6, 1.5, .4, '#3d4a4a', '#293333', 3.4, 4.85, -5, 0, .012));                 // above arch
  LP.add(box(THREE, 2.9, .22, .5, '#8a5f22', '#5f3f14', 3.4, 4.02, -5, 0, .012));                 // arch trim
  [-5.2, 5.2].forEach(sx => LP.add(box(THREE, .4, 5.6, 30, '#354242', '#232d2d', sx * 2.5, 2.8, 0, 0, .01))); // side walls
  LP.add(box(THREE, 26, .3, 30, '#2c3838', '#1c2424', 0, 5.75, 0, 0, .006));                     // ceiling
  // the DESK (centre-left): counter with panelled front, top slab
  LP.add(box(THREE, 3.6, 1.22, .95, '#5d3a22', '#3c2410', -.5, .61, -1.6, 0, .016));
  LP.add(box(THREE, 3.9, .09, 1.2, '#7a4c2a', '#54331a', -.5, 1.27, -1.6, 0, .014));
  [-1.5, -.5, .5].forEach(px => LP.add(box(THREE, .8, .85, .05, '#4a2c14', '#2e1a0a', px, .62, -1.1, 0, .01)));
  // desk lamp (practical 1): stem + shade + bulb on the desk's left end
  LP.add(box(THREE, .05, .55, .05, '#3a3d40', '#232527', -1.9, 1.58, -1.7, 0, .01));
  { const sh = part(THREE, new THREE.ConeGeometry(.24, .2, 10, 1, true), flat('#175f57', '#0f3d38'), .012);
    sh.position.set(-1.78, 1.92, -1.6); LP.add(sh); }
  { const b = bulb(THREE, .09, 0xffd9a0, -1.78, 1.84, -1.6); LP.add(b); dyn.bulbs.push({ m: b, ph: 1.1 }); }
  // THE KEY BOARD behind the clerk: every hook taken (the "full" sign, no words)
  LP.add(box(THREE, 3.4, 2.0, .1, '#4a2c14', '#2e1a0a', -.5, 2.6, -4.72, 0, .014));
  LP.add(box(THREE, 3.2, 1.8, .04, '#6e5136', '#4c3823', -.5, 2.6, -4.66, 0, .01));
  for (let r = 0; r < 3; r++) for (let i = 0; i < 7; i++) {
    const kx = -1.85 + i * .45, ky = 3.15 - r * .55;
    LP.add(box(THREE, .06, .06, .06, '#c9a227', '#8a6a14', kx, ky, -4.6, 0, .006));              // hook
    LP.add(box(THREE, .09, .24, .03, '#c9a227', '#8a6a14', kx, ky - .19, -4.6, 0, .005));        // a key on EVERY hook
    LP.add(box(THREE, .15, .17, .02, '#8a5f22', '#5f3f14', kx, ky - .38, -4.6, 0, .005));         // its fob
  }
  // wall sconces (practicals 2 and 3)
  wallLamp(THREE, LP, -4.55, 3.0, -2.5, Math.PI / 2, dyn);
  wallLamp(THREE, LP, 4.55, 3.0, -4.4, -Math.PI / 2, dyn);
  // a luggage trolley + suitcases at the side (arrivals dressing)
  LP.add(box(THREE, .9, .06, .6, '#8a5f22', '#5f3f14', -3.9, .5, 1.8, .3, .01));
  [-.42, .42].forEach(px => LP.add(box(THREE, .05, 1.0, .05, '#8a5f22', '#5f3f14', -3.9 + px * .8, .5, 1.8 + px * .35, .3, .008)));
  LP.add(box(THREE, .62, .46, .2, '#7a4a28', '#4f2d15', -3.9, .28, 1.8, .3, .012));
  LP.add(box(THREE, .55, .4, .18, '#44586e', '#2c3a49', -3.85, .72, 1.75, .15, .012));
  // ---- the CORRIDOR STUB behind the arch: doors 1-2-3 occupied, receding ----
  const S = new THREE.Group(); L.add(S);
  const SP = new THREE.Group(); SP.name = 'stubPreviz'; S.add(SP);   // stub previz statics
  SP.add(box(THREE, 2.6, .06, 13, '#4a3826', '#322412', 3.4, -.01, -11.5, 0, .004));             // stub floor
  SP.add(box(THREE, .25, 4.4, 13, '#354242', '#232d2d', 2.02, 2.2, -11.5, 0, .01));              // stub left wall (doors side)
  SP.add(box(THREE, .25, 4.4, 13, '#354242', '#232d2d', 4.78, 2.2, -11.5, 0, .01));              // stub right wall
  SP.add(box(THREE, 2.6, .25, 13, '#2c3838', '#1c2424', 3.4, 4.5, -11.5, 0, .006));              // stub ceiling
  [1, 2, 3].forEach((n, i) => {
    const dz = -7.2 - i * 3;
    SP.add(box(THREE, .1, 3.2, 1.6, '#5d3a22', '#3c2410', 2.18, 1.6, dz, 0, .014));              // stub door (closed, occupied)
    SP.add(plaque(THREE, n, 2.24, 2.75, dz, Math.PI / 2));
    // an occupant head stirring at the door (a silhouette life element, pure in t)
    const head = new THREE.Group(); head.position.set(2.75, 0, dz + .55); S.add(head);
    const skull = bulb(THREE, .3, 0xe8e2d2, 0, 2.35, 0); head.add(skull);
    const cap = part(THREE, new THREE.SphereGeometry(.315, 10, 6, 0, Math.PI * 2, 0, Math.PI * .45), flat('#2c2620', '#1a1510'), .008);
    cap.position.y = 2.38; head.add(cap);
    head.add(box(THREE, .62, 1.1, .4, ['#6d3b5e', '#5c6633', '#44586e'][i], '#333', 0, 1.55, 0, 0, .01));
    dyn.stubHeads.push({ m: head, ph: i * 2.1 });
    SP.add(box(THREE, .5, .38, .18, '#6e5136', '#4c3823', 2.6, .19, dz - 1.1, .2, .01));        // luggage outside
  });
  wallLamp(THREE, SP, 4.62, 2.9, -8.6, -Math.PI / 2, dyn, .9);
  wallLamp(THREE, SP, 4.62, 2.9, -13.6, -Math.PI / 2, dyn, .9);
  SP.add(glowPlane(THREE, 2.4, 3.6, 0xff9a3a, 3.4, 1.9, -17.8, 0, .3));                          // warm depth end (never black)

  // ================= CORRIDOR (400,0) =================
  const C = new THREE.Group(); C.position.set(400, 0, 0); g.add(C);
  const CP = new THREE.Group(); CP.name = 'corrPreviz'; C.add(CP);   // corridor previz statics
  CP.add(box(THREE, 7, .08, 74, '#3e2f1e', '#291d11', 0, -.02, -28, 0, .004));                   // floor
  CP.add(box(THREE, 2.2, .045, 72, '#6e2f26', '#4c1f18', 0, .025, -28, 0, .004));                // runner carpet
  [-2.3, 2.3].forEach(wx => CP.add(box(THREE, .35, 4.6, 74, '#33413f', '#212c2b', wx, 2.3, -28, 0, .01))); // walls
  CP.add(box(THREE, 7, .3, 74, '#26302f', '#171f1e', 0, 4.75, -28, 0, .006));                    // ceiling
  CP.add(box(THREE, 1.55, 4.6, .4, '#33413f', '#212c2b', -1.72, 2.3, 5.2, 0, .01));   // mouth wall L of the doorway
  CP.add(box(THREE, 1.55, 4.6, .4, '#33413f', '#212c2b', 1.72, 2.3, 5.2, 0, .01));    // mouth wall R of the doorway
  CP.add(box(THREE, 1.9, 1.3, .4, '#33413f', '#212c2b', 0, 3.95, 5.2, 0, .01));       // doorway lintel
  // wall lamps between doors, alternating sides (practicals all down the depth)
  for (let i = 0; i < 10; i++) {
    const lz = .5 - i * 6.5, side = i % 2 ? 1 : -1;
    wallLamp(THREE, CP, side * 2.05, 3.05, lz, side > 0 ? -Math.PI / 2 : Math.PI / 2, dyn, .95);
  }
  // doors: hero doors 1/2/3 are props (film.js) — the set leaves their frames only.
  // All other doors are set elements; doors 5 and 7 get animated panels for L16.
  // Plaques live on C (never hidden) re-seated proud of the GLB panels (|x| 1.96,
  // in front of the GLB brass plate face at 1.98) so the numbers survive the swap.
  const doorZ = n => -2 - (n - 1) * 3, doorSide = n => (n % 2 ? -1 : 1); // odd doors left
  for (let n = 1; n <= 21; n++) {
    const dz = doorZ(n), sd = doorSide(n), wx = sd * 2.12;
    // frame
    CP.add(box(THREE, .14, 3.36, 1.76, '#4a2c14', '#2e1a0a', wx, 1.68, dz, 0, .012));
    if (n <= 3) continue; // hero door panels are props
    if (n === 5 || n === 7) {
      // animated reveal door: lit interior + panel on a hinge group (dyn.oddDoors)
      const lit = glowPlane(THREE, 1.5, 3.1, 0xffc26a, wx - sd * .12, 1.6, dz, sd > 0 ? -Math.PI / 2 : Math.PI / 2, 0);
      C.add(lit);
      const hinge = new THREE.Group(); hinge.position.set(wx, 0, dz - .8); C.add(hinge);
      const panel = box(THREE, .08, 3.14, 1.54, '#5d3a22', '#3c2410', -sd * .02, 1.57, .8, 0, .016);
      hinge.add(panel);
      const plq = plaque(THREE, n, sd * 1.96, 2.78, dz, sd > 0 ? Math.PI / 2 : -Math.PI / 2);
      C.add(plq);
      dyn.oddDoors.push({ hinge, lit, n, t0: n === 5 ? 47.35 : 47.85 });
      continue;
    }
    const panel = box(THREE, .08, 3.14, 1.54, '#5d3a22', '#3c2410', wx, 1.57, dz, 0, .016);
    CP.add(panel);
    [[.62], [1.55], [2.45]].forEach(([py]) => {
      const inset = box(THREE, .03, .78, 1.05, '#4a2c14', '#2e1a0a', wx + (sd > 0 ? .05 : -.05), py, dz, 0, .01);
      CP.add(inset);
    });
    C.add(plaque(THREE, n, sd * 1.96, 2.78, dz, sd > 0 ? Math.PI / 2 : -Math.PI / 2));
    const knob = bulb(THREE, .05, 0xc9a227, wx + (sd > 0 ? .07 : -.07), 1.55, dz + .6);
    CP.add(knob);
    // occupied dressing: luggage / shoes outside most doors (seeded)
    const r = rng(900 + n);
    if (r() < .75) CP.add(box(THREE, .5, .38, .18, ['#6e5136', '#5d4a5e', '#44586e'][n % 3], '#333', sd * 1.55, .19, dz + .95, r() * .5, .01));
    if (r() < .6) { CP.add(box(THREE, .3, .1, .12, '#2c2620', '#1a1510', sd * 1.7, .05, dz - .95, .3, .008));
      CP.add(box(THREE, .3, .1, .12, '#2c2620', '#1a1510', sd * 1.7, .05, dz - .7, -.2, .008)); }
  }
  // the L4 "last door": door 7 is animated for L16, so the shut-door beat uses door 8's
  // neighbour — a waiting suitcase stands outside door 7's frame from the start (set).
  CP.add(box(THREE, .55, .42, .19, '#7a4a28', '#4f2d15', -1.5, .21, doorZ(7) - 1.15, .15, .012));
  C.add(glowPlane(THREE, 4.4, 3.8, 0xff9a3a, 0, 2.0, -63.5, 0, .55));                            // far end warm haze glow

  // ================= FRONT (-400,0) =================
  const F = new THREE.Group(); F.position.set(-400, 0, 0); g.add(F);
  const FP = new THREE.Group(); FP.name = 'frontPreviz'; F.add(FP);   // front previz statics
  FP.add(box(THREE, 44, .08, 52, '#232833', '#161a21', 0, -.02, 8, 0, .004));                    // street
  FP.add(box(THREE, 10, .05, 40, '#2c313c', '#1d212a', 0, .03, 10, 0, .004));                    // road strip
  // THE FACADE: five storeys, ALL windows lit (the hotel is full, visible from the street)
  FP.add(box(THREE, 30, 17, 1, '#3a3f4a', '#272b33', 0, 8.5, -6.5, 0, .01));
  for (let row = 0; row < 5; row++) for (let col = 0; col < 7; col++) {
    if (row === 0 && (col === 3)) continue; // the entrance bay
    const wx = -12 + col * 4, wy = 2.6 + row * 3.1;
    FP.add(box(THREE, 1.7, 2.1, .12, '#20242c', '#12151a', wx, wy, -5.95, 0, .01));
    FP.add(glowPlane(THREE, 1.45, 1.85, (row + col) % 3 ? 0xffc26a : 0xffd9a0, wx, wy, -5.88));
    FP.add(box(THREE, 1.5, .07, .14, '#20242c', '#12151a', wx, wy, -5.9, 0, .008));
  }
  // entrance: recessed doors, canopy with two lamps (practicals), steps
  // 2026-11-28 (coordinator, on stills .suite/frames/entrance-probe/): the
  // previz entrance unit (recess + glow doors) is hidden so the Hunyuan
  // facade piece + canopy + lamps carry the front — the flat glow-card doors
  // the integration flagged no longer cap the modelled facade. Verified at
  // 36.5 and 38.5: no hole, no dark gap, bus front reads beside the bay.
  // FP.add(box(THREE, 3.4, 4.4, .3, '#20242c', '#12151a', 0, 2.2, -5.9, 0, .012));
  // [-0.8, 0.8].forEach(dx => FP.add(glowPlane(THREE, 1.3, 3.6, 0xffb45e, dx, 1.9, -5.72)));
  FP.add(box(THREE, 5.6, .22, 3.4, '#6e2f26', '#4c1f18', 0, 4.35, -4.4, 0, .014));                // canopy
  FP.add(box(THREE, 5.6, .5, .18, '#8a5f22', '#5f3f14', 0, 4.05, -2.78, 0, .01));                 // canopy fascia (brass)
  wallLamp(THREE, FP, -1.6, 3.6, -3.1, 0, dyn, 1.1);
  wallLamp(THREE, FP, 1.6, 3.6, -3.1, 0, dyn, 1.1);
  FP.add(box(THREE, 4.4, .18, 1.6, '#4c4f55', '#33363b', 0, .09, -4.6, 0, .01));                  // steps
  // street lamp posts down the street (practicals in depth, 30 D of street)
  // 2026-11-28 (v2): the posts live in their own group (SL) so the Hunyuan
  // street piece's lamp row can replace them on load (GLB layer below) —
  // the escalation note's route: previz lamps hide, the piece's lamps
  // carry the street band. The street/road slabs stay either way.
  const SL = new THREE.Group(); SL.name = 'streetLampPreviz'; FP.add(SL);
  [[-5.5, 2], [5.5, 8], [-5.5, 14], [5.5, 20], [-5.5, 26]].forEach(([lx, lz], i) => {
    SL.add(box(THREE, .09, 3.8, .09, '#22262e', '#12151a', lx, 1.9, lz, 0, .01));
    const b = bulb(THREE, .13, 0xffc26a, lx, 3.85, lz); SL.add(b); dyn.bulbs.push({ m: b, ph: i * 1.9 });
    SL.add(box(THREE, .5, .08, .5, '#22262e', '#12151a', lx, 3.95, lz, 0, .008));
  });
  // far building silhouettes (street depth, never a void)
  FP.add(box(THREE, 10, 11, 1, '#171c26', '#0e1219', -11, 5.5, 30, 0, .004));
  FP.add(box(THREE, 12, 8, 1, '#151a24', '#0d1017', 10, 4, 32, 0, .004));
  FP.add(glowPlane(THREE, 1.2, 1.6, 0xffc26a, -12, 6, 29.4, 0, .8));
  FP.add(glowPlane(THREE, 1.2, 1.6, 0xffc26a, 9, 4.5, 31.4, 0, .8));
  // THE BUS (dyn): arrives 35.2→36.4 from the left, sighs to a stop left of the entrance
  const bus = new THREE.Group(); F.add(bus); dyn.bus = bus;
  const BP = new THREE.Group(); BP.name = 'busPreviz'; bus.add(BP);   // previz bus (GLB replaces)
  BP.add(box(THREE, 7.6, 2.5, 2.3, '#33507a', '#22334e', 0, 1.75, 0, 0, .016));
  BP.add(box(THREE, 7.7, .5, 2.35, '#22334e', '#16222f', 0, 3.2, 0, 0, .012));
  for (let i = 0; i < 6; i++) BP.add(glowPlane(THREE, .95, .8, 0xffd9a0, -3.1 + i * 1.25, 2.25, 1.16));
  const busDoorPreviz = box(THREE, 1.1, 2.2, .06, '#20242c', '#12151a', 2.6, 1.6, 1.16, 0, .01);  // bus door (opens on arrival)
  BP.add(busDoorPreviz);
  dyn.busDoor = busDoorPreviz;
  [-2.8, 2.8].forEach(wx => { const wh = part(THREE, new THREE.CylinderGeometry(.5, .5, .25, 14), flat('#1c1f24', '#101216'), .01);
    wh.rotation.x = Math.PI / 2; wh.position.set(wx, .5, 1.1); BP.add(wh);
    const wh2 = wh.clone(); wh2.position.z = -1.1; BP.add(wh2); });
  [-3.4, 3.4].forEach(hx => { const hl = bulb(THREE, .11, 0xffe9a0, hx, .95, 1.18); BP.add(hl); });
  bus.position.set(-17, 0, -2.5);
  // THE QUEUE (dyn silhouettes): passengers stretching down the street, shuffling
  // forward in a slow loop — depth figures; the named cast leads them in L17.
  const qCols = ['#93302a', '#3e6b4f', '#6d3b5e', '#5c6633', '#44586e', '#a87c24'];
  for (let i = 0; i < 9; i++) {
    const q = new THREE.Group();
    const col = qCols[i % qCols.length];
    q.add(box(THREE, .62, 1.15, .4, col, '#26221e', 0, 1.15, 0, 0, .01));
    q.add(bulb(THREE, .29, 0xe8e2d2, 0, 2.15, 0));
    const qc = part(THREE, new THREE.SphereGeometry(.305, 10, 6, 0, Math.PI * 2, 0, Math.PI * .45), flat('#2c2620', '#1a1510'), .008);
    qc.position.y = 2.18; q.add(qc);
    q.add(box(THREE, .45, .34, .16, '#6e5136', '#4c3823', .45, .75, .1, .3, .008));              // a bag in hand
    q.position.set(-1.3 + (i % 3) * .5, 0, 3.5 + i * 2.6);
    F.add(q); dyn.queue.push({ m: q, i, z0: 3.5 + i * 2.6 });
  }

  // ================= HUNYUAN SETS (Environment overhaul, hybrid) =================
  // 2026-11-28: Hunyuan hybrid integration. The Blender-built GLBs were
  // CANCELLED as the film's set source (user order 2026-11-28 04:09); instead
  // Hunyuan 3D generated the pieces, Qwen's glb_reduce.py lightened them and
  // the palette adaptation renamed their materials to the GLB_PALETTE names
  // below. The adapted pieces live in assets/hunyuan/adapted/ and load through
  // this layer with a per-piece fit transform (the Hunyuan meshes are ~1-unit
  // single meshes, NOT place-local like the cancelled Blender sets).
  // V2 (2026-11-28): front / bus / busdoor integrated (below); the corridor
  // v2 room is integrated as five fitted tiles of the adapted tube; a street
  // dressing piece covers the front street band; the lobby room is
  // integrated (the crew GLB — the v2 room with palette fixes — fitted
  // desk-true with the key-board exception; see its block below). Loaded
  // with the engine's
  // readGlb; any missing/unreadable file simply leaves the previz standing.
  const GLB_PALETTE = {
    wood: ['#7a4a26', '#54300f'], wood_dark: ['#4c2c12', '#301b08'], wood_pale: ['#a87c48', '#7d5a2e'],
    brass: ['#d9a83c', '#a87c1e'], iron: ['#33373d', '#1f2226'], stone: ['#61666e', '#43464d'],
    door_teal: ['#128a7a', '#0a5c50'], door_burg: ['#a02844', '#701a2e'], door_plum: ['#7d3694', '#55246a'],
    door_forest: ['#3d7a44', '#27542c'], wall_teal: ['#2e5a52', '#1d3a35'], plaster_warm: ['#c49a5e', '#96703c'],
    carpet_red: ['#a33327', '#701f16'], cream: ['#efe6cc', '#cfc09c'],
    bus_blue: ['#2f6da3', '#1e4a73'], bus_cream: ['#efe9d8', '#cfc8ae'],
  };
  try {
    const { readGlb } = await import('../world/look/glb.js');
    const loadGlb = async file => {
      const d = await readGlb(THREE, new URL(`../assets/hunyuan/adapted/${file}`, import.meta.url));
      return d && d.roots ? d : null;
    };
    // Adds a GLB under parent; lampglow prims become basic-material meshes
    // re-centred on their bbox centre and registered for the flicker;
    // winlit prims become plain basic-material meshes. The optional xf fit
    // transform ({pos, rotY, scale}, three-space, applied as a wrapper group
    // around the piece) lands a ~1-unit Hunyuan mesh in its place contract;
    // measured raw bboxes are recorded in lessons/hunyuan-integration.md.
    // Returns the added group (the wrapper when xf is given), or null.
    const addGlb = (data, parent, flicker, xf) => {
      let added = null;
      for (const root of data.roots) {
        const grp = new THREE.Group();
        root.matrix.decompose(grp.position, grp.quaternion, grp.scale);
        for (const prim of root.prims) {
          let mesh;
          if (prim.material === 'lampglow' || prim.material === 'winlit') {
            const col = prim.material === 'lampglow' ? 0xffc26a : 0xffb45e;
            if (prim.material === 'lampglow' && flicker) {
              prim.geometry.computeBoundingBox();
              const c = new THREE.Vector3(); prim.geometry.boundingBox.getCenter(c);
              prim.geometry.translate(-c.x, -c.y, -c.z);
              mesh = new THREE.Mesh(prim.geometry, new THREE.MeshBasicMaterial({ color: col }));
              mesh.position.copy(c);
              dyn.bulbs.push({ m: mesh, ph: c.x * 1.3 + c.z * 1.7 });
            } else {
              mesh = new THREE.Mesh(prim.geometry, new THREE.MeshBasicMaterial({ color: col }));
            }
          } else {
            const pal = GLB_PALETTE[prim.material] || ['#7a7d82', '#55585c'];
            mesh = new THREE.Mesh(prim.geometry, flat(pal[0], pal[1]));
          }
          mesh.frustumCulled = false;
          grp.add(mesh);
        }
        if (xf) {
          const w = new THREE.Group();
          if (xf.pos) w.position.set(xf.pos[0], xf.pos[1], xf.pos[2]);
          if (xf.rotY) w.rotation.y = xf.rotY;
          if (xf.scale) w.scale.set(xf.scale[0], xf.scale[1], xf.scale[2]);
          w.add(grp); parent.add(w); added = w;
        } else { parent.add(grp); added = grp; }
      }
      return added;
    };
    // CORRIDOR v2 (2026-11-28): the v2 piece is a complete corridor tube
    // (raw three-space bbox 0.250 W x 0.263 H x 1.145 D, open at local +Z,
    // end wall + door at local z ~ -0.55). It is tiled along the lane:
    // five copies at scale [21.65, 17, 18] — x puts the wall inner faces
    // at |x| 2.10 (plaques at 1.96 and the odd-door glow planes at 2.0
    // stay proud of the piece's door faces), y puts the floor top at 0
    // and the ceiling underside at 4.10, z makes the piece's door rhythm
    // land on the contract doors (pairs at place -2.0 / -5.0 / -8.1 for
    // hero doors 1-3; no piece door at door 5's -14, so the animated
    // reveal reads clean; a pair at -19.2 behind door 7's panel).
    // Tiles A-C use corridor-nocap.glb (end cap cut at local z -0.525 in
    // blender/strip_corridor_cap.py — cleanup for tiling, nothing drawn);
    // tile D keeps its cap, closing the tube behind the far glow plane
    // (-63.5); tile E is the capped piece flipped (rotY pi) to dress the
    // vestibule, its cap landing at z +27, beyond every shot. CP hides
    // only if all five tiles land.
    // Tile A alone uses corridor-nocap-d1.glb (2026-11-28, corridor
    // critic fix): the piece door behind hero door 1 stood in front of
    // the prop's own lit interior (props/door.js litPlane at piece
    // x -0.110) and read as torn teal shards in the S10 reveal, so
    // blender/strip_corridor_door1.py deleted the non-floor faces inside
    // door 1's reveal window in front of that plane — the prop's lit
    // interior + room back now carry the reveal, as doors 5/7 already
    // proved clean. Same transform as tile A always had; tiles B/C keep
    // the shared nocap file (their copy of that window has no hero prop
    // behind it). All three corridor files also carry the runner fix
    // (adapt_hilbert_corridorfix.py: the floor's centre band is
    // carpet_red — the v2 source has no red in it at all).
    const corrCap = await loadGlb('corridor.glb');
    const corrOpen = await loadGlb('corridor-nocap.glb');
    const corrD1 = await loadGlb('corridor-nocap-d1.glb');
    if (corrCap && corrOpen && corrD1) {
      const CS = [21.65, 17, 18];
      let nTiles = 0;
      if (addGlb(corrD1, C, true, { pos: [0, -0.187, -3.89], scale: CS })) nTiles++;
      if (addGlb(corrOpen, C, true, { pos: [0, -0.187, -23.83], scale: CS })) nTiles++;
      if (addGlb(corrOpen, C, true, { pos: [0, -0.187, -43.78], scale: CS })) nTiles++;
      if (addGlb(corrCap, C, true, { pos: [0, -0.187, -63.72], scale: CS })) nTiles++;
      if (addGlb(corrCap, C, true, { pos: [0, -0.187, 17.09], rotY: Math.PI, scale: CS })) nTiles++;
      if (nTiles === 5) CP.visible = false;
    }
    // LOBBY (2026-11-28, order 27 — Lead 1 merge of the lobby crew's
    // section; fit + full reasoning in .suite/places/lobby/fit.json):
    // the crew GLB is the v2 room with the carpet/brass palette fixes
    // (geometry identical to adapted/lobby-v2.glb; lobby-crew2.glb is
    // that file with the piece's hanging lanterns deleted — the front
    // one's lampglow mass covered the clerk's face on the S18 axis).
    // The fit is
    // desk-true (desk top 1.27, desk width 3.6); the piece's doorway
    // is centred on the corridor-stub axis and its back wall lands
    // exactly on the contract plane z -5.0. KEY-BOARD EXCEPTION
    // (lead's decision, ADOPTED): the piece has no key board, so the
    // previz board prop — the 65 LP children built right after the
    // desk (board + face at z -4.72/-4.66 and the 21 hooks/keys/fobs
    // at z -4.60; x -2.2..1.2, y 1.6..3.6) — is re-parented into L
    // (Object3D.attach) BEFORE LP hides, shifted +0.55 in z so the
    // board and its hooks stand proud of the piece's back-wall
    // relief (relief front ~z -4.20 in the board band), centred on
    // the clerk. SP (corridor stub) stays visible:
    // the stub reads through the piece's centred doorway.
    const LOBBY_ASSET = 'lobby-crew2.glb';
    const LOBBY_XF = { pos: [0.61, 0, -1.117], rotY: 0, scale: [18, 6.35, 11] };
    const lobGlb = await loadGlb(LOBBY_ASSET);
    if (lobGlb && addGlb(lobGlb, L, true, LOBBY_XF)) {
      const board = LP.children.filter(c =>
        c.position.z >= -4.75 && c.position.z <= -4.55 &&
        c.position.x >= -2.25 && c.position.x <= 1.25 &&
        c.position.y >= 1.55 && c.position.y <= 3.65);
      if (board.length === 65) for (const c of board) { c.position.z += 0.55; L.attach(c); }
      // WHOLE-SET GATE FIX — Fault 2 (lobby open-topped): the piece's
      // walls top out at y 3.68 (measured on lobby-crew2.glb: world
      // bbox y 0..3.68, z -5.00..4.28) and it has no ceiling, so every
      // lobby camera (y 2.55..2.85, looking north, fov 30-31) saw the
      // film's pale sky over the cornice — the top 15-28% of frame,
      // incl. frame 0. Closure: a warm dark wood ceiling slab resting
      // on the wall tops (underside 3.66, embedding 0.02 into the rim
      // so no sky sliver survives at the joint), spanning the piece's
      // full width (x -3.73..8.17) and from just past the back wall
      // (z -5.05) south past every lobby camera (z 13.65; the
      // southernmost is S1's 13.4, under the slab at y 2.85). Any
      // northbound ray either reaches 3.66 under the slab or is still
      // below the wall top at z -5 and meets the wall — no sky path
      // remains. It starts AT the back wall, so the stub sight-line
      // through the doorway is untouched, and it passes above the key
      // board (top 3.6, at z -4.05..-4.2, in front of the wall).
      // TONE (recovery round, verified on fix-stills): only the slab's
      // DARK side (flat() underside) is ever on screen, and the look's
      // top-of-frame falloff takes it to RGB ~7-17 — a black bar, not a
      // ceiling. The dark tone is therefore raised to a mid warm wood
      // (#77572f) so the underside lands warm-dark (~20-50) on screen;
      // geometry unchanged.
      L.add(box(THREE, 11.9, 0.15, 18.7, '#8a683f', '#77572f', 2.22, 3.735, 4.3, 0, 0));
      LP.visible = false;
    }
    // FRONT: raw three-space bbox 0.711 W x 0.657 H x 0.713 D, base at y=0.
    // Measured profile (vertex density): the building mass spans local
    // z -0.16..+0.10, a projecting wing continues to +0.26, and a flat
    // ground apron (local height <=0.028) reaches +0.47. Fit: span the
    // previz facade's 30 D width, stand 17 D tall, building front plane
    // (local z +0.10) at world z -5.85, just in front of the previz facade
    // face (-6.0) and its window planes (-5.88). FP stays VISIBLE
    // (deliberate, judged on stills): hiding it took the street, kerbs,
    // street lamps, canopy and far buildings with it and left the queue
    // standing on the bare kit ground. The piece sits 0.39 low so its
    // apron top lands at ~0.34 — inside the bus lane's 0.35 keep-clear —
    // and the wing front (-4.28) stays north of the lane box (-4.2).
    const froGlb = await loadGlb('front.glb');
    if (froGlb) addGlb(froGlb, F, true, { pos: [-0.18, -0.39, -6.83], scale: [42.2, 25.9, 9.8] });
    // STREET — CREW RE-FIT (2026-11-28, street place crew, three.js member;
    // numbers in .suite/places/street/fit.json). Replaces the STREET v2 fit
    // above for the crew file (street-crew.glb: 149,701 faces, decimation
    // ratio 0.10, lamp heads forced 100% lampglow by the crew textures pass —
    // the lead places it in assets/hunyuan/adapted/, where loadGlb resolves).
    // WHY THE OLD FIT FAILED (front critic round 2, verdict NO): rotY ~pi
    // laid the piece's lamp row at place x -4.4..-8.1, west of S13's narrow
    // portrait wedge (fov 34, horizontal half-angle 9.76 deg) — its entire
    // in-frame trace was a pavement-edge sliver at px x 0..140, zero lamps
    // read. Measured from the crew GLB, the piece is NOT a uniform strip:
    // four lamps stand in a near-straight local row on three ground pads
    // (the generation's ~9 deg diagonal drift lives in the pads, not the
    // row). This fit rotates the row itself down the west pavement band at
    // place x ~ -2.3: lamp bases La (-2.28, 10.77), Lb (-2.35, 5.17),
    // Lc (-2.24, 2.17) — all west of the queue lane (x -2.2..1.2), inside
    // the pavement band x -5.6..-1.8; the south pad (C) also carries the
    // curved-arm lamp Ld (base (-0.47, -0.64), head leaning to (0.39, -0.29))
    // and the low lantern Lm (-1.56, -0.83) on the entrance apron, clear of
    // every capsule, of the bus sweep (z -3.65..-1.35) and of the bus's S17
    // broadside box (x -4.9..-2.6, z -2.25..5.35). scaleY/posY are the OLD
    // fit's, unchanged: pavement top 0.081, kerb tops 0.334 (<= the lanes'
    // 0.35 cap), lamp tops 3.41 / 2.73 / 2.13 (<= 4.0 cap).
    // PROJECTED READ (engine path() cameras, 1080x1920, projector validated
    // against verdict2's stills): THREE lamps read whole — base, post and
    // glowing head inside the frame — at EVERY S13 framing: Ld head px
    // (814,936) / (853,905) / (956,825), Lm head (520,1053) / (531,1050) /
    // (559,1054) at frame centre, Lc head (292,1186) / (278,1176) /
    // (231,1169); Lb joins at 35.8/36.5 and grazes out at 38.5. Pad C's
    // kerb edges cross the foreground (east edge px (517,1312)->(340,1448)
    // at 35.8, (564,1411)->(310,1567) at 38.5). La is the row's far end and
    // stays out of S13 (crane proximity), as in any lawful fit of this
    // rigid piece. On load the previz lamp posts (SL) hide, as before.
    const strCrewGlb = await loadGlb('street-crew.glb');
    if (strCrewGlb && addGlb(strCrewGlb, F, true, { pos: [-2.5, -0.26, 5.0], rotY: -0.24, scale: [8.0, 11.0, 12.5] })) {
      SL.visible = false;
    }
    // BUS: raw bbox 0.476 W x 0.596 H x 1.122 L (length along Z). rotY +90
    // lays the length on X (7.6, the previz footprint) with the piece's +Z
    // end at +X — the end the S13 wide sees as the bus FRONT.
    const busGlb = await loadGlb('bus.glb');
    if (busGlb && dyn.bus && addGlb(busGlb, dyn.bus, false, { pos: [0.23, 0, 0], rotY: Math.PI / 2, scale: [4.83, 5.54, 6.77] })) {
      BP.visible = false;
      // BUSDOOR: raw bbox 0.530 W x 0.555 H x 1.100 D. It dresses the door
      // root at the previz door spot (2.6, 1.6, 1.16): scaled to door height
      // with its base on the ground and its face flush with the bus side;
      // update(t) slides this root's position.x open on arrival, as before.
      const doorGlb = await loadGlb('busdoor.glb');
      if (doorGlb) {
        const doorRoot = addGlb(doorGlb, dyn.bus, false, { pos: [2.6, 0, 0.55], scale: [4.15, 4.0, 1.2] });
        if (doorRoot) dyn.busDoor = doorRoot; // the door root group
      }
    }
  } catch (e) { /* GLB layer failed: the previz stands, the film still renders */ }

  let rig; try { rig = createLightRig(THREE, PLACES, {}); } catch { rig = undefined; }
  const look = (rig && opts && opts.post) ? createPost(THREE, rig, opts.post) : undefined;
  if (look && opts && opts.post && opts.post.shade) { try { look.shading = createRigShade(THREE, rig, opts.post.shade); } catch (e) { /* shading optional */ } }
  return {
    ...base, group: g, rig, look,
    marks: { ...(base.marks || {}), lobby: [0, 0], corridor: [400, 0], front: [-400, 0] },
    points,
    update(t) {
      base.update?.(t); rig?.update(t);
      // lamp flicker (seeded phases, pure in t)
      for (const b of dyn.bulbs) { const s = 1 + .06 * Math.sin(t * 11 + b.ph) * Math.sin(t * 3.7 + b.ph * 2);
        b.m.scale.setScalar(s); }
      // lobby stub occupants stir at their doors (the hook's living depth)
      for (const h of dyn.stubHeads) { h.m.rotation.y = .16 * Math.sin(t * .7 + h.ph);
        h.m.position.y = .03 * Math.sin(t * 1.3 + h.ph * 1.7); }
      // L16: the set's odd doors (5, 7) swing open lit, staggered after «بتفضى» (46.98)
      for (const d of dyn.oddDoors) { const k = ss(d.t0, d.t0 + .45, t);
        d.hinge.rotation.y = -k * 1.8; d.lit.material.opacity = k * .95; }
      // L13: the bus pulls in (35.2→36.4, ease-out), its door opens at 36.5
      if (dyn.bus) { const k = ss(35.2, 36.4, t); const e = 1 - (1 - k) * (1 - k);
        dyn.bus.position.x = -17 + e * 12.6; dyn.bus.position.z = -2.5;
        if (dyn.busDoor) dyn.busDoor.position.x = 2.6 + ss(36.5, 36.9, t) * .55;
        // S17 (49.06+): the bus has swung round during the corridor cutaways
        // (S14–S16 are all indoors; the bus is off-screen 38.4→49.1) and sits
        // broadside across the plaza, door side (+Z local -> +X world under
        // rotY +90) facing the S17 camera, so the open doorway reads behind
        // the filing queue as the pack's S17 sighting requires. In its L13
        // park the length lay on X with the front toward the S17 camera and
        // the door side at grazing incidence — the doorway could not read
        // (critic verdict2, busdoor NO). Pure in t; S13 is untouched.
        if (t >= 49.05) { dyn.bus.rotation.y = Math.PI / 2;
          dyn.bus.position.x = -3.75; dyn.bus.position.z = 1.55; }
        else dyn.bus.rotation.y = 0; }
      // the queue shuffles toward the entrance, looping (pure in t)
      for (const q of dyn.queue) { const adv = ((t * .32 + q.i * .9) % 2.2);
        q.m.position.z = q.z0 - adv * .35; q.m.position.y = .02 * Math.abs(Math.sin(t * 2.4 + q.i * 1.3)); }
    },
  };
}
