# BIBLE — Hilbert's Infinite Hotel (فندق هيلبرت / فندق مالوش نهاية)

Pass 1 (BIBLE + SHOTPLAN). The director's brief (`../DIRECTOR-BRIEF.md`) is BINDING: the four
compasses, the hero prop (the room numbers), the title decided in advance. The director's shot
plan (`../SHOTPLAN.md`) fixes segments, cuts and cameras. This bible locks cast, places, props,
colour, the Face Notebook and the line-by-line beats the builder implements in `film.js` /
`set.js` / `cast/` / `props/`.

Format: 9:16, 1080x1920, 30 fps, film ≈ 59.71 s (last word ends 59.21 + 0.5 endHold), frames
0..~1790 (exact end from the harness `info`). Voice: `audio/clean.wav` exactly as delivered —
NEVER edited (MD5 d87b8ce2944fcbfdbc898f7895c8858f). 150 script words = **155 spoken entries**
in `audio/word-timings.txt`, split into **19 narrator lines** in `scenes/words.json` (the
caption source of truth — captions match the spoken words exactly, incl. the ما/فيش and
لا/نهائيين splits). ALL lines are narrator lines (third-person voiceover; `who` omitted —
nobody lip-syncs). On screen each line's beat is carried by its named focus character(s).
Captions: `captions: 'words'`, 1–2 words per beat, lower third, engine style (white bold,
ink outline, no black box). No text on screen except captions and the diegetic door numbers.

## THE ONE-SENTENCE AND THE COMPASSES (brief, binding)
- The sentence the viewer says: «فندق مليان على الآخر، ولسه بيلاقي أوضة لأي ضيف يوصل!»
- The 3-second bet: a FULL hotel — every door occupied, the key board exhausted — and the calm
  clerk still tells the new guest: «في أوضة». **The stakes live INSIDE the hook frames**
  (training item 4, this film's named risk): frame 0 shows the astonished guest with his
  suitcase in the foreground, the clerk calm behind the desk, and BEHIND them the corridor
  mouth with numbered doors 1-2-3 all occupied (heads, luggage, lamplight) plus the key board
  with every hook taken. Nothing about the stakes is caption-carried.
- The want: the CLERK wants to prove his hotel never says no. The GUEST wants a room and
  cannot believe. "FULL" is every shot's enemy; the solution appears visually in the same beat.
- Hero prop: **the room numbers** — door plaque «1» first, then the numbers sliding (+1 dance,
  then ×2 doubling, then the odd doors lighting open). Companion prop: the clerk's brass key.
- Title (decided, does not repeat the hook line): «الفندق اللي عمره ما قال لضيف: مفيش مكان».

## MOVEMENT LOCK (training standard — no exceptions)
- No static shot. Every shot: a named camera move (path/push/orbit/follow) with reframing
  beats ≤2.5 s apart, motion inside the frame, and a living element (lamp flicker, dust,
  cloth, heads at doors). Camera movement alone never counts: characters act on every line.
- Every line: focus character's face key at line start −0.1, ONE body action tied to a word,
  listeners reacting 1–3 frames after the trigger word, then a dead-still hold.
- Cuts ONLY on word boundaries (line starts; inside L9 at word 11 «وهكذا» 25.80; inside L15
  at word 5 «واتنين» 44.32). Place changes only on cuts.
- Walking shots show real walking (travel + leg cycle); a walk ends before the line that
  needs the walker somewhere else.

## GLOBAL LOOK
A grand old hotel at night: warm amber lamplight against deep teal shadow. The corridor is
the film's spine — an endless perspective of numbered doors and lamp pools. Faces readable
at all times; no cropped faces; no focus character's back to camera. Frame 0: the guest's
astonished face big in the foreground (≥300 px), the clerk and the full corridor behind him.
Brightness floor: NO frame below 40/255 mean luminance (the hotel is lamplit warm, not black).

## CAST (specs in scenes/cast/<id>.json — round white heads, ink outlines; one owned colour
and one distinguishing thing each; leads 3–6 torso details, extras 1–3)
- `clerk` — the night clerk, 40s, tall and slim, deep TEAL waistcoat over a cream shirt, dark
  trousers, bowler hat, round gold glasses, neat moustache. Owned colour: teal. His calm is
  the film's engine: he conducts the impossible like a nightly routine. Desk side in the
  lobby; the corridor is his stage.
- `guest` — the new guest, 30s, medium-stout, RUST-ORANGE coat over a shirt, flat cap, wide
  eyes (eyeSize 1.05), suitcase in his right hand. Owned colour: rust. The audience's face:
  astonishment arc (Face Notebook).
- `g1` — room guest at door 1→2→(×2)4: middle-aged, PLUM coat, moustache, carries a suitcase.
- `g2` — room guest at door 2→3→(×2)6: young, OLIVE jacket, ball cap, carries a suitcase.
- `g3` — room guest at door 3→4→(×2)8: older, grey-blue dressing gown over pyjamas, bald
  sides with white hair — the comic sleepy one, moved twice against his will.
- `h1` — door head, mustard headscarf; `h2` — door head, burgundy beanie, beard;
  `h3` — door head, slate jacket, goatee. (Corridor life at doors 4–6; heads only in most
  shots, full body when their door is near camera.)
- `pax1` — bus passenger, red headscarf, two bags; `pax2` — bus passenger, tall, green coat,
  navy beanie, a suitcase in each hand. (The endless queue is pax1/pax2 variants re-dressed
  by the set's crowd cards in the front place — nobody important is a copy of themselves.)
Crowd depth: the bus queue and the corridor's far doors read through depth, haze and
silhouette figures built into the set (Environment owns them); the named cast carries every
readable face.

## FACE NOTEBOOK (binding — written before Build; NO character repeats the same full face
state on consecutive beats; emotions must travel)
CLERK (calm, but never twice the same calm):
L1 smug (brow on, eyes smug, mouth smirk) → L2 serene presenter (eyes open, mouth smile) →
L4 matter-of-fact (eyes half, mouth flat) → L6 deadpan pity, miming the ordinary clerk
(brow down, eyes sad, mouth frown) → L7 dawning mischief (brow up, eyes wide, mouth smile) →
L8 conductor (brow on, eyes open, mouth smile — the point down the corridor) →
L9 pleased rhythm (eyes smug, mouth smirk) → L10 warm welcome (brow up, eyes open,
mouth smile, at door 1) → L12 serene pride (eyes half, mouth smile) → L14 grand showman
(brow down, eyes stare, mouth tight) → L16 triumphant calm (brow on, eyes smug, mouth smirk) →
L18 knowing (brow quizzical, eyes half, mouth smile — the wink beat, to camera) →
L19 serene final (brow on, eyes open, mouth smile).
GUEST (the astonishment arc):
L1 astonished (brow up, eyes wide, mouth o) → L4 confused (brow knit, eyes stare, mouth flat) →
L5 hopeful (brow up, eyes open, mouth smile) → L6 deflated (brow worried, eyes sad, mouth
frown) → L7 dawning (expr dawning) → L9 amazed at the dance (brow up, eyes wide, mouth wide) →
L10 joy entering room 1 (eyes arc, mouth smile) → L11 relief (expr relief) → L13 fresh shock
at the bus (brow up, eyes wide, mouth o) → L15 eager helper in the doubling (brow on, eyes
open, mouth smile — he steps 1→2 himself) → L16 comprehension (brow quizzical, eyes open,
mouth smirk) → L17 delight (eyes arc, mouth smile) → L18 laughing disbelief (brow up, eyes
half, mouth wide) → L19 settled happy (brow on, eyes open, mouth smile).
G1/G2/G3 (minor arc, same discipline): L3 curious heads out → L9 put-upon (wince, knit) while
carrying → L11 content settled (smile) → L15 effort hop (tight, down) → L16 smug settled.
H1/H2/H3 and PAX: one readable state per appearance, never the same twice in a row on screen.

## PLACES (scenes/set.js, own set, places 400 D apart; previz flat at Build — Environment
owns the real set later; every place has depth: far end 25 D+ behind the focus, 2+ visible
practicals, a living element in set update(t))
1. `lobby` (0,0) — grand reception at night. Desk centre-left, the key board behind the
   clerk (every hook taken — the board is the "full" sign, no words), desk lamp + two wall
   sconces, and the CORRIDOR MOUTH in the back wall: through the arch, doors 1-2-3 and the
   corridor's lamp pools recede 25 D+. Colour: warm amber vs teal shadow. Lines 1, 5, 6, 7, 18.
2. `corridor` (400,0) — the endless corridor, the film's spine: 4 D wide, 60 D+ long, doors
   on both sides every 3 D with brass number plaques (1,2,3… readable near camera, dissolving
   into haze far away), wall lamps between doors (light pools), runner carpet, luggage and
   shoes outside occupied doors. Far end fades in warm haze — never a black void.
   Lines 2, 3, 4, 8, 9, 10, 11, 12, 14, 15, 16, 19.
3. `front` (−400,0) — the hotel facade at night: five storeys of lit windows (ALL lit = the
   hotel is full, visible from the street), entrance canopy with lamps, the street running
   30 D into lamp posts and dark. The bus arrives here; the passenger queue stretches down
   the street. Lines 13, 17. This place holds the film's ONE establishing wide (S13).

## PROPS (scenes/props/<kind>.js + built-ins; PROP GUARD: owners and hand-overs on screen,
state changes on their words or on cuts, snap only on real hits)
- `key` (custom, brass room key on a fob) — the clerk's right hand from frame 0; raised high
  on «حاجة تانية» (L7 word 5, 19.41); points the dances (L8/L14); never leaves his hand.
- `suitcase` (custom) — the guest's (right hand, from frame 0; set down inside room 1 on
  «دخلها» L10 word 6, 30.03 — a put_down on screen), and one each for g1/g2/g3 in the dances
  (carried in hand through L9/L15; put down at their new doors in L11/L16).
- `ledger` (built-in `book` with a printed cover, on the desk) — the clerk taps it on
  «الرياضيات» (L18 word 4, 52.03). It never moves.
- Door plaques and doors: set elements (Environment owns their build); the three hero doors
  (1, 2, 3) are PROPS (custom kind `door`) so their open/light states key on words:
  door 1 opens lit at «فضيت» (L10 word 3, 28.82); odd hero doors open lit in the reveal
  sequence L16 (46.98 «بتفضى» …). All other doors are set dressing with state in set
  update(t), pure in t, on the same words.

## LINES — beats (narrator voiceover; focus = who carries the picture; times = word times)
| # | time | place | focus / beat | camera (Build framing — Camera pass refines) | living element |
|---|--------|-------|--------------|----------------------------------------------|----------------|
| 1 | 0.00–3.63 | lobby | HOOK. Guest astonished foreground with suitcase; clerk calm behind desk; corridor mouth + occupied doors 1-2-3 + exhausted key board behind. On «في أوضة» (3.22) the clerk smiles and lifts the key a fraction. Beat: FULL, and still a room. | path: start on guest face ~380 px, slow arc-push settling to the clerk two-shot by word 7 | lamp flicker, heads stirring at doors behind |
| 2 | 4.35–6.40 | corridor | The endless hotel: glide along doors 1..6, plaques passing, clerk walking ahead presenting with an open hand on «ملوش نهاية». | tracking glide along the corridor depth | lamp pools passing, a head ducking back in |
| 3 | 6.75–9.52 | corridor | «أوضة واحد واتنين وتلاتة»: on each number word the matching door's guest head pops out (g1 at 7.12, g2 at 7.41, g3 at 7.98); the glide continues into depth on «وهكذا». | follow-glide past the hero doors, push into depth | heads popping on the words, lamp sway |
| 4 | 9.98–12.44 | corridor | EVERY room taken: h1/h2/h3 heads out at doors 4-6, g3 brushing his teeth, luggage stacked outside a door; on «ولا أوضة فاضية» (11.81) a last door stays shut with a suitcase waiting outside it. Guest (at corridor mouth) confused. | glide slowing to a stop on the shut door, guest reaction in depth | toothbrush foam, heads turning to camera |
| 5 | 13.10–14.64 | lobby | The guest asks: he lifts his suitcase a little on «ويسأل عن أوضة», hopeful. Clerk listens, serene. | two-shot push-in on the guest | desk lamp glow, key board glint |
| 6 | 15.26–17.67 | lobby | The ordinary hotel, mimed: on «آسفين» (16.51) the clerk does the slow sad head-shake + shrug of every other hotel; the guest deflates. The mime is the gag — the clerk is acting the refusal he will NOT give. | slow push on the clerk, guest in depth | sconce flicker |
| 7 | 18.16–19.74 | lobby | «بس الموظف هنا بيعمل حاجة تانية»: the clerk brightens and raises the brass key high on «حاجة تانية» (19.41); the guest dawns. | push-in ending on the raised key + both faces | key glint, lamp flare a touch |
| 8 | 20.45–22.64 | corridor | At the corridor mouth the clerk orders the move: he points down the corridor on «ينقل» (21.57); heads at doors turn to listen. | orbit around the clerk to face down the corridor | heads turning, lamps |
| 9 | 23.29–27.56 | corridor | THE +1 DANCE. On «ينقل لاتنين» (23.87) g1 steps out of door 1 with his suitcase and into door 2; on «ينقل لتلاتة» (25.18) g2 steps 2→3; g3 follows 3→4; the wave continues into the depth (heads + suitcases receding). Cut inside the line at «وهكذا» (25.80) to the depth view. Clerk conducts from the side; guest watches amazed. | lateral track with the dancers, then (cut) a depth glide behind the wave | suitcases swinging, doors opening/closing in rhythm |
| 10 | 28.38–30.22 | corridor | Room 1 is FREE: door 1 stands open, warm light spilling; on «دخلها» (30.03) the guest steps in with his suitcase, turns back amazed, sets the suitcase down. | push toward door 1 ending on the guest's face in the doorway | light spill, dust in the doorway beam |
| 11 | 30.78–32.50 | corridor | Everyone still housed: g1 settles at door 2 (suitcase down, content), g2 at 3, g3 at 4 pulls his gown around him, relieved. | slow lateral glide past the settled doors | a lamp being turned down, heads nodding off |
| 12 | 32.90–34.69 | corridor | «ما حدش اتطرد»: the clerk pats door 1's frame; the guest gives a happy thumbs-up from the doorway; nobody is in the corridor with a bag packed to leave. | two-shot push on clerk + guest at door 1 | corridor lamps calm |
| 13 | 35.55–38.42 | front | THE SCALE MOMENT (the film's one wide): the bus pulls in under the canopy, doors sigh open, and passengers pour out into a queue that stretches down the lamplit street with no end. On «ملوش نهاية» the queue is still coming. | the one establishing wide (heads 180–250 px), slow crane down toward the entrance | bus lights, queue shuffling forward, window glow |
| 14 | 38.94–42.39 | corridor | The clerk, grander: he orders the doubling — a big point on «ضعف رقمه» (41.87); the guests brace, suitcases up. | orbit + push on the clerk, dancers in depth | lamps, suitcases lifting together |
| 15 | 42.96–45.65 | corridor | THE ×2 DOUBLING. On «واحد لاتنين» (42.96) the guest himself steps out of door 1 → door 2; on «لأربعة» (44.32) g1 hops 2→4; cut inside the line at the «لأربعة» word boundary (44.32) to g2's 3→6 landing on «لستة» (45.35). Plaques 2, 4, 6 glow in sequence on their words. | track with the guest, then (cut) track with g2 | plaques glowing, doors swinging |
| 16 | 46.09–48.72 | corridor | THE REVEAL: on «بتفضى» (46.98) the odd doors — 1, 3, 5, 7 — swing open one after another down the corridor, warm light spilling from each empty room, an endless row of free rooms. | glide down the corridor as the doors open in sequence | light spills, dust in the beams |
| 17 | 49.06–50.49 | front | The passengers file in: pax1/pax2 lead the queue through the entrance, smiling, bags in hand — everyone finds a place. | follow at the entrance, queue in depth | queue moving, canopy lamps |
| 18 | 51.36–55.56 | lobby | The wink: «طبعًا ده في الرياضيات بس» — the clerk taps the ledger on «الرياضيات» (52.03), shares a knowing look with the guest (laughing disbelief) and, on «نفس اللحظة» (55.21), the smallest smile toward camera. In the background (corridor mouth) a guest is still mid-shift, frozen comically. | two-shot path: push to the clerk at «بس», orbit to the guest's reaction at «لا نهائيين» (54.45), settle two-shot | lamp flicker, background guest's held pose |
| 19 | 56.59–59.21 | corridor | CLOSING. «فندق مليان بالكامل، ولسه فيه مكان»: a slow glide down the lamplit corridor — every door settled, door 1 open and welcoming in the foreground — ending on the clerk's serene face (guest beside him in depth, settled happy). Final frame holds the faces. | long push ending on the clerk's face 300–430 px | corridor lamps, dust motes in the light |

## COLOUR SCRIPT
One night, one palette: warm amber lamplight (the hotel's welcome) against deep teal shadow
(the night outside and the corridor's far end). The clerk's teal waistcoat rhymes with the
shadow colour — he belongs to this hotel; the guest's rust coat is the only warm-orange
figure colour, the eye's anchor. The reveal (L16) is the warmest beat: every odd door spills
amber. The front place is the coolest (night street) with the facade's windows all amber.

## BUILD LOCKS (checked by the critics)
- Frame 0 = the guest's astonished face ≥300 px, clerk + occupied corridor + key board in
  frame behind him. No empty frame, no back, no title text.
- Every line: face key at start −0.1, one body action on a word, listeners +1–3 frames after
  the trigger word, dead-still holds. Face Notebook states exactly as tabled above.
- Every word of the 155 in exactly one line, as heard (words.json is the source); cuts only
  on the word boundaries listed; place changes only on cuts.
- Prop state changes land on their words: key raise (19.41), dance moves (23.87 / 25.18 /
  42.96 / 44.32 / 45.35), door 1 opens (28.82) and the guest enters (30.03), odd doors open
  (46.98+). PROP GUARD: no prop jumps; suitcase hand-overs and put-downs on screen.
- Set bar (Environment must pass; Build reports it): shot ≥22% detail / ≤80% flat; film
  median ≥28% / ≤78%; ≤40% of shots under. Brightness: no frame <40/255 mean.
- Pure in t everywhere: seeded randomness only, no Date/Math.random, no state between frames.
