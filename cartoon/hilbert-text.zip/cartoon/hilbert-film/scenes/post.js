// scenes/post.js — POST grade for Hilbert's Infinite Hotel (Post pass, 2026-11-28).
// Trained grade + the binding LOOK-DIRECTION (عربي 02:18, colours VIVID):
//   gamma 1.15 everywhere; saturation ABOVE the trained 1.08 floor per place
//   (lobby 1.16 / corridor 1.15 / front 1.13 — skin checked on stills, no clipping);
//   fog (air density) −20% from the Build base (.008/.010/.007 → .0064/.0080/.0056);
//   bloom threshold HELD at 1.08 so eye-whites never blow out.
// Stub-glow fix: the lobby arch/stub glow blew out flat orange because the bloom
// pass piled onto a saturated plateau. Fixed by ROLL-OFF, not muting: lobby bloom
// k .32→.26 and air `lights` .30→.24, so the glow's core stays warm amber but its
// shoulder falls off through the bright-pass smoothstep (thr → thr*1.6) instead of
// clipping to a flat card. Palette saturation went UP in the same pass.
// Every place change is a cut: no states, no moves. Dust in the lamplight.
export function makePost(A = {}) {
  const dust = (count, box, color, alpha) => ({
    mode: 'box', count, box, vel: [.05, .012, -.02], velVar: [.04, .01, .02], size: .02, sizeVar: .8,
    color, alpha, lit: 1, ambient: .14, sway: .22, swaySpeed: .2,
    nearFade: [.4, 1.6], farFade: .012, soft: .1, shutter: .05 });
  const grade = sat => ({ gamma: 1.15, contrast: 1.08, saturation: sat, gr: .99, gb: 1.04, vignette: .32, vgamma: 1.5 });
  return {
    quality: 'auto', maxBlur: 26, blend: .14,
    zones: { lobby: [0, 0], corridor: [400, 0], front: [-400, 0] },
    states: [],
    moves: [],
    focus: [[0, 4.35, 'guest'], [13.1, 20.45, 'guest'], [28.38, 35.55, 'guest'], [56.59, 59.71, 'clerk']],
    places: {
      lobby: {
        air: { density: .0064, start: [.7, 5], far: 60, color: [.026, .018, .008], lights: .24, g: .3 },
        dof: { aperture: 9, nearK: .3, dead: .5 }, bloom: { k: .26, thr: 1.08 }, gain: 1.35,
        grade: grade(1.16),
        particles: [dust(420, [22, 9, 26], [.72, .6, .4], .15)],
      },
      corridor: {
        air: { density: .008, start: [.7, 5], far: 75, color: [.024, .016, .007], lights: .32, g: .3 },
        dof: { aperture: 9, nearK: .3, dead: .5 }, bloom: { k: .34, thr: 1.08 }, gain: 1.35,
        grade: grade(1.15),
        particles: [dust(650, [10, 8, 70], [.72, .6, .4], .16)],
      },
      front: {
        air: { density: .0056, start: [1, 6], far: 90, color: [.012, .016, .034], lights: .26, g: .35 },
        dof: { aperture: 9, nearK: .3, dead: .5 }, bloom: { k: .36, thr: 1.08 }, gain: 1.3,
        grade: { ...grade(1.13), gb: 1.1 },
        particles: [dust(300, [36, 10, 44], [.55, .58, .68], .12)],
      },
    },
  };
}
