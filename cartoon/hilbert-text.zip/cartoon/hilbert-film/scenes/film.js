// scenes/film.js — BUILD PASS: Hilbert's Infinite Hotel (BIBLE.md, SHOTPLAN.md).
// 19 narrator lines (no `who` — third-person voiceover; nobody lip-syncs), 21 shots,
// cuts ONLY on the BIBLE word boundaries (line starts; L9 at word 11 «وهكذا» 25.80;
// L15 at word 4 «لأربعة» 44.32). MOVEMENT LOCK: every shot is a named move (path /
// push / orbit) with reframing beats ≤2.5 s apart; every line has its focus face key
// at line start −0.1, one body action tied to a word, listener reactions +0.07 after
// the trigger word, then dead-still holds. Frame 0 = the guest's astonished face
// ≥300 px with the clerk, the occupied corridor stub and the exhausted key board
// behind him. Prop state changes land on their BIBLE words; place changes only on
// cuts. Pure in t throughout.
import { makePost } from './post.js';
import { makeShade } from './shade.js';

export default {
  fps: 30, size: [1080, 1920],
  world: { set: 'own', setOpts: { post: { ...makePost(), shade: makeShade() } } },
  cast: {
    clerk: { spec: 'cast/clerk.json', at: [-0.5, -2.9], ry: 12 },
    guest: { spec: 'cast/guest.json', at: [1.7, 2.0], ry: -18 },
    g1:    { spec: 'cast/g1.json',    at: [398.7, -34], ry: 30 },
    g2:    { spec: 'cast/g2.json',    at: [401.3, -37], ry: -30 },
    g3:    { spec: 'cast/g3.json',    at: [398.7, -40], ry: 30 },
    h1:    { spec: 'cast/h1.json',    at: [401.3, -43], ry: -30 },
    h2:    { spec: 'cast/h2.json',    at: [398.7, -46], ry: 30 },
    h3:    { spec: 'cast/h3.json',    at: [401.3, -49], ry: -30 },
    pax1:  { spec: 'cast/pax1.json',  at: [-401.6, 0.8], ry: 140 },
    pax2:  { spec: 'cast/pax2.json',  at: [-400.6, 2.2], ry: 155 },
  },
  voice: {
    file: 'audio/clean.wav', words: 'scenes/words.json',
    lines: [
      { text: 'الفندق مليان والموظف لسه بيقول للضيف في أوضة' },
      { text: 'تخيل فندق عدد أوضه ملوش نهاية' },
      { text: 'أوضة واحد واتنين وتلاتة وهكذا من غير آخر' },
      { text: 'وكل أوضة فيها ضيف يعني ما فيش ولا أوضة فاضية' },
      { text: 'يجي ضيف جديد ويسأل عن أوضة' },
      { text: 'أي فندق عادي هيقوله آسفين ما فيش مكان' },
      { text: 'بس الموظف هنا بيعمل حاجة تانية' },
      { text: 'بيطلب من كل ضيف ينقل للأوضة اللي بعد أوضته' },
      { text: 'اللي في واحد ينقل لاتنين واللي في اتنين ينقل لتلاتة وهكذا وما فيش آخر ضيف أصلاً' },
      { text: 'أوضة واحد فضيت والضيف الجديد دخلها' },
      { text: 'وكل الضيوف التانيين لسه ليهم أوضة' },
      { text: 'ما حدش اتطرد وما حدش خرج من الفندق' },
      { text: 'دلوقتي يجي أتوبيس ركابه عددهم ملوش نهاية' },
      { text: 'الموظف بيطلب من كل ضيف ينقل للأوضة اللي رقمها ضعف رقمه' },
      { text: 'واحد لاتنين واتنين لأربعة وتلاتة لستة' },
      { text: 'كل الأوض الفردي بتفضى وعددها ملوش نهاية برضه' },
      { text: 'والركاب كلهم بيلاقوا مكان' },
      { text: 'طبعاً ده في الرياضيات بس لأن ما فيش حد ينقل ضيوف لا نهائيين في نفس اللحظة' },
      { text: 'فندق مليان بالكامل ولسه في مكان' },
    ],
  },
  acts: {
    clerk: {
      place: [
        { t: 0, at: [-0.5, -2.9], ry: 12 },
        { t: 'line:2.start', at: [399.2, -7], ry: 160 },
        { t: 'line:3.start', at: [400.3, 9.5], ry: 180 },
        { t: 'line:4.start', at: [400.5, 13.5], ry: 180 },
        { t: 'line:5.start', at: [-0.5, -2.9], ry: 12 },
        { t: 'line:8.start', at: [400.9, -3.2], ry: -25 },
        { t: 'line:9.start', at: [402.0, -1.2], ry: -70 },
        { t: 'line:12.start', at: [400.6, -3.4], ry: 15 },
        { t: 'line:14.start', at: [399.2, 0.6], ry: 30 },
        { t: 'line:16.start', at: [400.7, -1.0], ry: -20 },
        { t: 'line:18.start', at: [-0.5, -2.9], ry: 12 },
        { t: 'line:19.start', at: [399.9, -0.6], ry: 25 },
      ],
      face: [
        { t: 0, brow: 'on', eyes: 'smug', mouth: 'smirk' },
        { t: 'line:2.start-0.1', brow: 'off', eyes: 'open', mouth: 'smile' },
        { t: 'line:4.start-0.1', brow: 'on', eyes: 'half', mouth: 'flat' },
        { t: 'line:6.start-0.1', brow: 'down', eyes: 'sad', mouth: 'frown' },
        { t: 'line:7.start-0.1', brow: 'up', eyes: 'wide', mouth: 'smile' },
        { t: 'line:8.start-0.1', brow: 'on', eyes: 'open', mouth: 'smile' },
        { t: 'line:9.start-0.1', brow: 'on', eyes: 'smug', mouth: 'smirk' },
        { t: 'line:10.start-0.1', brow: 'up', eyes: 'open', mouth: 'smile' },
        { t: 'line:12.start-0.1', brow: 'off', eyes: 'half', mouth: 'smile' },
        { t: 'line:14.start-0.1', brow: 'down', eyes: 'stare', mouth: 'tight' },
        { t: 'line:16.start-0.1', brow: 'on', eyes: 'smug', mouth: 'smirk' },
        { t: 'line:18.start-0.1', brow: 'quizzical', eyes: 'half', mouth: 'smile' },
        { t: 'line:19.start-0.1', brow: 'on', eyes: 'open', mouth: 'smile' },
      ],
      look: [
        { t: 0, at: [1.7, 2.3, 2.0] },
        { t: 'line:5.start', at: [2.4, 2.3, -0.6] },
        { t: 'line:6.start', at: [1.7, 2.2, 2.0] },
        { t: 'line:7.start', at: [2.4, 2.3, -0.6] },
        { t: 'line:8.start', at: [401.8, 2.35, 2.5] },
        { t: 'line:12.start', at: [398.8, 2.3, -2] },
        { t: 'line:14.start', at: [400.2, 2.2, -12] },
        { t: 'line:18.start', at: [2.4, 2.3, -0.6] },
        { t: 'line:18.word:15', at: [2.2, 2.6, 11.4] },
        { t: 'line:19.start', at: [400.8, 2.4, -11] },
      ],
      clips: [
        { clip: 'point', at: 'line:1.word:7', hold: 5, out: 6, params: { side: 'R', dir: [0.1, 0.35, 0.35] } },
        { clip: 'point', at: 'line:2.word:6', hold: 8, out: 6, params: { side: 'L', dir: [-0.3, 0.1, -0.4] } },
        { clip: 'shrug', at: 'line:6.word:5', params: {} },
        { clip: 'head_turn', at: 'line:6.word:5', params: { yaw: -16 } },
        { clip: 'head_turn', at: 'line:6.word:7', params: { yaw: 0 } },
        { clip: 'raise_prop', at: 'line:7.word:6', params: { side: 'R', prop: 'key1', to: 'up', frames: 6, antic: 2 } },
        { clip: 'point', at: 'line:8.word:5', hold: 10, out: 6, params: { side: 'R', dir: [0.15, 0.05, -0.5] } },
        { clip: 'point', at: 'line:9.word:4', hold: 6, out: 5, params: { side: 'R', dir: [-0.4, 0.1, -0.3] } },
        { clip: 'point', at: 'line:10.word:3', hold: 6, out: 6, params: { side: 'R', dir: [-0.45, 0.15, 0.1] } },
        { clip: 'knock', at: 'line:12.word:1', params: { side: 'R', to: [-0.4, 0.1, 0.3] } },
        { clip: 'point', at: 'line:14.word:10', hold: 10, out: 6, params: { side: 'R', dir: [0.1, 0.2, -0.5] } },
        { clip: 'point', at: 'line:15.word:1', hold: 5, out: 5, params: { side: 'R', dir: [-0.3, 0.1, -0.3] } },
        { clip: 'point', at: 'line:16.word:4', hold: 8, out: 6, params: { side: 'R', dir: [-0.2, 0.1, -0.5] } },
        { clip: 'knock', at: 'line:18.word:4', params: { side: 'R', to: [-0.2, -0.3, 0.4] } },
        { clip: 'point', at: 'line:19.word:4', hold: 8, out: 8, params: { side: 'R', dir: [-0.4, 0.1, 0.2] } },
      ],
      walk: [
        { t0: 'line:2.start+0.1', path: [[399.2, -7], [399.4, -5.2]], speed: 1.3 },
      ],
    },
    guest: {
      place: [
        { t: 0, at: [1.7, 2.0], ry: -18 },
        { t: 'line:2.start', at: [400.4, 10.5], ry: 0 },
        { t: 'line:4.start', at: [398.9, 3.0], ry: 25 },
        { t: 'line:5.start', at: [2.4, -0.6], ry: -30 },
        { t: 'line:8.start', at: [401.6, -6.5], ry: -20 },
        { t: 'line:9.word:11', at: [400.2, -0.6], ry: -35 },
        { t: 'line:12.start', at: [398.75, -2], ry: 55 },
        { t: 'line:15.start', at: [398.75, -2], ry: 55 },
        { t: 'line:18.start', at: [2.4, -0.6], ry: -30 },
        { t: 'line:19.start', at: [400.9, 0.9], ry: -15 },
      ],
      face: [
        { t: 0, brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:4.start-0.1', brow: 'knit', eyes: 'stare', mouth: 'flat' },
        { t: 'line:5.start-0.1', brow: 'up', eyes: 'open', mouth: 'smile' },
        { t: 'line:6.start-0.1', brow: 'worried', eyes: 'sad', mouth: 'frown' },
        { t: 'line:7.start-0.1', expr: 'dawning' },
        { t: 'line:9.start-0.1', brow: 'up', eyes: 'wide', mouth: 'wide' },
        { t: 'line:10.start-0.1', brow: 'off', eyes: 'arc', mouth: 'smile' },
        { t: 'line:11.start-0.1', expr: 'relief' },
        { t: 'line:13.start-0.1', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:15.start-0.1', brow: 'on', eyes: 'open', mouth: 'smile' },
        { t: 'line:16.start-0.1', brow: 'quizzical', eyes: 'open', mouth: 'smirk' },
        { t: 'line:17.start-0.1', brow: 'up', eyes: 'arc', mouth: 'smile' },
        { t: 'line:18.start-0.1', brow: 'up', eyes: 'half', mouth: 'wide' },
        { t: 'line:19.start-0.1', brow: 'on', eyes: 'open', mouth: 'smile' },
      ],
      look: [
        { t: 0, at: [0.9, 2.45, 9.5] },
        { t: 'line:5.start', at: [0.2, 2.45, 3.5] },
        { t: 'line:9.start', at: [399.5, 2.1, -6] },
        { t: 'line:16.start', at: [399.0, 2.2, -14] },
        { t: 'line:18.start', at: [0.2, 2.45, 3.5] },
        { t: 'line:19.start', at: [399.9, 2.5, -0.6] },
      ],
      clips: [
        { clip: 'lean_back', at: 'line:1.word:2', params: {} },
        { clip: 'hand_to_temple', at: 'line:4.word:8+0.07', params: {} },
        { clip: 'raise_prop', at: 'line:5.word:4', params: { side: 'R', prop: 'gsuit', to: 'forward', frames: 5, antic: 2 } },
        { clip: 'lean_back', at: 'line:6.word:5+0.07', params: {} },
        { clip: 'lean_over', at: 'line:7.word:6+0.07', params: {} },
        { clip: 'lean_over', at: 'line:9.word:4+0.07', params: {} },
        { clip: 'put_down', at: 'line:10.word:6', params: { prop: 'gsuit', side: 'R', at: [398.3, 0, -1.3] } },
        { clip: 'wave', at: 'line:12.word:4', params: { side: 'L' } },
        { clip: 'head_turn', at: 'line:16.word:5+0.07', params: { yaw: -18 } },
        { clip: 'lean_back', at: 'line:18.word:13+0.07', params: {} },
      ],
      walk: [
        { t0: 'line:10.word:3', path: [[400.2, -0.6], [399.2, -1.4], [398.75, -2.0]], speed: 2.2 },
        { t0: 'line:15.word:1', path: [[398.75, -2.0], [399.8, -3.6], [401.3, -5.0]], speed: 2.6 },
      ],
    },
    g1: {
      place: [
        { t: 0, at: [398.7, -34], ry: 30 },
        { t: 'line:3.start', at: [398.7, -2], ry: 30 },
        { t: 'line:8.start', at: [399.0, -12], ry: 30 },
        { t: 'line:9.start', at: [398.7, -2], ry: 30 },
      ],
      face: [
        { t: 'line:3.start-0.1', brow: 'up', eyes: 'open', mouth: 'smile' },
        { t: 'line:9.start-0.1', brow: 'knit', eyes: 'wince', mouth: 'flat' },
        { t: 'line:11.start-0.1', brow: 'off', eyes: 'arc', mouth: 'smile' },
        { t: 'line:15.start-0.1', brow: 'down', eyes: 'stare', mouth: 'tight' },
        { t: 'line:16.start-0.1', brow: 'on', eyes: 'smug', mouth: 'smirk' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:3.word:2', params: {} },
        { clip: 'put_down', at: 'line:11.word:2', params: { prop: 'g1suit', side: 'R', at: [401.0, 0, -4.2] } },
        { clip: 'pick_up', at: 'line:14.word:6', params: { prop: 'g1suit', side: 'R', at: [401.0, 0, -4.2] } },
        { clip: 'put_down', at: 'line:16.word:2', params: { prop: 'g1suit', side: 'R', at: [401.0, 0, -10.2] } },
      ],
      walk: [
        { t0: 'line:9.word:4', path: [[398.7, -2], [399.6, -3.6], [401.3, -5]], speed: 2.0 },
        { t0: 'line:15.word:4', path: [[401.3, -5], [401.3, -8], [401.3, -11]], speed: 3.5, gait: 'run' },
      ],
    },
    g2: {
      place: [
        { t: 0, at: [401.3, -37], ry: -30 },
        { t: 'line:3.start', at: [401.3, -5], ry: -30 },
      ],
      face: [
        { t: 'line:3.start-0.1', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:9.start-0.1', brow: 'worried', eyes: 'wince', mouth: 'frown' },
        { t: 'line:11.start-0.1', brow: 'off', eyes: 'open', mouth: 'smile' },
        { t: 'line:15.start-0.1', brow: 'knit', eyes: 'stare', mouth: 'grid' },
        { t: 'line:16.start-0.1', brow: 'quizzical', eyes: 'smug', mouth: 'smirk' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:3.word:3', params: {} },
        { clip: 'put_down', at: 'line:11.word:3', params: { prop: 'g2suit', side: 'R', at: [398.9, 0, -7.2] } },
        { clip: 'pick_up', at: 'line:14.word:7', params: { prop: 'g2suit', side: 'R', at: [398.9, 0, -7.2] } },
        { clip: 'put_down', at: 'line:16.word:5', params: { prop: 'g2suit', side: 'R', at: [401.0, 0, -16.2] } },
      ],
      walk: [
        { t0: 'line:9.word:9', path: [[401.3, -5], [400.0, -6.6], [398.7, -8]], speed: 2.0 },
        { t0: 'line:15.word:4', path: [[398.7, -8], [400.0, -12], [401.3, -17]], speed: 4.2, gait: 'run' },
      ],
    },
    g3: {
      place: [
        { t: 0, at: [398.7, -40], ry: 30 },
        { t: 'line:3.start', at: [398.7, -8], ry: 30 },
        { t: 'line:9.start', at: [400.9, -10.5], ry: -25 },
        { t: 'line:18.start', at: [3.1, -8.6], ry: 85 },
      ],
      face: [
        { t: 'line:3.start-0.1', brow: 'off', eyes: 'half', mouth: 'flat' },
        { t: 'line:9.start-0.1', brow: 'worried', eyes: 'sad', mouth: 'frown' },
        { t: 'line:11.start-0.1', expr: 'relief' },
        { t: 'line:15.start-0.1', brow: 'down', eyes: 'wince', mouth: 'tight' },
        { t: 'line:16.start-0.1', brow: 'on', eyes: 'half', mouth: 'smirk' },
        { t: 'line:18.start-0.1', brow: 'knit', eyes: 'wince', mouth: 'grid' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:3.word:4', params: {} },
        { clip: 'shake', at: 'line:4.word:4', params: { side: 'R' } },
        { clip: 'put_down', at: 'line:11.word:4', params: { prop: 'g3suit', side: 'R', at: [401.0, 0, -10.2] } },
        { clip: 'pick_up', at: 'line:14.word:8', params: { prop: 'g3suit', side: 'R', at: [401.0, 0, -10.2] } },
        { clip: 'put_down', at: 'line:16.word:6', params: { prop: 'g3suit', side: 'R', at: [401.0, 0, -22.2] } },
        { clip: 'lean_over', at: 'line:18.word:3', params: { deg: 26 } },
      ],
      walk: [
        { t0: 25.7, path: [[398.7, -8], [400.0, -9.6], [401.3, -11]], speed: 2.4 },
        { t0: 'line:15.word:5', path: [[401.3, -11], [401.3, -17], [401.3, -23]], speed: 4.4, gait: 'run' },
      ],
    },
    h1: {
      place: [
        { t: 0, at: [401.3, -43], ry: -30 },
        { t: 'line:4.start', at: [401.3, -11], ry: -30 },
        { t: 'line:9.start', at: [401.3, -29], ry: -30 },
      ],
      face: [
        { t: 'line:4.start-0.1', brow: 'up', eyes: 'open', mouth: 'smile' },
        { t: 'line:8.start-0.1', brow: 'on', eyes: 'open', mouth: 'flat' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:4.word:2', params: {} },
        { clip: 'head_turn', at: 'line:8.word:5+0.07', params: { yaw: 18 } },
      ],
    },
    h2: {
      place: [
        { t: 0, at: [398.7, -46], ry: 30 },
        { t: 'line:4.start', at: [398.7, -14], ry: 30 },
      ],
      face: [
        { t: 'line:4.start-0.1', brow: 'on', eyes: 'stare', mouth: 'flat' },
        { t: 'line:8.start-0.1', brow: 'up', eyes: 'open', mouth: 'smile' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:4.word:3', params: {} },
        { clip: 'head_turn', at: 'line:8.word:5+0.07', params: { yaw: -16 } },
      ],
    },
    h3: {
      place: [
        { t: 0, at: [401.3, -49], ry: -30 },
        { t: 'line:4.start', at: [401.3, -17], ry: -30 },
        { t: 'line:15.start', at: [401.3, -35], ry: -30 },
      ],
      face: [
        { t: 'line:4.start-0.1', brow: 'quizzical', eyes: 'open', mouth: 'smirk' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:4.word:4', params: {} },
      ],
    },
    pax1: {
      place: [
        { t: 0, at: [-401.6, 0.8], ry: 140 },
        { t: 'line:17.start', at: [-401.6, 0.8], ry: 165 },
      ],
      face: [
        { t: 'line:13.start-0.1', brow: 'up', eyes: 'wide', mouth: 'o' },
        { t: 'line:17.start-0.1', brow: 'off', eyes: 'arc', mouth: 'smile' },
      ],
      clips: [
        { clip: 'lean_over', at: 'line:13.word:3+0.07', params: {} },
        { clip: 'wave', at: 'line:17.word:3', params: { side: 'L' } },
      ],
      walk: [
        // S13 STAGING FIX (2026-11-28, bus critic re-submission): he stood square
        // on the bus door spot and the open doorway never read behind him — as the
        // bus pulls in he steps aside to the door's left flank and turns to face
        // the door; back to his queue spot during S14 (front off-screen) so S17
        // opens exactly as the Camera pass tuned it
        { t0: 'line:13.start+0.15', path: [[-401.6, 0.8], [-402.7, 0.45], [-403.4, 0.25]], speed: 1.6, face: [-401.8, -1.9] },
        { t0: 'line:14.start+0.3', path: [[-403.4, 0.25], [-402.5, 0.5], [-401.6, 0.8]], speed: 1.6 },
        { t0: 'line:17.start', path: [[-401.6, 0.8], [-400.6, -1.5], [-399.7, -4.0]], speed: 1.6 },
      ],
    },
    pax2: {
      face: [
        { t: 'line:13.start-0.1', brow: 'on', eyes: 'open', mouth: 'flat' },
        { t: 'line:17.start-0.1', brow: 'up', eyes: 'open', mouth: 'smile' },
      ],
      clips: [
        { clip: 'lean_back', at: 'line:13.word:5+0.07', params: {} },
      ],
      walk: [
        // S13 STAGING FIX (2026-11-28, bus critic re-submission): he grazed the
        // doorway's right edge — as the bus pulls in he steps aside to the door's
        // right flank and turns to face the door; back to his queue spot during
        // S14 (front off-screen) so S17 opens exactly as the Camera pass tuned it
        { t0: 'line:13.start+0.3', path: [[-400.6, 2.2], [-399.8, 2.0], [-399.0, 1.85]], speed: 1.6, face: [-401.5, -1.9] },
        // …holds the flank through the door beat, then shuffles back toward his
        // queue spot late in S13: at the shot's low end framing (38.2) the flank
        // spot puts his head/suitcase on the right frame edge — the shuffle
        // brings him fully back inside the frame for the scale framing
        { t0: 37.55, path: [[-399.0, 1.85], [-399.5, 1.95], [-399.85, 2.05]], speed: 1.3 },
        { t0: 'line:14.start+0.45', path: [[-399.85, 2.05], [-400.2, 2.1], [-400.6, 2.2]], speed: 1.6 },
        { t0: 'line:17.start+0.15', path: [[-400.6, 2.2], [-399.9, 0], [-399.0, -3.6]], speed: 1.6 },
      ],
    },
  },
  props: [
    // the clerk's brass key — in his right hand from frame 0, never leaves it
    { id: 'key1', kind: 'key', owner: 'clerk', in: 'hand:R', rot: [0, 0, 0] },
    // the guest's suitcase — hand from frame 0; set down inside room 1 on «دخلها»
    { id: 'gsuit', kind: 'suitcase', owner: 'guest', in: 'hand:R', color: '#8a4a24', strap: '#54300f',
      keys: [{ t: 'line:10.word:6', in: 'world', at: [398.3, 0, -1.3], rot: [0, 35, 0] }] },
    // the dancers' suitcases — carried through the dances, down at their new doors
    { id: 'g1suit', kind: 'suitcase', owner: 'g1', in: 'hand:R', color: '#5d3b52', strap: '#38222f',
      keys: [{ t: 'line:11.word:2', in: 'world', at: [401.0, 0, -4.2], rot: [0, -20, 0] },
             { t: 'line:14.word:6', in: 'hand:R' },
             { t: 'line:16.word:2', in: 'world', at: [401.0, 0, -10.2], rot: [0, -15, 0] }] },
    { id: 'g2suit', kind: 'suitcase', owner: 'g2', in: 'hand:R', color: '#55602f', strap: '#333a1a',
      keys: [{ t: 'line:11.word:3', in: 'world', at: [398.9, 0, -7.2], rot: [0, 25, 0] },
             { t: 'line:14.word:7', in: 'hand:R' },
             { t: 'line:16.word:5', in: 'world', at: [401.0, 0, -16.2], rot: [0, -25, 0] }] },
    { id: 'g3suit', kind: 'suitcase', owner: 'g3', in: 'hand:R', color: '#44586e', strap: '#2c3a49',
      keys: [{ t: 'line:11.word:4', in: 'world', at: [401.0, 0, -10.2], rot: [0, -30, 0] },
             { t: 'line:14.word:8', in: 'hand:R' },
             { t: 'line:16.word:6', in: 'world', at: [401.0, 0, -22.2], rot: [0, -20, 0] }] },
    // passenger bags
    { id: 'pax1bag1', kind: 'bag', owner: 'pax1', in: 'hand:R', color: '#93302a', flap: '#6e231d' },
    { id: 'pax1bag2', kind: 'bag', owner: 'pax1', in: 'hand:L', color: '#7a5c38', flap: '#573f22' },
    { id: 'pax2suit1', kind: 'suitcase', owner: 'pax2', in: 'hand:R', color: '#3e6b4f', strap: '#24402e' },
    { id: 'pax2suit2', kind: 'suitcase', owner: 'pax2', in: 'hand:L', color: '#5d4a2c', strap: '#3a2c16' },
    // the ledger on the desk — tapped on «الرياضيات», never moves
    { id: 'ledger', kind: 'book', owner: 'clerk', in: 'world', at: [0.2, 1.30, -1.0], rot: [0, 18, 0],
      open: 0, color: '#5d2f26', w: .42, h: .58 },
    // HERO DOORS 1/2/3 (props, so their open/light states key on words)
    { id: 'door1', kind: 'door', owner: 'clerk', in: 'world', at: [397.92, 0, -2], rot: [0, 90, 0], n: 1, open: 0, lit: 0,
      keys: [{ t: 'line:10.word:3', open: .55, lit: 1, ease: .3 }] },
    { id: 'door2', kind: 'door', owner: 'clerk', in: 'world', at: [402.08, 0, -5], rot: [0, -90, 0], n: 2, open: 0, lit: 0,
      keys: [{ t: 'line:9.word:4', open: .9, lit: .55, ease: .3 },
             { t: 'line:11.start', open: 0, lit: 0, ease: .3 },
             { t: 'line:15.word:2', open: .9, lit: .55, ease: .3 },
             { t: 'line:16.start', open: 0, lit: 0, ease: .3 }] },
    { id: 'door3', kind: 'door', owner: 'clerk', in: 'world', at: [397.92, 0, -8], rot: [0, 90, 0], n: 3, open: 0, lit: 0,
      keys: [{ t: 'line:9.word:9', open: .9, lit: .55, ease: .3 },
             { t: 'line:11.start', open: 0, lit: 0, ease: .3 },
             { t: 'line:15.word:5', open: .9, lit: .55, ease: .3 },
             { t: 47.2, open: 1, lit: 1, ease: .35 }] },
  ],
  shots: [
    // S1 — L1 HOOK: guest's astonished face big in the foreground, arc-push settling
    // to the clerk two-shot; corridor stub + key board behind them the whole time
    { t0: 0, t1: 'line:2.start', camera: { move: 'path', roll: [2, 1], keys: [
      { t: 0, pos: [2.9, 2.7, 11.8], target: [1.7, 2.35, 2.0], fov: 30 },
      { t: 1.7, pos: [2.2, 2.75, 12.6], target: [0.9, 2.4, 0.2], fov: 30 },
      { t: 3.3, pos: [1.2, 2.85, 13.4], target: [0.2, 2.45, -1.2], fov: 31 } ] } },
    // S2 — L2: tracking glide along the corridor, the clerk walking ahead presenting
    { t0: 'line:2.start', t1: 'line:3.start', camera: { move: 'path', roll: [-2, -1], keys: [
      { t: 'line:2.start', pos: [400.6, 2.6, 5.0], target: [399.4, 2.4, -5.5], fov: 30 },
      { t: 'line:2.word:4', pos: [400.4, 2.6, 4.4], target: [399.4, 2.38, -5.4], fov: 30 },
      { t: 'line:3.start', pos: [400.3, 2.55, 3.0], target: [399.35, 2.35, -5.3], fov: 30 } ] } },
    // S3 — L3: follow-glide past the hero doors, a head popping on each number word
    { t0: 'line:3.start', t1: 'line:4.start', camera: { move: 'path', roll: [2, 2], keys: [
      { t: 'line:3.start', pos: [400.6, 2.6, 7.2], target: [398.8, 2.35, -2], fov: 32 },
      { t: 'line:3.word:3+0.2', pos: [400.2, 2.6, 4.8], target: [401.2, 2.3, -5], fov: 32 },
      { t: 'line:3.word:5', pos: [400.5, 2.6, 2.6], target: [398.9, 2.2, -9], fov: 32 } ] } },
    // S4 — L4: guest confused at the mouth, glide slowing to the shut door 7
    { t0: 'line:4.start', t1: 'line:5.start', camera: { move: 'path', roll: [-2, -2], keys: [
      { t: 'line:4.start', pos: [400.7, 2.6, 9.5], target: [398.9, 2.4, 3.0], fov: 32 },
      { t: 'line:4.word:5', pos: [399.9, 2.55, 2.0], target: [400.2, 2.2, -12], fov: 32 },
      { t: 'line:4.end', pos: [399.9, 2.5, -4.5], target: [398.9, 1.9, -20], fov: 32 } ] } },
    // S5 — L5: lobby two-shot push-in on the hopeful guest
    { t0: 'line:5.start', t1: 'line:6.start', camera: { move: 'push',
      from: { pos: [3.9, 2.6, 8.4], target: [1.2, 2.35, -0.6], fov: 30 },
      to: { pos: [3.7, 2.55, 7.8], target: [1.3, 2.35, -0.7], fov: 30 }, roll: [2, 2] } },
    // S6 — L6: slow push on the miming clerk, the guest deflating in depth
    { t0: 'line:6.start', t1: 'line:7.start', camera: { move: 'push',
      from: { pos: [2.85, 2.7, 9.4], target: [1.2, 2.48, -1.4], fov: 30 },
      to: { pos: [2.45, 2.65, 8.3], target: [0.8, 2.5, -1.9], fov: 30 }, roll: [-2, -1] } },
    // S7 — L7: push-in ending on the raised key + both faces (CAMERA PASS: widened
    // and re-centred so the guest's full head stays in frame at 300+ px — he was
    // cut by the right edge at ~190 px visible; aim now sits on the pair's axis)
    { t0: 'line:7.start', t1: 'line:8.start', camera: { move: 'push',
      from: { pos: [3.15, 2.65, 11.2], target: [1.3, 2.5, -1.15], fov: 30 },
      to: { pos: [3.0, 2.7, 10.0], target: [1.2, 2.55, -1.2], fov: 30 }, roll: [2, 3] } },
    // S8 — L8: orbit around the clerk at the corridor mouth to face down the corridor
    { t0: 'line:8.start', t1: 'line:9.start', camera: { move: 'path', roll: [-2, 2], keys: [
      { t: 'line:8.start', pos: [401.6, 2.6, 4.9], target: [401.0, 2.45, -3.0], fov: 34 },
      { t: 'line:8.word:5', pos: [401.5, 2.6, 4.3], target: [401.0, 2.42, -3.1], fov: 34 } ] } },
    // S9a — L9 first half: the +1 dance from the one verified deep pocket
    // (CAMERA PASS FINAL: the pocket at (399.0,−12.6) is the only deep seat
    // with a verified clean still — deeper seats are poisoned by h2's leaning
    // body, which blacks cameras near (398.9,−13.2) and fills frames from
    // z −14..−16; so the camera creeps 0.15 D and lets the AIM swing carry
    // the dance: g1's face ~310–390 px throughout, g3 held 26°+ off-axis)
    { t0: 'line:9.start', t1: 'line:9.word:11', camera: { move: 'path', roll: [2, 1], keys: [
      { t: 'line:9.start', pos: [399.02, 2.6, -12.55], target: [399.6, 2.28, -2.55], fov: 32 },
      { t: 'line:9.word:6', pos: [399.05, 2.6, -12.7], target: [400.05, 2.22, -4.4], fov: 32 },
      { t: 'line:9.word:11', pos: [399.08, 2.55, -12.65], target: [400.35, 2.15, -5.6], fov: 32 } ] } },
    // S9b — L9 second half (cut on «وهكذا»): the depth glide behind the wave,
    // shot from the mouth looking in (CAMERA PASS FINAL: the guest anchors
    // the foreground over-shoulder as he watches the wave land in depth —
    // g3/h-figures read small down the corridor, h3's old left-edge block is
    // gone; fov 34 + aim biased +x so the clerk's conducting face stays fully
    // in frame right and no head blocks an edge)
    { t0: 'line:9.word:11', t1: 'line:10.start', camera: { move: 'path', roll: [-2, -3], keys: [
      { t: 'line:9.word:11', pos: [400.35, 2.6, 8.6], target: [400.7, 2.1, -2.0], fov: 34 },
      { t: 'line:9.word:14', pos: [400.38, 2.58, 8.15], target: [400.75, 2.05, -3.0], fov: 34 },
      { t: 'line:10.start', pos: [400.4, 2.55, 7.6], target: [400.8, 2.0, -4.0], fov: 34 } ] } },
    // S10 — L10: push toward door 1, ending on the guest's face in the lit doorway
    { t0: 'line:10.start', t1: 'line:11.start', camera: { move: 'push',
      from: { pos: [401.9, 2.6, 4.4], target: [398.7, 2.25, -2], fov: 38 },
      to: { pos: [401.8, 2.6, 3.6], target: [398.6, 2.3, -2], fov: 38 }, roll: [2, 2] } },
    // S11 — L11: slow lateral glide past the settled doors
    // (WHOLE-SET FIX: mid key shifted +0.6 in x toward the lane centre — the
    // guest's bowed back crossed point-blank at t≈31.3–31.5 and browned out
    // 80%+ of the frame; his back faces the lane, so the camera must clear
    // east of it (+0.3 fixed 31.3 but left the 31.5 camera on his back). The
    // outer keys are untouched, so the monotone-cubic path eases the offset
    // in/out with no jump at the shot's edges, and the guest's bow/crossing
    // beat itself is unchanged)
    // (GATE-B FIX: end key shifted −1.0 in x, 401.5 → 400.5 — Gate B's
    // full-frame inspection flagged frame 971 ONLY (t≈32.37): on the return
    // leg g1's head (centre ≈(401.78, 2.06, −5.39)) sweeps through the old
    // camera point (401.196, 2.6, −5.581) as he turns into his settle, and
    // the lens sits inside his head hull for exactly that one frame
    // (detail 4.0% / flat 95.7% / lum 27.9; 970 and 972 clean). Proven by
    // elimination render: hiding character.g1 alone restores the frame.
    // Holding the lane-centre side through the end key keeps ~0.6 clearance
    // from his head; his acting and the shot's targets are unchanged)
    { t0: 'line:11.start', t1: 'line:12.start', camera: { move: 'path', roll: [-2, -1], keys: [
      { t: 'line:11.start', pos: [401.7, 2.6, 1.6], target: [401.2, 2.1, -5], fov: 32 },
      { t: 'line:11.word:3', pos: [399.1, 2.6, -2.2], target: [398.9, 2.1, -8.5], fov: 32 },
      { t: 'line:11.end', pos: [400.5, 2.6, -6.0], target: [401.2, 2.0, -11.5], fov: 32 } ] } },
    // S12 — L12: two-shot push, clerk patting door 1's frame + guest in the doorway
    // (CAMERA PASS: shot from the mouth side — the old deep camera saw the clerk's
    // back; from +Z he reads three-quarter (~45°) while the guest's doorway beat
    // stays in frame left)
    { t0: 'line:12.start', t1: 'line:13.start', camera: { move: 'push',
      from: { pos: [399.5, 2.65, 7.0], target: [399.9, 2.42, -2.8], fov: 32 },
      to: { pos: [399.65, 2.6, 5.6], target: [399.95, 2.4, -2.85], fov: 32 }, roll: [2, 1] } },
    // S13 — L13: THE ONE WIDE (front): crane down as the bus arrives and the queue
    // stretches down the lamplit street (featured heads 180–250 px)
    { t0: 'line:13.start', t1: 'line:14.start', camera: { move: 'path', roll: [-2, 1], keys: [
      { t: 'line:13.start', pos: [-397.8, 8.5, 19], target: [-401.8, 1.8, -3], fov: 34 },
      { t: 'line:13.word:4', pos: [-398.2, 6.0, 16.5], target: [-402.0, 1.8, -3.2], fov: 34 },
      { t: 'line:13.end', pos: [-398.6, 4.2, 14], target: [-402.2, 1.9, -3.5], fov: 34 } ] } },
    // S14 — L14: orbit + push on the grand clerk, the dancers braced in depth
    { t0: 'line:14.start', t1: 'line:15.start', camera: { move: 'path', roll: [2, -2], keys: [
      { t: 'line:14.start', pos: [401.7, 2.62, -10.81], target: [399.5, 2.42, 0.3], fov: 32 },
      { t: 'line:14.word:5', pos: [401.13, 2.62, -9.6], target: [399.7, 2.38, -0.8], fov: 32 },
      { t: 'line:14.word:10', pos: [401.77, 2.63, -7.96], target: [399.9, 2.3, -4], fov: 32 } ] } },
    // S15a — L15 first half: track with the guest himself stepping 1→2
    { t0: 'line:15.start', t1: 'line:15.word:4', camera: { move: 'path', roll: [2, 2], keys: [
      { t: 'line:15.start', pos: [400.4, 2.6, -13.5], target: [399.6, 2.25, -2.5], fov: 32 },
      { t: 'line:15.word:3', pos: [400.3, 2.6, -14.8], target: [400.0, 2.2, -4], fov: 32 } ] } },
    // S15b — L15 second half (cut on «لأربعة»): g1's hop in depth, track with g2 3→6
    { t0: 'line:15.word:4', t1: 'line:16.start', camera: { move: 'path', roll: [-2, -1], keys: [
      { t: 'line:15.word:4', pos: [400.3, 2.6, -26.5], target: [400.1, 2.1, -10], fov: 32 },
      { t: 'line:15.word:6', pos: [400.3, 2.6, -25.8], target: [400.1, 2.05, -11], fov: 32 } ] } },
    // S16 — L16 THE REVEAL: glide down the corridor as the odd doors open lit in sequence
    // (GATE-B FIX: first two keys shifted west, 400.5 → 399.8 and
    // 400.4 → 399.4 — Gate B's full-frame inspection flagged frames
    // 1401–1405: the old glide drove straight through the CLERK's head
    // (hull centre (400.7, 2.75, −1.0), x-span [399.99, 401.42]) as he
    // conducts at the corridor mouth; at t=46.7667 the camera
    // (400.41, 2.66, −0.535) sits inside his head hull — frame 1403 is the
    // flat orange inside of his face (detail 3.7% / flat 96.1%), 1404/1405
    // the dark interior. Proven by elimination render: hiding
    // character.clerk alone restores the frames. The west shift passes him
    // with ~0.5–0.6 clearance inside the lane; he stays the foreground
    // subject at frame right, his conducting beat and all targets are
    // unchanged, and the end key is untouched)
    // (GATE-B FIX ROUND 2: key 2 shifted again, [399.4, 2.65, −1.5] →
    // [399.2, 2.65, −2.6] — Gemini Neon's blind sheet review caught frame
    // 1410 (t=47.0), a fault class the metric scan cannot see: at
    // line:16.word:4 the clerk's point gesture sweeps his golden key
    // (prop.key, AABB 0.33×0.47×0.15) through the old key-2 point — at
    // t=47.0 the key sits 0.19 from the lens and its bow rings the frame
    // as a hollow orange shell (orange coverage 36.7%); frame 1409 is
    // the graze as it arrives. Proven by elimination renders on the real
    // render path: hiding prop.key alone collapses the shell to 4.3%,
    // hiding every character leaves it standing. The dark centre oval is
    // the clerk's pointing hand at 0.49 — ordinary foreground once the
    // ring is gone. Two lateral attempts failed on stills: [398.9, 2.65,
    // −0.9] moved the collision to frames 1414–1415 (shell 25.7%/44.4%)
    // and a west rail at [398.45, 2.65, −1.1] still met it at 1414
    // (53.7%) — the engine's FX1 clear solver (character.js clearOfFace)
    // displaces a raised hand sideways in screen space by up to ~0.45
    // as the camera sees it, so any path lingering in the lane at the
    // key's hang depth (z ≈ −1.85, hand peak (399.4, 2.61, −2.14))
    // during the gesture (46.98–47.58) can be met halfway. The final
    // key 2 therefore dives SOUTH of the hang depth before the gesture
    // fires: the camera crosses z = −1.85 at t ≈ 46.93 (clear weight
    // still 0, key at rest by the clerk) and is at z ≤ −2.6, ≥1.25 from
    // the key, for the whole gesture; the approach passes the clerk's
    // head hull 0.69 west of its face (round 1 had 0.59, clean), and
    // leg 2 restores the eastern line (x ≈ 399.8 at z = −4) for the
    // bearded guest's door. Targets, acting, timings and the other two
    // keys are unchanged)
    { t0: 'line:16.start', t1: 'line:17.start', camera: { move: 'path', roll: [1, 2], keys: [
      { t: 'line:16.start', pos: [399.8, 2.7, 3.8], target: [399.4, 2.2, -4], fov: 32 },
      { t: 'line:16.word:4', pos: [399.2, 2.65, -2.6], target: [399.4, 2.1, -13], fov: 32 },
      { t: 'line:16.end', pos: [400.5, 2.6, -5.5], target: [399.6, 2.0, -21], fov: 32 } ] } },
    // S17 — L17: at the entrance, the passengers file in toward camera, queue in depth
    // (CAMERA PASS: camera moved ~2 D closer to the walk's start and fov 39→38 so
    // the featured heads open inside 300–430 px instead of 270–285 px)
    { t0: 'line:17.start', t1: 'line:18.start', camera: { move: 'path', roll: [-2, 1], keys: [
      { t: 'line:17.start', pos: [-392.9, 3.15, -1.4], target: [-401.05, 2.4, 1.78], fov: 38 },
      { t: 'line:17.word:3', pos: [-392.9, 3.15, -1.4], target: [-400.01, 2.45, -1.03], fov: 38 },
      { t: 'line:17.end', pos: [-392.9, 3.15, -1.4], target: [-399.25, 2.5, -3.65], fov: 38 } ] } },
    // S18 — L18 THE WINK (lobby): push to the clerk at «بس», orbit to the guest's
    // laughing disbelief at «لا نهائيين», settle two-shot; g3 frozen mid-shift in the stub
    // (CAMERA PASS: the whole path now sits on the pair's axis like S7 — the guest
    // stays fully in frame through every beat; he was half-cropped at the right
    // edge / out of frame on the old clerk-biased path)
    { t0: 'line:18.start', t1: 'line:19.start', camera: { move: 'path', roll: [2, -1], keys: [
      { t: 'line:18.start', pos: [3.1, 2.65, 10.8], target: [1.35, 2.5, -1.2], fov: 30 },
      { t: 'line:18.word:5', pos: [3.0, 2.7, 10.0], target: [1.2, 2.55, -1.2], fov: 30 },
      { t: 'line:18.word:12', pos: [2.95, 2.65, 9.9], target: [1.1, 2.5, -1.05], fov: 30 },
      { t: 'line:18.end', pos: [3.1, 2.65, 10.5], target: [1.35, 2.5, -1.15], fov: 30 } ] } },
    // S19 — L19 CLOSING: long push down the lamplit corridor, door 1 open in the
    // foreground, ending on the clerk's serene face (guest settled beside him in depth)
    { t0: 'line:19.start', t1: 'line:19.end+0.5', camera: { move: 'path', roll: [-2, -1], keys: [
      { t: 'line:19.start', pos: [401.5, 2.7, -11.2], target: [400.0, 2.45, -0.7], fov: 30 },
      { t: 'line:19.word:4', pos: [401.4, 2.65, -10.7], target: [400.0, 2.42, -0.7], fov: 30 },
      { t: 'line:19.end', pos: [401.3, 2.6, -10.2], target: [400.0, 2.4, -0.7], fov: 30 } ] } },
  ],
  captions: 'words',
};
