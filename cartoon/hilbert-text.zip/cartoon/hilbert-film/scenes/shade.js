// scenes/shade.js — SHADING pass for Hilbert's Infinite Hotel (2026-11-28).
// Two-tone per place per references/shading.md: lit side full colour under a warm
// key from the lamp side; shadow side a DEEP WARM colour of the same hue family
// (amber-brown, never grey/black, never a cold cast on faces). The Build base's
// teal fillTint read cold/grey on the shadow side of faces at featured sizes, so
// the fill is now warm; the teal of the BIBLE colour script lives in the SET's
// shadow geometry and the front place's cool key, not on faces.
// Floors are warm per place so faces never fall to mud under the night grade and
// keep modelling at every featured size (300–430 px). Front keeps a cool night
// key with a warm canopy fill — its shadow floor stays the coolest of the three.
// steps sit on the film's cuts so no light change pops mid-shot. Pure in t.
export function makeShade() {
  const metal = { spec: .75, env: .32, keep: .62, sky: [.4, .44, .55], ground: [.08, .07, .06] };
  return {
    zones: { lobby: [0, 0], corridor: [400, 0], front: [-400, 0] },
    states: [],
    steps: [4.35, 6.75, 9.98, 13.1, 15.26, 18.16, 20.45, 23.29, 25.8, 28.38, 30.78, 32.9, 35.55, 38.94, 42.96, 44.32, 46.09, 49.06, 51.36, 56.59],
    places: {
      // lobby: desk-lamp warm key from the left, deep warm amber shadow side
      lobby:    { exposure: 1.3, sat: 1.1, keyTint: [1.18, .9, .58], fillTint: [.78, .6, .42],
                  floor: [.31, .27, .22], hard: .64, rim: .55, rimFill: .5, low: .5, metal },
      // corridor: lamp-pool warm key overhead-side, warm brown shadow into the depth
      corridor: { exposure: 1.3, sat: 1.1, keyTint: [1.16, .88, .55], fillTint: [.76, .58, .4],
                  floor: [.3, .26, .21], hard: .66, rim: .55, rimFill: .5, low: .5, metal },
      // front: cool night key, warm fill from canopy/street lamps (shadow stays warm-dark)
      front:    { exposure: 1.26, sat: 1.06, keyTint: [.82, .9, 1.1], fillTint: [1.12, .8, .48],
                  floor: [.28, .26, .3], hard: .6, rim: .5, rimFill: .5, low: .5, metal },
    },
    moods: [],
  };
}
