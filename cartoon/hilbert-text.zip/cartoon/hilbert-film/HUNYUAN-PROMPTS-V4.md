# Hunyuan prompts v4 — professional scene-first wording (عربي's order, 2026-11-28 07:46)

Rule learned tonight: object-first prompts produce a single hero object (the main model).
Professional scene prompts describe a PLACE you stand inside: scene type first, spatial
layout second, materials and light third, exclusions last. Both fit the 500-char box
with margin — use VERBATIM, never trim. Download the PANORAMA variant in the same
session, immediately after generation, under the lead's checkpoint.

## LOBBY (393 chars)
Wide interior scene of a grand hotel lobby, viewed from inside the room: wood-panelled walls on all sides, a long straight wooden reception counter across the middle, behind it a full wall of small brass key hooks with hanging keys, red carpet floor, arched doorway in the back wall, brass lanterns hanging from the ceiling, warm golden lamplight, teal and burgundy accents, no people, no text

## STREET (318 chars)
Street scene at dusk: a wide stone pavement with a raised kerb in the foreground, a straight row of four chunky cast-iron street lamps with big glowing amber lantern heads standing on the pavement, cobbled road beside the kerb, warm golden evening light, lamps large in the foreground, no buildings, no people, no text
