# HUNYUAN GENERATION PACK — فندق هيلبرت (user redirect 2026-11-28 04:09)

The Blender-built set is CANCELLED (set.js GLB layer disabled, film on previz,
info ERRORS: []). All five pieces are generated on Hunyuan 3D
(3d.hunyuanglobal.com), then Blender ONLY decimates / palette-adapts / cleans /
integrates (blender/adapt_hunyuan.py + repaint_hunyuan.py, already in place).
**Enable the materials/textures (PBR) option before every download.**
Save each raw download EXACTLY as named below, into
`~/workspace/projects/hilbert-hotel/assets/hunyuan/`:
`lobby-raw.glb`, `corridor-raw.glb`, `front-raw.glb`, `bus-raw.glb`, `busdoor-raw.glb`.
Look (binding, LOOK-DIRECTION): VIVID — lamplit golds, deep warm wood,
jewel-tone doors (teal, burgundy, plum, forest green), brass, red carpet;
warm night; stylised, clean, game-ready forms that sit beside flat-shaded
cartoon characters. No people in any piece. No text/letters baked in
(room numbers are engine props).

## 1. LOBBY → lobby-raw.glb
Prompt: "Grand vintage hotel lobby interior at night, one-point perspective
from the entrance looking at a long polished dark-wood reception desk, behind
it a tall wooden key board covered with rows of small brass keys on hooks,
warm brass wall sconces glowing amber, arched doorway in the back wall opening
to a corridor, red patterned carpet, deep warm wood panelling, jewel teal and
burgundy accents, hanging lantern, stylised 3D game environment, rich saturated
colours, no people, no text"
Contract: lobby place (0,0); desk line and key board must land behind the
clerk's mark (0,0) facing +Z arrivals; arch centred on the corridor stub.
Adapted piece replaces the lobby shell; engine desk/keyboard props stay out —
the piece carries them.

## 2. CORRIDOR → corridor-raw.glb
Prompt: "Endless vintage hotel corridor interior at night, long straight
hallway in one-point perspective, rows of numbered-free jewel-tone doors on
both sides — deep teal, burgundy, plum, forest green — with warm wood frames
and brass handles, glowing amber wall lamps between the doors, red runner
carpet with a border down the centre, dark wood wainscoting, suitcases and
shoes beside some doors, warm hazy glow at the far end, stylised 3D game
environment, rich saturated colours, no people, no text"
Contract: corridor place (400,0), lane 4 wide along −Z, doors both sides.
Integration tiles/scales the piece along the lane; the centre 2.2-wide walking
lane and all door swings stay keep-clear (blender/keep_clear.json). Hero doors
1–3 and animated doors 5/7 remain engine props in front of the piece's doors.

## 3. FRONT → front-raw.glb
Prompt: "Grand vintage hotel exterior facade at night, tall elegant building
front with rows of warm glowing windows, stone pilasters and cornices, a
bracketed entrance canopy with hanging lanterns over double doors, wide steps,
old-fashioned street lamps glowing amber on the pavement, deep blue night,
warm gold light spilling from the windows, stylised 3D game environment, rich
saturated colours, no people, no text"
Contract: front place (−400,0); facade behind the entrance marks, street and
kerbs in front; all windows lit (winlit material convention at adaptation).

## 4. BUS EXTERIOR → bus-raw.glb
Prompt: "Vintage rounded city bus exterior at night, deep blue and cream
two-tone paint, big curved windshield, round glowing headlights, brass grille
and hubcaps, warm light in the windows, three-quarter front view, stylised 3D
game vehicle, rich saturated colours, no people, no text"
Contract: replaces the bus body in the animated bus group at (−396,0,−14);
the FRONT must be modelled (windshield, headlights) — S13's scale shot and
the arrival (35.2→36.4) depend on it. Door stays a separate engine-animated
root (piece 5 dresses it).

## 5. BUS DOOR / INTERIOR → busdoor-raw.glb
Prompt: "Vintage bus open doorway and interior at night, folding entrance door
open, warm amber interior light, rows of empty upholstered seats in deep red
and brass handrails, steps up into the bus, seen from just outside the door,
stylised 3D game environment, rich saturated colours, no people, no text"
Contract: dresses the bus door root; seen at the 36.5 door-open beat and in
the S17 queue framings behind the passengers.

## Adaptation + integration (my side, per piece, on landing)
1. LIGHTENING — Qwen's step (user order 2026-11-28 04:11): Qwen4-Max's verified
   script `~/workspace/qwen-test/glb_reduce.py` (Blender 5.2.5 headless:
   `--input <piece>-raw.glb --output <piece>-light.glb --ratio 0.05
   --max-texture 1024`; proven tonight on the 1,492,018-tri wall → exactly
   74,599 tris, textures ≤1024 verified in its own output). JUDGE IT BY ITS
   LOG/OUTPUT, NEVER ITS EXIT CODE (known flaw: may exit 0 on hard failure).
   A piece that resists (oversize, broken geometry) STOPS and escalates to
   the lead, who consults Qwen live — no local workaround.
2. Palette-split adaptation (blender/adapt_hunyuan.py) on the lightened piece, to the set.js
   GLB_PALETTE material names (wood, wood_dark, wood_pale, brass, iron, stone,
   door_teal, door_burg, door_plum, door_forest, wall_teal, plaster_warm,
   carpet_red, cream, bus_blue, bus_cream; lampglow/winlit for light sources),
   textures ≤1024. Output: `assets/hunyuan/adapted/<piece>.glb` (the cancelled
   Blender files in assets/set/ stay untouched; the set.js loader is repointed
   to the adapted directory at integration).
3. Integrate in scenes/set.js around unchanged characters/acting/cameras;
   keep-clear verified; info ERRORS: [].
4. Fresh critic per piece before it ships. A piece that fails critic or
   integration is ESCALATED to the lead with evidence — NO silent fallback
   (user order, point 4).
Report per piece: generated → lightened (tris before/after, by Qwen's
glb_reduce log) → adapted (size) → integrated → critic verdict.
