# LOOK DIRECTION — binding (عربي, 2026-11-28 02:18): «أتمنى أن تكون الألوان زاهية»

The colours of this film must be VIVID. This binds Environment and Post alongside the
trained grade numbers:

- **Palette (Environment):** rich, saturated, warm — lamplit golds, deep warm wood,
  jewel-tone accents on doors and costumes. Not muted, not grey, not washed.
- **Saturation (Post):** the trained 1.08 is a FLOOR, not a ceiling — go above it
  where the vivid look needs more, per place, and report the final per-place values.
- **Hard floors that do NOT move:** no frame below 40/255 mean luminance (full-frame
  scan evidence at the gates); bloom threshold held at 1.08 so eye-whites never
  blow out.
- **The benchmark lesson:** our Tian Dan grade was the darkest in the field (only
  film with sub-40 frames). This film must read BRIGHT and VIVID at arm's length
  on a phone.
- **Evidence at Post close (required):** measured per-place saturation values and a
  frame-luminance series (min / median) from the graded film — numbers, not
  adjectives.
