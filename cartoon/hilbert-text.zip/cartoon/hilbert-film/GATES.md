# PRE-RENDER GATES — plan (both mandatory before fleet dispatch)

## Gate A — Blind hook test, true form (internal)
Fresh critic, first 3 s of the FINAL graded film, muted, ONE viewing, no context.
Pass condition: the viewer states BOTH the strange act (a completely full hotel
that still offers a room) AND the stakes (the new guest has nowhere to go — the
full hotel / exhausted key board / occupied corridor must read IN the frames).
Verdict recorded verbatim in the gate report.

## Gate A2 — External Neon review assets (user directions, 2026-11-28 02:38 + 04:17)
The external vision critic is Gemini 4 Neon in Task mode (verified tonight:
strict, frame-specific, independently matched our critics). The LEAD runs the
Neon review from the main chat — my job is only to produce and stash the assets
at the gate stage, from the same final frames, WITHOUT delaying the pipeline.
Per the 04:17 update, the blind-look asset is the WHOLE SHORT in one contact
sheet — any model shown the blind view sees the complete Short:

- `gates/full-film-contact-sheet.png` — a dense tile of the ENTIRE film (all
  shots sampled densely across the full 59.6 s, benchmark-board style like
  Savana's Tian Dan board), tiled with ffmpeg from the final graded
  fleet-rendered frames (the user's contact-sheet method).
- `gates/full-film-contact-sheet-nocaptions.png` — the same board from a
  captions-off THROWAWAY scratch copy (the shipped film.js is never touched),
  if the render budget carries the second render; if not, the shortfall is
  stated in the gate report, not hidden.
- `gates/hook-frames-nocaptions.png` — contact sheet of the hook (first ~3 s,
  sampled across the window, same tiling as our internal strips) from the same
  captions-off scratch copy. No captions anywhere in the sheet.
- `gates/hook-video.mp4` — if feasible, the hook as a short muted video file
  (frames from the same scratch copy, assembled locally with ffmpeg, no audio
  track needed; if the render budget cannot carry it, the sheets alone are
  delivered and the shortfall is stated in the report).

## Gate B — Full-frame inspection (benchmark method)
On the fleet-rendered frames, BEFORE assembly: every frame scanned (PIL) for
black frames, camera-inside-object frames, and mean luminance below 40/255.
Any defective range is fixed at the cause and re-rendered before assembly.
Zero defective frames reach the delivered film.
