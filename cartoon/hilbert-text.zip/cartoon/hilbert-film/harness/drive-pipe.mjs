// drive-pipe.mjs — same job as drive.mjs, but talks to the sandboxed image Chromium
// (/opt/hatch/bin/hatch-chromium-sandbox) over --remote-debugging-pipe (fds 3/4),
// because this VM blocks downloaded Chromium and the sandbox has no network namespace
// route to a debugging port. Usage mirrors drive.mjs:
//   node drive-pipe.mjs info
//   node drive-pipe.mjs stills 0,1.7,4.5 [scale] [outdir]
//   node drive-pipe.mjs frames <from> <to> <outdir>
//   node drive-pipe.mjs track | layout | sweep
//   node drive-pipe.mjs eval "<expr>"
import { spawn } from 'node:child_process';
import { writeFileSync, mkdirSync } from 'node:fs';
mkdirSync('/var/tmp/cz-chrome-profile-pipe', { recursive: true });
import { join } from 'node:path';
import { startServer, ROOT, OUT } from './server.mjs';

const CHROME = process.env.CZ_CHROME || '/opt/hatch/bin/hatch-chromium-sandbox';
const sleep = ms => new Promise(r => setTimeout(r, ms));

const FONT_INJECT = `(() => { const add = () => { try {
  for (const fam of ['Segoe UI Black', 'Arial Black']) {
    const f = new FontFace(fam, "url('/harness/fonts/NotoSansArabic-Black.ttf')", { weight: '900',
      unicodeRange: 'U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF, U+0640' });
    document.fonts.add(f); f.load().catch(() => {});
  } } catch (e) {} };
  add(); document.addEventListener('DOMContentLoaded', add); })();`;

async function boot() {
  const server = await startServer(+(process.env.CZ_PORT || 8765));
  const chrome = spawn(CHROME, ['--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--mute-audio',
    '--use-angle=swiftshader-webgl', '--enable-unsafe-swiftshader', '--remote-debugging-pipe',
    '--user-data-dir=/var/tmp/cz-chrome-profile-pipe', 'about:blank'],
    { stdio: ['ignore', 'pipe', 'pipe', 'pipe', 'pipe'] });
  chrome.stderr.on('data', () => {});
  const w = chrome.stdio[3], r = chrome.stdio[4];
  let buf = Buffer.alloc(0);
  const pending = new Map(); let nextId = 0; const events = [];
  const sessions = new Map();
  r.on('data', d => { buf = Buffer.concat([buf, d]);
    let i; while ((i = buf.indexOf(0)) >= 0) { const msg = JSON.parse(buf.subarray(0, i).toString()); buf = buf.subarray(i + 1);
      if (msg.id && pending.has(msg.id)) { const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(msg.error.message)) : res(msg.result); }
      else events.push(msg); } });
  const send = (method, params = {}, sessionId) => new Promise((res, rej) => { const id = ++nextId;
    pending.set(id, { res, rej }); w.write(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }) + '\0'); });
  // The sandbox has no network: serve the whole project through Fetch interception.
  const { readFileSync, existsSync, statSync } = await import('node:fs');
  const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.wav': 'audio/wav', '.ttf': 'font/ttf',
    '.css': 'text/css', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.glb': 'model/gltf-binary', '.txt': 'text/plain', '.md': 'text/plain' };
  const fetchTimer = setInterval(() => { for (let i = events.length - 1; i >= 0; i--) { const m = events[i];
    if (m.method === 'Fetch.requestPaused') { events.splice(i, 1); const p = m.params; const sid = m.sessionId;
      (async () => { try { const u = new URL(p.request.url); let fp = join(ROOT, decodeURIComponent(u.pathname));
          if (existsSync(fp) && statSync(fp).isDirectory()) fp = join(fp, 'index.html');
          const body = readFileSync(fp);
          const ext = fp.slice(fp.lastIndexOf('.')).toLowerCase();
          await send('Fetch.fulfillRequest', { requestId: p.requestId, responseCode: 200,
            responseHeaders: [{ name: 'Content-Type', value: MIME[ext] || 'application/octet-stream' },
              { name: 'Access-Control-Allow-Origin', value: '*' }, { name: 'Cache-Control', value: 'no-store' }],
            body: body.toString('base64') }, sid);
        } catch { await send('Fetch.fulfillRequest', { requestId: p.requestId, responseCode: 404, body: '' }, sid).catch(() => {}); } })(); } } }, 5);
  fetchTimer.unref();
  const cleanup = async () => { try { chrome.kill('SIGKILL'); } catch {} server.close(); };
  try {
    // find the page target and attach (flatten)
    let targetId = null;
    for (let k = 0; k < 40 && !targetId; k++) { const { targetInfos } = await send('Target.getTargets');
      targetId = targetInfos.find(t => t.type === 'page')?.targetId || null; if (!targetId) await sleep(250); }
    if (!targetId) throw new Error('no page target in sandbox chrome');
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
    const P = { send: (m, p) => send(m, p, sessionId),
      eval: async (expr, awaitPromise = true) => { const rr = await send('Runtime.evaluate',
        { expression: expr, awaitPromise, returnByValue: true }, sessionId);
        if (rr.exceptionDetails) throw new Error('page eval failed: ' + (rr.exceptionDetails.exception?.description || rr.exceptionDetails.text));
        return rr.result?.value; } };
    await P.send('Page.enable'); await P.send('Runtime.enable');
    await send('Fetch.enable', { patterns: [{ urlPattern: '*' }] }, sessionId);
    await P.send('Page.addScriptToEvaluateOnNewDocument', { source: FONT_INJECT });
    await P.send('Page.navigate', { url: `http://127.0.0.1:${+(process.env.CZ_PORT || 8765)}/__suite/cartoon.html?mode=render` });
    const t0 = Date.now();
    for (;;) { if (await P.eval('window.ready === true').catch(() => false)) break;
      if (Date.now() - t0 > 180000) throw new Error('page did not become ready in 180 s; bootError=' + await P.eval('window.bootError || null').catch(() => '?'));
      await sleep(500); }
    return { P, cleanup };
  } catch (e) { await cleanup(); throw e; }
}

const [cmd, ...args] = process.argv.slice(2);
const { P, cleanup } = await boot();
try {
  if (cmd === 'info') {
    console.log(JSON.stringify(await P.eval('window.suite.info()'), null, 1));
    console.log('ERRORS:', JSON.stringify(await P.eval('window.suite.errors()')));
  } else if (cmd === 'stills') {
    const times = args[0].split(',').map(Number), scale = +(args[1] || 1), dir = args[2] || join(ROOT, '.suite', 'frames', 'harness');
    mkdirSync(dir, { recursive: true });
    const res = await P.eval(`window.suite.stills(${JSON.stringify(times)}, ${scale})`);
    res.forEach((d, i) => { if (!d) { console.log(times[i], 'NULL'); return; }
      const f = join(dir, `f_${String(times[i]).replace('.', '_')}.png`); writeFileSync(f, Buffer.from(d.split(',')[1], 'base64')); console.log(f); });
    console.log('ERRORS:', JSON.stringify(await P.eval('window.suite.errors()')));
  } else if (cmd === 'sweep') {
    console.log(JSON.stringify(await P.eval('window.suite.sweep(10)')));
  } else if (cmd === 'track') {
    const tr = await P.eval('window.suite.track()');
    writeFileSync(join(OUT, 'track.json'), JSON.stringify(tr)); console.log('ids:', tr?.ids, 'frames:', tr ? Object.keys(tr.frames).length : 0);
  } else if (cmd === 'layout') {
    console.log(JSON.stringify(await P.eval('window.suite.layout()'), null, 1));
  } else if (cmd === 'frames') {
    const from = +args[0], to = +args[1], dir = args[2] || join(ROOT, 'harness', 'out', 'frames');
    mkdirSync(dir, { recursive: true });
    let done = 0, nulls = 0;
    for (let b = from; b <= to; b += 9) {
      const batch = []; for (let f = b; f <= Math.min(b + 8, to); f++) batch.push(f);
      const res = await P.eval(`window.suite.stills(${JSON.stringify(batch.map(f => f / 30))}, 1)`);
      res.forEach((d, i) => { const f = batch[i];
        if (!d) { nulls++; console.log('frame', f, 'NULL'); return; }
        writeFileSync(join(dir, `f_${String(f).padStart(5, '0')}.png`), Buffer.from(d.split(',')[1], 'base64')); done++; });
      console.log(`frames ${batch[0]}..${batch[batch.length - 1]} written (${done}/${to - from + 1})`);
    }
    console.log('FRAMES DONE:', done, 'NULLS:', nulls);
    console.log('ERRORS:', JSON.stringify(await P.eval('window.suite.errors()')));
    if (nulls || done !== to - from + 1) process.exitCode = 3;
  } else if (cmd === 'eval') {
    console.log(JSON.stringify(await P.eval(args[0])));
  } else console.error('unknown command: ' + cmd);
} finally { await cleanup(); }
